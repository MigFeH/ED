package AVL.V2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.FixMethodOrder;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;

import AVL.AVLTree;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class AVLTreeTest {

	@Test
	void T1_addNode2() {
		AVLTree<Integer> b = new AVLTree<Integer>();

		// 5, 18 10 -- RDD(10)
		assertTrue(b.addNode2(5));
		assertTrue(b.addNode2(18));
		assertTrue(b.addNode2(10));
		assertEquals("5:BF=0\t10:BF=0\t18:BF=0\t",b.inOrder2());
		
		// 40, 50 -- RSD(18)
		assertTrue(b.addNode2(40));
		assertTrue(b.addNode2(50));
		assertEquals("5:BF=0\t10:BF=1\t18:BF=0\t40:BF=0\t50:BF=0\t",b.inOrder2());
		
		// 15 -- RDD(10)
		assertTrue(b.addNode2(15));
		assertEquals("5:BF=0\t10:BF=0\t15:BF=0\t18:BF=0\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// 16 
		assertTrue(b.addNode2(16));
		assertEquals("5:BF=0\t10:BF=1\t15:BF=1\t16:BF=0\t18:BF=-1\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// 12 
		assertTrue(b.addNode2(12));
		assertEquals("5:BF=0\t10:BF=1\t12:BF=0\t15:BF=0\t16:BF=0\t18:BF=-1\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// 14 -- RDD(10)
		assertTrue(b.addNode2(14));
		assertEquals("5:BF=0\t10:BF=-1\t12:BF=0\t14:BF=0\t15:BF=0\t16:BF=0\t18:BF=-1\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// 17 -- RDI(18)
		assertTrue(b.addNode2(17));
		assertEquals("5:BF=0\t10:BF=-1\t12:BF=-1\t14:BF=0\t15:BF=0\t16:BF=1\t17:BF=0\t18:BF=0\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// Inserta un nodo null
		try {
			b.addNode2(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}

		// Inserta un elemento que ya existe
		assertFalse(b.addNode2(15));
	}
	
	@SuppressWarnings("removal")
	@Test
	public void T2_searchNode2() {
		AVLTree<Integer> b = new AVLTree<Integer>();
		
		//Buscar en un �rbol vac�o
		assertNull(b.search2(50));
		
		assertTrue(b.addNode2(10));
		assertTrue(b.addNode2(100));
		assertTrue(b.addNode2(60));
		assertTrue(b.addNode2(30));
		assertTrue(b.addNode2(2));
		assertTrue(b.addNode2(-43));
		assertTrue(b.addNode2(70));
		assertTrue(b.addNode2(90));
		assertTrue(b.addNode2(23));
		assertTrue(b.addNode2(43));
		assertTrue(b.addNode2(65));
		assertTrue(b.addNode2(13));
		assertTrue(b.addNode2(230));
		assertTrue(b.addNode2(49));
		assertTrue(b.addNode2(7));
		assertTrue(b.addNode2(40));
		assertTrue(b.addNode2(50));
		assertTrue(b.addNode2(20));
		assertTrue(b.addNode2(15));
		assertTrue(b.addNode2(3));
		
		//Busca un nodo que no existe
		assertNull(b.search2(500));
		
		//Buscar un nodo
		assertEquals(b.search2(15).getInfo(), new Integer(15));
		assertEquals(b.search2(43).getInfo(), new Integer(43));
	}

	@Test
	void T3_removeNode2() {
		AVLTree<Integer> b = new AVLTree<Integer>();
		//Intenta borrar de un �rbol vac�o
		assertFalse(b.removeNode2(50));
		
		// Insertar 5, 18 10, 40, 50, 15, 16, 12, 14, 17
		b.addNode2(5);
		b.addNode2(18);
		b.addNode2(10);
		b.addNode2(40);
		b.addNode2(50);
		b.addNode2(15);
		b.addNode2(16);
		b.addNode2(12);
		b.addNode2(14);
		b.addNode2(17);
		assertEquals("5:BF=0\t10:BF=-1\t12:BF=-1\t14:BF=0\t15:BF=0\t16:BF=1\t17:BF=0\t18:BF=0\t40:BF=1\t50:BF=0\t",b.inOrder2());
		
		// Borrar un nodo null
		try {
			b.removeNode2(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//Borra un nodo que no existe
		assertFalse(b.removeNode2(500));
		
		// Borra una clave sin hijos --> 50
		assertTrue(b.removeNode2(50));
		assertEquals("5:BF=0\t10:BF=-1\t12:BF=-1\t14:BF=0\t15:BF=0\t16:BF=1\t17:BF=0\t18:BF=-1\t40:BF=0\t",b.inOrder2());
		
		// Borra un elemento que no existe
		assertFalse(b.removeNode2(50));
		
		// Borra una clave con un hijo izquierdo --> 10
		assertTrue(b.removeNode2(10));
		assertEquals("5:BF=0\t12:BF=0\t14:BF=0\t15:BF=1\t16:BF=1\t17:BF=0\t18:BF=-1\t40:BF=0\t",b.inOrder2());
	
		// Borra la ra�z que tiene dos hijos --> 15
		assertTrue(b.removeNode2(15));
		assertEquals("5:BF=0\t12:BF=-1\t14:BF=1\t16:BF=1\t17:BF=0\t18:BF=-1\t40:BF=0\t",b.inOrder2());
	
		// Borra la ra�z que tiene dos hijos --> 14
		assertTrue(b.removeNode2(14));
		assertEquals("5:BF=0\t12:BF=-1\t16:BF=0\t17:BF=0\t18:BF=0\t40:BF=0\t",b.inOrder2());
		
		// Borra una clave que es hoja --> 17
		assertTrue(b.removeNode2(17));
		assertEquals("5:BF=0\t12:BF=-1\t16:BF=0\t18:BF=1\t40:BF=0\t",b.inOrder2());
		
		// Borra una clave que tiene un hijo derecho --> 18
		assertTrue(b.removeNode2(18));
		assertEquals("5:BF=0\t12:BF=-1\t16:BF=-1\t40:BF=0\t",b.inOrder2());
		
		// Borra una clave que es hoja --> 40
		assertTrue(b.removeNode2(40));
		assertEquals("5:BF=0\t12:BF=0\t16:BF=0\t",b.inOrder2());
		
		// Borra la ra�z que tiene dos hijos --> 12
		assertTrue(b.removeNode2(12));
		assertEquals("5:BF=1\t16:BF=0\t",b.inOrder2());
		
		// Borra un hijo que es hoja --> 16
		assertTrue(b.removeNode2(16));
		assertEquals("5:BF=0\t",b.inOrder2());
		
		// Borra la ra�z que no tiene hijos
		assertTrue(b.removeNode2(5));
		
		// Borra el 5 que no existe
		assertFalse(b.removeNode2(5));
	}
}
