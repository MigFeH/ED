package BST;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ArbolesBinariosTest3{

	@Test
	public void T1_addNode3() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		assertTrue(b.addNode3(10));
		assertTrue(b.addNode3(100));
		assertTrue(b.addNode3(60));
		assertTrue(b.addNode3(30));
		assertTrue(b.addNode3(2));
		assertTrue(b.addNode3(-43));
		assertTrue(b.addNode3(70));
		assertTrue(b.addNode3(90));
		assertTrue(b.addNode3(23));
		assertTrue(b.addNode3(43));
		assertTrue(b.addNode3(65));
		assertTrue(b.addNode3(13));
		assertTrue(b.addNode3(230));
		assertTrue(b.addNode3(49));
		assertTrue(b.addNode3(7));
		assertTrue(b.addNode3(40));
		assertTrue(b.addNode3(50));
		assertTrue(b.addNode3(20));
		assertTrue(b.addNode3(15));
		assertTrue(b.addNode3(3));
	
		// Inserta un nodo null
		try {
			b.addNode3(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//A�ade un elemento que ya existe
		assertFalse(b.addNode3(3));
		
		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder3());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230\t",b.preOrder3());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10\t",b.postOrder3());
	}
	
	
	@SuppressWarnings("removal")
	@Test
	public void T2_search3Node() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		//Buscar en un �rbol vac�o
		assertNull(b.search3(50));
		
		assertTrue(b.addNode3(10));
		assertTrue(b.addNode3(100));
		assertTrue(b.addNode3(60));
		assertTrue(b.addNode3(30));
		assertTrue(b.addNode3(2));
		assertTrue(b.addNode3(-43));
		assertTrue(b.addNode3(70));
		assertTrue(b.addNode3(90));
		assertTrue(b.addNode3(23));
		assertTrue(b.addNode3(43));
		assertTrue(b.addNode3(65));
		assertTrue(b.addNode3(13));
		assertTrue(b.addNode3(230));
		assertTrue(b.addNode3(49));
		assertTrue(b.addNode3(7));
		assertTrue(b.addNode3(40));
		assertTrue(b.addNode3(50));
		assertTrue(b.addNode3(20));
		assertTrue(b.addNode3(15));
		assertTrue(b.addNode3(3));
		
		//Busca un nodo que no existe
		assertNull(b.search3(500));
		
		//Buscar un nodo
		assertEquals(b.search3(15).getInfo(), new Integer(15));
		assertEquals(b.search3(43).getInfo(), new Integer(43));
	}
	
	
	@Test
	public void T3_removeNode3() {
		BSTree<Integer> b = new BSTree<Integer>();
		//Intenta borrar de un �rbol vac�o
		assertFalse(b.removeNode3(50));
		
		assertNull(b.search3(50));
		assertTrue(b.addNode3(10));
		assertTrue(b.addNode3(100));
		assertTrue(b.addNode3(60));
		assertTrue(b.addNode3(30));
		assertTrue(b.addNode3(2));
		assertTrue(b.addNode3(-43));
		assertTrue(b.addNode3(70));
		assertTrue(b.addNode3(90));
		assertTrue(b.addNode3(23));
		assertTrue(b.addNode3(43));
		assertTrue(b.addNode3(65));
		assertTrue(b.addNode3(13));
		assertTrue(b.addNode3(230));
		assertTrue(b.addNode3(49));
		assertTrue(b.addNode3(7));
		assertTrue(b.addNode3(40));
		assertTrue(b.addNode3(50));
		assertTrue(b.addNode3(20));
		assertTrue(b.addNode3(15));
		assertTrue(b.addNode3(3));
		
		// Borrar un nodo null
		try {
			b.removeNode3(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//Borra un nodo que no existe
		assertFalse(b.removeNode3(500));

		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder3());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230\t",b.preOrder3());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10\t",b.postOrder3());
		
		//Borra un nodo con un hijo: 7 tiene como hijo el 3
		assertTrue(b.removeNode3(7));
		assertEquals("-43\t2\t3\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder3());
				
		//Borra un nodo con un hijo: 20 tiene como hijo al 15
		assertTrue(b.removeNode3(20));
		assertEquals("-43\t2\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder3());
		
		//Borra un nodo con dos hijos: 2 tiene como hijos al -43 y 2
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode3(2));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder3());
	
		//Borra un nodo con dos sub�rboles: 100
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode3(100));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t230\t",b.inOrder3());
		
		//Borra un nodo con dos sub�rboles: 60
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode3(60));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder3());

		//Borra una hoja: 40
		assertTrue(b.removeNode3(40));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder3());
		
		//Borra la raiz: 10
		assertTrue(b.removeNode3(10));
		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder3());
		
		//Borra un nodo con dos sub�rboles: 50
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode3(50));

		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t65\t70\t90\t230\t",b.inOrder3());
	}
}
