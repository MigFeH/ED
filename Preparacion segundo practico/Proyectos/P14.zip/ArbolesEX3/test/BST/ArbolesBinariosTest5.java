package BST;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ArbolesBinariosTest5{

	@Test
	public void T1_addNode5() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		assertTrue(b.addNode5(10));
		assertTrue(b.addNode5(100));
		assertTrue(b.addNode5(60));
		assertTrue(b.addNode5(30));
		assertTrue(b.addNode5(2));
		assertTrue(b.addNode5(-43));
		assertTrue(b.addNode5(70));
		assertTrue(b.addNode5(90));
		assertTrue(b.addNode5(23));
		assertTrue(b.addNode5(43));
		assertTrue(b.addNode5(65));
		assertTrue(b.addNode5(13));
		assertTrue(b.addNode5(230));
		assertTrue(b.addNode5(49));
		assertTrue(b.addNode5(7));
		assertTrue(b.addNode5(40));
		assertTrue(b.addNode5(50));
		assertTrue(b.addNode5(20));
		assertTrue(b.addNode5(15));
		assertTrue(b.addNode5(3));
	
		// Inserta un nodo null
		try {
			b.addNode5(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//A�ade un elemento que ya existe
		assertFalse(b.addNode5(3));
		
		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230",b.inOrder5());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230",b.preOrder5());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10",b.postOrder5());
	}
	
	
	@SuppressWarnings("removal")
	@Test
	public void T2_search5Node() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		//Buscar en un �rbol vac�o
		assertNull(b.search5(50));
		
		assertTrue(b.addNode5(10));
		assertTrue(b.addNode5(100));
		assertTrue(b.addNode5(60));
		assertTrue(b.addNode5(30));
		assertTrue(b.addNode5(2));
		assertTrue(b.addNode5(-43));
		assertTrue(b.addNode5(70));
		assertTrue(b.addNode5(90));
		assertTrue(b.addNode5(23));
		assertTrue(b.addNode5(43));
		assertTrue(b.addNode5(65));
		assertTrue(b.addNode5(13));
		assertTrue(b.addNode5(230));
		assertTrue(b.addNode5(49));
		assertTrue(b.addNode5(7));
		assertTrue(b.addNode5(40));
		assertTrue(b.addNode5(50));
		assertTrue(b.addNode5(20));
		assertTrue(b.addNode5(15));
		assertTrue(b.addNode5(3));
		
		//Busca un nodo que no existe
		assertNull(b.search5(500));
		
		//Buscar un nodo
		assertEquals(b.search5(15).getInfo(), new Integer(15));
		assertEquals(b.search5(43).getInfo(), new Integer(43));
	}
	
	
	@Test
	public void T3_removeNode5() {
		BSTree<Integer> b = new BSTree<Integer>();
		//Intenta borrar de un �rbol vac�o
		assertFalse(b.removeNode5(50));
		
		assertNull(b.search5(50));
		assertTrue(b.addNode5(10));
		assertTrue(b.addNode5(100));
		assertTrue(b.addNode5(60));
		assertTrue(b.addNode5(30));
		assertTrue(b.addNode5(2));
		assertTrue(b.addNode5(-43));
		assertTrue(b.addNode5(70));
		assertTrue(b.addNode5(90));
		assertTrue(b.addNode5(23));
		assertTrue(b.addNode5(43));
		assertTrue(b.addNode5(65));
		assertTrue(b.addNode5(13));
		assertTrue(b.addNode5(230));
		assertTrue(b.addNode5(49));
		assertTrue(b.addNode5(7));
		assertTrue(b.addNode5(40));
		assertTrue(b.addNode5(50));
		assertTrue(b.addNode5(20));
		assertTrue(b.addNode5(15));
		assertTrue(b.addNode5(3));
		
		// Borrar un nodo null
		try {
			b.removeNode5(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//Borra un nodo que no existe
		assertFalse(b.removeNode5(500));

		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230",b.inOrder5());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230",b.preOrder5());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10",b.postOrder5());
		
		//Borra un nodo con un hijo: 7 tiene como hijo el 3
		assertTrue(b.removeNode5(7));
		assertEquals("-43\t2\t3\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230",b.inOrder5());
				
		//Borra un nodo con un hijo: 20 tiene como hijo al 15
		assertTrue(b.removeNode5(20));
		assertEquals("-43\t2\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230",b.inOrder5());
		
		//Borra un nodo con dos hijos: 2 tiene como hijos al -43 y 2
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode5(2));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230",b.inOrder5());
	
		//Borra un nodo con dos sub�rboles: 100
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode5(100));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t230",b.inOrder5());
		
		//Borra un nodo con dos sub�rboles: 60
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode5(60));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t65\t70\t90\t230",b.inOrder5());

		//Borra una hoja: 40
		assertTrue(b.removeNode5(40));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230",b.inOrder5());
		
		//Borra la raiz: 10
		assertTrue(b.removeNode5(10));
		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230",b.inOrder5());
		
		//Borra un nodo con dos sub�rboles: 50
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode5(50));

		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t65\t70\t90\t230",b.inOrder5());
	}
}
