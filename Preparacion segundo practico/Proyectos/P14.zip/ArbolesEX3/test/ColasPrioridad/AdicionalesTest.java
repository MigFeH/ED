package ColasPrioridad;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class AdicionalesTest {

	@Test
	void test()
	{
		BinaryHeap<Integer> BH = new BinaryHeap<>(7);
		
		assertTrue(BH.add3(5));
		assertTrue(BH.add3(9));
		assertTrue(BH.add3(3));
		assertTrue(BH.add3(1));
		assertTrue(BH.add3(4));
		assertTrue(BH.add3(17));
		assertTrue(BH.add3(2));
		
		List<Integer> ancestrosDel5 = new ArrayList<>();
		ancestrosDel5.add(2);
		ancestrosDel5.add(1);
		
		List<Integer> ancestrosDel17 = new ArrayList<>();
		ancestrosDel17.add(2);
		ancestrosDel17.add(1);
		
		List<Integer> ancestrosDel4 = new ArrayList<>();
		ancestrosDel4.add(3);
		ancestrosDel4.add(1);
		
		List<Integer> ancestrosDel9 = new ArrayList<>();
		ancestrosDel9.add(3);
		ancestrosDel9.add(1);
		
		assertEquals(ancestrosDel5, BH.getAncestors(5));
		assertEquals(ancestrosDel17, BH.getAncestors(17));
		assertEquals(ancestrosDel4, BH.getAncestors(4));
		assertEquals(ancestrosDel9, BH.getAncestors(9));
		
		List<Integer> ancestrosDel2 = new ArrayList<>();
		ancestrosDel2.add(1);
		
		List<Integer> ancestrosDel3 = new ArrayList<>();
		ancestrosDel3.add(1);
		
		assertEquals(ancestrosDel2, BH.getAncestors(2));
		assertEquals(ancestrosDel3, BH.getAncestors(3));
		
		List<Integer> ancestrosDel1 = new ArrayList<>();
		
		assertEquals(ancestrosDel1, BH.getAncestors(1));
	}

}
