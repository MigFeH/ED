package ColasPrioridad;

public interface PriorityQueue <T extends Comparable<T>>
{
	public boolean add(T elemento);
	public T sacar();
	public boolean remove (T elemento);
	public boolean isEmpty();
	public void clear();
	public boolean cambiarPrioridad(int pos, T elemento);
	public String toString();
	boolean add2(T elemento);
	public T sacar2();
	public boolean remove2(T elemento);
	public boolean isEmpty2();
	public void clear2();
	public boolean cambiarPrioridad2(int pos, T elemento);
	public boolean add3(T elemento);
	public T sacar3();
	public boolean remove3(T elemento);
	public boolean isEmpty3();
	public void clear3();
	public boolean cambiarPrioridad3(int pos, T elemento);
	public boolean add4(T elemento);
	public T sacar4();
	public boolean remove4(T elemento);
	public boolean isEmpty4();
	public void clear4();
	public boolean cambiarPrioridad4(int pos, T elemento);
}