package Hash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ClosedHashTableTestRedispersion4
{

	@Test
	void test4()
	{
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add4(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add4(5);
		System.out.println(T.toString());
		// A�ado el 20
		T.add4(20);
		System.out.println(T.toString());
		// A�ado el 19
		T.add4(19);
		System.out.println(T.toString());
		// A�ado el 18
		T.add4(18);
		System.out.println(T.toString());
		// A�ado el 30
		assertTrue(T.add4(30));
		System.out.println(T.toString());
	}

}
