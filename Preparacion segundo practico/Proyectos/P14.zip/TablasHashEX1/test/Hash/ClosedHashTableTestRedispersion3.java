package Hash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ClosedHashTableTestRedispersion3
{

	@Test
	void test3()
	{
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add3(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add3(5);
		System.out.println(T.toString());
		// A�ado el 20
		T.add3(20);
		System.out.println(T.toString());
		// A�ado el 19
		T.add3(19);
		System.out.println(T.toString());
		// A�ado el 18
		T.add3(18);
		System.out.println(T.toString());
		// A�ado el 30
		assertTrue(T.add3(30));
		System.out.println(T.toString());
	}

}
