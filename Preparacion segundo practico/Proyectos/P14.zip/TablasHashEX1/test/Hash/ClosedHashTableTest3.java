package Hash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Exceptions.ElementNotPresentException;

class ClosedHashTableTest3
{
	@Test
	void testAdd3()
	{
		System.out.println();
		System.out.println("-------- Pruebas de add3 --------");
		
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add3(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add3(5);
		System.out.println(T.toString());
		// A�ado el 20
		T.add3(20);
		System.out.println(T.toString());
		// A�ado el 19
		T.add3(19);
		System.out.println(T.toString());
		// A�ado el 18
		T.add3(18);
		System.out.println(T.toString());
		// A�ado el 30
		assertTrue(T.add3(30));
		System.out.println(T.toString());
	}
	
	@Test
	void testFind3()
	{
		System.out.println();
		System.out.println("-------- Pruebas de find3 --------");
		
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add3(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add3(5);
		System.out.println(T.toString());
		// A�ado el 19
		T.add3(19);
		System.out.println(T.toString());
		
		HashNode<Integer> Nodo = T.find3(19);
		System.out.println(Nodo.getInfo().toString());
		System.out.println(Nodo.getStatus());
	}
	
	@Test
	void testRemove3() {
		// Crear una tabla hash vac�a de tama�o 11 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<Integer>(11,0);
		T.add3(2);
		T.add3(11);
		T.add3(13);
		T.add3(24);
		System.out.println(T.toString());
		
		T.remove3(24);
		System.out.println(T.toString());
		
		try {
			T.remove3(35);
		}catch (ElementNotPresentException e) {
			assertEquals(e.getMessage(), "El elemento 35 no existe en la estructura");
		}
		System.out.println(T.toString());
	}

	@Test
	void testGetNumberCollisions() {
		// Crear una tabla hash vac�a de tama�o 11 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<Integer>(13,0);
		T.setDispersionStatus(false);
		
		T.add3(5);
		assertEquals(0, T.getNumberCollisions());
		
		T.add3(8);
		assertEquals(0, T.getNumberCollisions());
		
		T.add3(11);
		assertEquals(0, T.getNumberCollisions());
		
		T.add3(9);
		assertEquals(0, T.getNumberCollisions());
		
		T.add3(5);
		assertEquals(1, T.getNumberCollisions());
		
		T.add3(7);
		assertEquals(0, T.getNumberCollisions());
		
		T.add3(8);
		assertEquals(2, T.getNumberCollisions());
		
		T.add3(6);
		assertEquals(6, T.getNumberCollisions());
		
		T.add3(14);
		assertEquals(0, T.getNumberCollisions());
		
		System.out.println("Numero de operaciones: " + T.getNumberOfOperations());
		System.out.println("Ratio de colisiones por operacion desde la creacion de la tabla hash: " + T.collisionsPerOperation());
	}
}
