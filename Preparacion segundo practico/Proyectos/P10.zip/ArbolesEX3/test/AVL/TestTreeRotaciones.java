package AVL;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestTreeRotaciones {

	@Test
	void testRSD() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode(50));
		assertTrue(T.addNode(25));
		assertTrue(T.addNode(75));
		assertTrue(T.addNode(10));
		assertTrue(T.addNode(30));
		assertTrue(T.addNode(90));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=1\t90:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
		assertTrue(T.addNode(95));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=0\t90:BF=0\t95:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());

	}

	@Test
	void testRSI() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode(50));
		assertTrue(T.addNode(25));
		assertTrue(T.addNode(75));
		assertTrue(T.addNode(10));
		assertEquals("10:BF=0\t25:BF=-1\t50:BF=-1\t75:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
		assertTrue(T.addNode(5));
		assertEquals("5:BF=0\t10:BF=0\t25:BF=0\t50:BF=-1\t75:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
	}
	
	@Test
	void testRSD2() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode2(50));
		assertTrue(T.addNode2(25));
		assertTrue(T.addNode2(75));
		assertTrue(T.addNode2(10));
		assertTrue(T.addNode2(30));
		assertTrue(T.addNode2(90));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=1\t90:BF=0\t",T.inOrder2());
		System.out.println(T.inOrder2());
		assertTrue(T.addNode2(95));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=0\t90:BF=0\t95:BF=0\t",T.inOrder2());
		System.out.println(T.inOrder2());

	}

	@Test
	void testRSI2() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode2(50));
		assertTrue(T.addNode2(25));
		assertTrue(T.addNode2(75));
		assertTrue(T.addNode2(10));
		assertEquals("10:BF=0\t25:BF=-1\t50:BF=-1\t75:BF=0\t",T.inOrder2());
		System.out.println(T.inOrder2());
		assertTrue(T.addNode2(5));
		assertEquals("5:BF=0\t10:BF=0\t25:BF=0\t50:BF=-1\t75:BF=0\t",T.inOrder2());
		System.out.println(T.inOrder2());
	}

}
