package ColasPrioridad;

import Exceptions.ElementNotPresentException;

public class BinaryHeap <T extends Comparable <T>> implements PriorityQueue<T>
{
	private T[] monticulo; // vector de elementos de una determinada dimension
	private int numElementos; // numeros de elementos insertados en el vector
	
	@SuppressWarnings("unchecked")
	public BinaryHeap(int n)
	{
		this.monticulo = (T[]) new Comparable[n];
		this.numElementos = 0;
	}
	
	/**
	 * Si recibe como parametro un valor null, lanza una excepcion del tipo NullPointerException.
	 * Si no cabe, no lo inserta retorna false.
	 * true si inserta la clave.
	 * false si ya existe (no lo inserta)
	 */
	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(monticulo.length == numElementos || search(elemento) != null)
		{
			return false;
		}
		
		if(numElementos == 0)
		{
			monticulo[numElementos] = elemento;
			numElementos++;
		} else
		{
			monticulo[numElementos] = elemento;
			numElementos++;
		}
		
		filtradoAscendente(numElementos-1); // de abajo a arriba
		
		return true;
	}

	private Object search(T elemento)
	{
		for(int i = 0; i < monticulo.length; i++)
		{
			if(monticulo[i] != null && monticulo[i].compareTo(elemento) == 0)
			{
				return monticulo[i];
			}
		}
		return null;
	}

	/**
	 * @return saca el elemento de la raiz y lo borra.
	 * Null, si la cola esta vacia
	 */
	@Override
	public T sacar()
	{
		T res = monticulo[0]; // guardamos la raiz en una variable local
		monticulo[0] = monticulo[numElementos-1]; // colocar el ultimo elemento del vector en la raiz y realizar un filtrado descendente
		monticulo[numElementos-1] = null; // eliminamos el sustituto de la anterior raiz para que no haya duplicados
		numElementos--; // disminuimos el numero de elementos insertados
		filtradoDescendente(0); // realizamos el filtrado descendente desde la raiz
		return res; // retornamos la raiz inicial
	}

	/**
	 * Colocar el �ltimo elemento del vector en la posici�n del elemento a borrar
	 * Realizar un filtrado descendente o filtrado ascendente desde la posici�n del elemento a borrar, 
	 * dependiendo de lo siguiente:
	 * 		Si el valor del �ltimo elemento es menor que el original => filtrado ascendente
	 * 		Si el valor del �ltimo elemento es mayor que el original => filtrado descendente
	 */
	@Override
	public boolean remove(T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(search(elemento) == null) // elemento no presente en la estructura
		{
			throw new ElementNotPresentException(elemento);
		}
		if(numElementos == 0) // cola vacia...
		{
			return false;
		}
		
		// eliminamos
		// el elemento que va a ser borrado es el pasado por parametro
		int initialPos = indexOfElement(elemento); // guardamos la posicion del elemento a borrar
		
		monticulo[initialPos] = monticulo[numElementos-1]; // ponemos el ultimo elemento en la posicion del elemento a borrar
		monticulo[numElementos-1] = null; // borramos el ultimo elemento del monticulo
		numElementos--; // disminuimos el numero de elementos insertados
		T nuevoElemento = monticulo[0];
		
		if(nuevoElemento.compareTo(elemento) < 0) // si el valor del nuevo elemento es menor que el original...
		{
			filtradoAscendente(initialPos);
		} else if(nuevoElemento.compareTo(elemento) > 0) // si el valor del nuevo elemento es mayor que el original...
		{
			filtradoDescendente(initialPos);
		}
		
		return true;
	}
	
	private int indexOfElement(T elemento)
	{
		for(int i = 0; i < monticulo.length; i++)
		{
			if(monticulo[i] != null && monticulo[i].compareTo(elemento) == 0)
			{
				return i;
			}
		}
		return -1;
	}

	@Override
	public boolean isEmpty()
	{
		return this.numElementos == 0;
	}

	@Override
	public void clear()
	{
		for(int i = 0; i < monticulo.length; i++)
		{
			monticulo[i] = null;
		}
		numElementos = 0;
	}

	/**
	 * Cambia la prioridad de un elemento que se encuentra en la posicion pos por la que se pasa como parametro.
	 * Devuelve:
	 * 		Si recibe como parametro un valor null, no lo inserta y lanza una excepcion del tipo NullPointerException
	 * 		Si no existe la clave lanza una excepcion del tipo ElementNotPresentException
	 * 		true si cambia la prioridad
	 * 		false si la cola esta vacia
	 */
	@Override
	public boolean cambiarPrioridad(int pos, T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(pos < 0 || pos >= numElementos || numElementos == 0)
		{
			return false;
		}
		if(search(elemento) == null) // elemento no presente en la estructura
		{
			throw new ElementNotPresentException(elemento);
		}
		
		// la posicion del elemento a modificar me da la pos
		// el sustituto es el que me pasan por parametro
		T anterior = monticulo[pos];
		monticulo[pos] = elemento;
		
		if(elemento.compareTo(anterior) < 0) // sustituto < anterior...
		{
			filtradoAscendente(pos);
		} else
		{
			filtradoDescendente(pos);
		}
		
		return true;
	}
	
	/**
	 * Elementos separados por tabuladores. No hay tabulador al final.
	 */
	public String toString()
	{
		String res = "";
		for(int i = 0; i < monticulo.length; i++)
		{
			if(monticulo[i] == null)
			{
				res = res + "";
			} else
			{
				res = res + monticulo[i] + "\t";
			}
		}
		return res.substring(0, res.length()-1);
	}
	
	/**
	 * Filtrado ascendente a partir de la posicion pasada como parametro. 
	 * Es necesario realizarlo cada vez que se inserta un nuevo elemento o cuando se borra
	 * 
	 * Si el elemento insertado es menor que su padre entonces intercambiarlos
	 * Realizar la operacion mientras el padre sea mayor que el hijo o elemento insertado y no hayamos alcanzado la raiz
	 * El padre estara en la posicion E[(i � 1)/2]
	 */
	private void filtradoAscendente(int pos)
	{
		// tenemos los hijos y debemos calcular el padre (vamos de abajo a arriba)
		int pos_hijo = pos; // suponemos que la posicion siempre es la del hijo izquierdo porque es el hijo comun a todos los padres al contrario que el hijo derecho
		int pos_padre = (pos_hijo-1)/2; // calculamos la posicion del padre
		
		while(pos_hijo >= 1 /* mientras el hijo no lo sea de la raiz */ &&
				monticulo[pos_padre].compareTo(monticulo[pos_hijo]) > 0 /* padre mayor que su hijo */)
		{
			T aux = monticulo[pos_padre];
			monticulo[pos_padre] = monticulo[pos_hijo];
			monticulo[pos_hijo] = aux;
			
			pos_hijo = pos_padre;
			pos_padre = (pos_hijo-1) / 2;
		}
	}
	
	/**
	 * Filtrado descendente a partir de la posicion pasada como parametro. 
	 * Es necesario realizarlo cada vez que se borra un elemento o se invoca al metodo sacar
	 * 
	 * Si el padre es mayor que uno de sus hijos entonces intercambiarlo.
	 * Si el padre tiene dos hijos y es mayor que los dos entonces intercambiarlo por el menor de los hijos
	 * Realizar la operacion anterior mientras el padre sea mayor que alguno de sus hijos o los dos y ademas no sea hoja
	 * El hijo izquierdo, si existe, estara en la posicion 2*i + 1
	 * El hijo derecho, si existe, estara en la posicion 2*i + 2
	 */
	private void filtradoDescendente(int pos)
	{
		// tenemos el padre y tenemos que calcular los hijos (vamos de arriba a abajo)
		int pos_padre = pos;
		int pos_hijo_izq = 2*pos + 1;
		int pos_hijo_der = 2*pos + 2;
		
		while(pos_hijo_izq < numElementos /* hijo izq no es hoja */ && 
				monticulo[pos_hijo_izq] != null /* si el hijo izq no existe tampoco existe el derecho */ &&
				(monticulo[pos_padre].compareTo(monticulo[pos_hijo_izq]) > 0 || monticulo[pos_padre].compareTo(monticulo[pos_hijo_der]) > 0))
		{
			T aux = monticulo[pos_padre];
			int pos_aux = pos_padre;
			
			// intercambio la posicion del padre con la posicion del menor de los hijos
			if(monticulo[pos_hijo_der].compareTo(monticulo[pos_hijo_izq]) < 0 /* hijo derecho menor que el izquierdo */ &&
					monticulo[pos_hijo_der].compareTo(monticulo[pos_padre]) < 0 /* hijo derecho menor que el padre */) // <=> el hijo derecho es el menor de los hijos...
			{
				// intercambio...
				monticulo[pos_padre] = monticulo[pos_hijo_der];
				monticulo[pos_hijo_der] = aux;
				pos_padre = pos_hijo_der;
				pos_hijo_der = pos_aux;
			} else if(monticulo[pos_hijo_izq].compareTo(monticulo[pos_hijo_der]) < 0 /* hijo izquierdo menor que el derecho */ &&
					monticulo[pos_hijo_izq].compareTo(monticulo[pos_padre]) < 0 /* hijo izquierdo es menir que el padre */) // <=> el hijo izquierdo es el menor de los hijos...
			{
				// intercambio...
				monticulo[pos_padre] = monticulo[pos_hijo_izq];
				monticulo[pos_hijo_izq] = aux;
				pos_padre = pos_hijo_izq;
				pos_hijo_izq = pos_aux;
			}
			
			pos_hijo_izq = 2*pos_padre + 1;
			pos_hijo_der = 2*pos_padre + 2;
		}
	}
	
	//-------------------------------------------------------------------------------------------------------//
	
	/**
	 * Si recibe como parametro un valor null, lanza una excepcion del tipo NullPointerException. --
	 * Si no cabe, no lo inserta retorna false. --
	 * true si inserta la clave.
	 * false si ya existe (no lo inserta) --
	 */
	@Override
	public boolean add2(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element to insert is null.");
		if(numElementos == monticulo.length) // monticulo lleno
			return false;
		
		if(isEmpty2())
		{
			monticulo[0] = elemento;
			numElementos++;
			return true;
		} else
		{
			if(search2(elemento) != null) // clave ya existente
				return false;
			monticulo[numElementos] = elemento; // insertamos el elemento
			numElementos++;
			
			filtradoAscendente(numElementos-1);
			return true;
		}
	}
	
	/**
	 * @return saca el elemento de la raiz, se sustituye por el ultimo elemento del monticulo y se retorna la
	 * raiz original.
	 * Null, si la cola esta vacia
	 */
	@Override
	public T sacar2()
	{
		if(isEmpty2())
			return null;
		else
		{
			T anterior = monticulo[0]; // anterior raiz
			monticulo[0] = monticulo[numElementos-1]; // sustituimos la raiz por el ultimo elemento del monticulo
			monticulo[numElementos-1] = null; // borramos el ultimo elemento para que no haya elementos repetidos
			numElementos--;
			filtradoDescendente(0); // aplicamos el filtrado descendente desde la nueva raiz del monticulo
			return anterior; // retornamos la raiz original
		}
	}
	
	private Object search2(T elemento)
	{
		for(int i = 0; i < numElementos; i++)
		{
			if(elemento.compareTo(monticulo[i]) == 0)
				return monticulo[i];
		}
		return null;
	}
	
	/**
	 * Colocar el ultimo elemento del vector en la posicion del elemento a borrar
	 * Realizar un filtrado descendente o filtrado ascendente desde la posicion del elemento a borrar, 
	 * dependiendo de lo siguiente:
	 * 		Si el valor del ultimo elemento es menor que el original => filtrado ascendente
	 * 		Si el valor del ultimo elemento es mayor que el original => filtrado descendente
	 */
	@Override
	public boolean remove2(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element to insert is null.");
		
		if(isEmpty2())
			return false;
		else if(search2(elemento) == null) // elemento no existente en la estructura
			throw new ElementNotPresentException(elemento);
		else
		{
			int indice_borrar = indexOfElement2(elemento); // calculamos la posicion del elemento a ser borrado
			
			T anterior = elemento; // hacemos una copia del elemento que va a ser borrado
			T sustituto = monticulo[numElementos-1]; // hacemos una copia del elemento que va a sustituir al elemento a borrar
			
			monticulo[indice_borrar] = monticulo[numElementos-1]; // machacamos el elemento a borrar en el monticulo con el ultimo elemento de este
			monticulo[numElementos-1] = null; // borramos el ultimo elemento del monticulo
			numElementos--;
			
			if(sustituto.compareTo(anterior) < 0)
				filtradoAscendente2(indice_borrar);
			else if(sustituto.compareTo(anterior) > 0)
				filtradoDescendente2(indice_borrar);
			return true;
		}
	}
	
	private int indexOfElement2(T elemento)
	{
		for(int i = 0; i < numElementos; i++)
		{
			if(elemento.compareTo(monticulo[i]) == 0)
				return i;
		}
		return -1;
	}

	@Override
	public boolean isEmpty2()
	{
		return numElementos == 0;
	}
	
	@Override
	public void clear2()
	{
		for(int i = 0; i < monticulo.length; i++)
			monticulo[i] = null;
		numElementos = 0;
	}
	
	/**
	 * Cambia la prioridad de un elemento que se encuentra en la posicion pos por la que se pasa como parametro.
	 * Devuelve:
	 * 		Si recibe como parametro un valor null, no lo inserta y lanza una excepcion del tipo NullPointerException
	 * 		Si no existe la clave lanza una excepcion del tipo ElementNotPresentException
	 * 		true si cambia la prioridad
	 * 		false si la cola esta vacia
	 * 
	 * Sustituyes el elemento de la posicion pasada por parametro por el elemento pasado por parametro
	 */
	@Override
	public boolean cambiarPrioridad2(int pos, T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element to insert is null.");
		if(pos < 0 || pos >= numElementos || numElementos == 0)
			return false;
		else if(search2(elemento) == null) // elemento no existente en la estructura
			throw new ElementNotPresentException(elemento);
		else
		{
			T anterior = monticulo[pos]; // hacemos copia del elemento que va a ser sustituido
			T sustituto = elemento;
			
			monticulo[pos] = sustituto;
			
			if(sustituto.compareTo(anterior) < 0)
				filtradoAscendente2(pos);
			else if(sustituto.compareTo(anterior) > 0)
				filtradoDescendente2(pos);
			return true;
		}
	}
	
	/**
	 * Filtrado ascendente a partir de la posicion pasada como parametro. 
	 * Es necesario realizarlo cada vez que se inserta un nuevo elemento o cuando se borra
	 * 
	 * Si el elemento insertado es menor que su padre entonces intercambiarlos
	 * Realizar la operacion mientras el padre sea mayor que el hijo o elemento insertado y no hayamos alcanzado la raiz
	 * El padre estara en la posicion E[(i � 1)/2]
	 */
	private void filtradoAscendente2(int pos)
	{
		// de abajo a arriba (tenemos los hijos y debemos calcular el padre)
		int pos_hijo = pos; // la posicion pasada es la del hijo
		int pos_padre = (pos_hijo-1) / 2; // calculamos la posicion del padre
		
		while(pos_hijo != 0 &&
				monticulo[pos_padre].compareTo(monticulo[pos_hijo]) > 0)
		{
			// intercambio
			T padre = monticulo[pos_padre];
			monticulo[pos_padre] = monticulo[pos_hijo];
			monticulo[pos_hijo] = padre;
			
			pos_hijo = pos_padre;
			pos_padre = (pos_hijo-1) / 2;
		}
	}
	
	/**
	 * Filtrado descendente a partir de la posicion pasada como parametro. 
	 * Es necesario realizarlo cada vez que se borra un elemento o se invoca al metodo sacar
	 * 
	 * Si el padre es mayor que uno de sus hijos entonces intercambiarlo.
	 * Si el padre tiene dos hijos y es mayor que los dos entonces intercambiarlo por el menor de los hijos
	 * Realizar la operacion anterior mientras el padre sea mayor que alguno de sus hijos o los dos y ademas no sea hoja
	 * El hijo izquierdo, si existe, estara en la posicion 2*i + 1
	 * El hijo derecho, si existe, estara en la posicion 2*i + 2
	 */
	private void filtradoDescendente2(int pos)
	{
		// de arriba a abajo (tenemos el padre y calculamos los hijos)
		int pos_padre = pos; // la posicion pasada es la del padre
		int pos_hijo_izq = 2*pos_padre + 1;
		int pos_hijo_der = 2*pos_padre + 2;
		
		while(pos_hijo_izq < numElementos &&
				monticulo[pos_hijo_izq] != null &&
				 (monticulo[pos_padre].compareTo(monticulo[pos_hijo_izq]) > 0 || monticulo[pos_padre].compareTo(monticulo[pos_hijo_der]) > 0))
		{
			T padre = monticulo[pos_padre];
			int pos_aux = pos_padre;
			
			if(monticulo[pos_padre].compareTo(monticulo[pos_hijo_izq]) > 0 /* si el padre es mayor que el hijo izq */ &&
					monticulo[pos_hijo_der].compareTo(monticulo[pos_hijo_izq]) > 0 /* y el hijo izq es el menor */)
			{
				// intercambiar con el izq
				monticulo[pos_padre] = monticulo[pos_hijo_izq];
				monticulo[pos_hijo_izq] = padre;
				
				pos_padre = pos_hijo_izq;
				pos_hijo_izq = pos_aux;
			} else if(monticulo[pos_padre].compareTo(monticulo[pos_hijo_der]) > 0 /* si el padre es mayor que el hijo der */ &&
					monticulo[pos_hijo_izq].compareTo(monticulo[pos_hijo_der]) > 0 /* y el hijo der es el menor */)
			{
				// intercambiar con el der
				monticulo[pos_padre] = monticulo[pos_hijo_der];
				monticulo[pos_hijo_der] = padre;
				
				pos_padre = pos_hijo_der;
				pos_hijo_der = pos_aux;
			}
			
			pos_hijo_izq = 2*pos_padre + 1;
			pos_hijo_der = 2*pos_padre + 2;
		}
	}
}
