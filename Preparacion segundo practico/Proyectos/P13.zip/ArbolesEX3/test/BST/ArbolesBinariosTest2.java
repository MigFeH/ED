package BST;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ArbolesBinariosTest2{

	@Test
	public void T1_addNode2() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		assertTrue(b.addNode2(10));
		assertTrue(b.addNode2(100));
		assertTrue(b.addNode2(60));
		assertTrue(b.addNode2(30));
		assertTrue(b.addNode2(2));
		assertTrue(b.addNode2(-43));
		assertTrue(b.addNode2(70));
		assertTrue(b.addNode2(90));
		assertTrue(b.addNode2(23));
		assertTrue(b.addNode2(43));
		assertTrue(b.addNode2(65));
		assertTrue(b.addNode2(13));
		assertTrue(b.addNode2(230));
		assertTrue(b.addNode2(49));
		assertTrue(b.addNode2(7));
		assertTrue(b.addNode2(40));
		assertTrue(b.addNode2(50));
		assertTrue(b.addNode2(20));
		assertTrue(b.addNode2(15));
		assertTrue(b.addNode2(3));
	
		// Inserta un nodo null
		try {
			b.addNode2(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//A�ade un elemento que ya existe
		assertFalse(b.addNode2(3));
		
		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder2());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230\t",b.preOrder2());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10\t",b.postOrder2());
	}
	
	
	@SuppressWarnings("removal")
	@Test
	public void T2_search2Node() {
		BSTree<Integer> b = new BSTree<Integer>();
		
		//Buscar en un �rbol vac�o
		assertNull(b.search2(50));
		
		assertTrue(b.addNode2(10));
		assertTrue(b.addNode2(100));
		assertTrue(b.addNode2(60));
		assertTrue(b.addNode2(30));
		assertTrue(b.addNode2(2));
		assertTrue(b.addNode2(-43));
		assertTrue(b.addNode2(70));
		assertTrue(b.addNode2(90));
		assertTrue(b.addNode2(23));
		assertTrue(b.addNode2(43));
		assertTrue(b.addNode2(65));
		assertTrue(b.addNode2(13));
		assertTrue(b.addNode2(230));
		assertTrue(b.addNode2(49));
		assertTrue(b.addNode2(7));
		assertTrue(b.addNode2(40));
		assertTrue(b.addNode2(50));
		assertTrue(b.addNode2(20));
		assertTrue(b.addNode2(15));
		assertTrue(b.addNode2(3));
		
		//Busca un nodo que no existe
		assertNull(b.search2(500));
		
		//Buscar un nodo
		assertEquals(b.search2(15).getInfo(), new Integer(15));
		assertEquals(b.search2(43).getInfo(), new Integer(43));
	}
	
	
	@Test
	public void T3_removeNode2() {
		BSTree<Integer> b = new BSTree<Integer>();
		//Intenta borrar de un �rbol vac�o
		assertFalse(b.removeNode2(50));
		
		assertNull(b.search2(50));
		assertTrue(b.addNode2(10));
		assertTrue(b.addNode2(100));
		assertTrue(b.addNode2(60));
		assertTrue(b.addNode2(30));
		assertTrue(b.addNode2(2));
		assertTrue(b.addNode2(-43));
		assertTrue(b.addNode2(70));
		assertTrue(b.addNode2(90));
		assertTrue(b.addNode2(23));
		assertTrue(b.addNode2(43));
		assertTrue(b.addNode2(65));
		assertTrue(b.addNode2(13));
		assertTrue(b.addNode2(230));
		assertTrue(b.addNode2(49));
		assertTrue(b.addNode2(7));
		assertTrue(b.addNode2(40));
		assertTrue(b.addNode2(50));
		assertTrue(b.addNode2(20));
		assertTrue(b.addNode2(15));
		assertTrue(b.addNode2(3));
		
		// Borrar un nodo null
		try {
			b.removeNode2(null);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("Element to insert is null.",e.getMessage());
		}
		
		//Borra un nodo que no existe
		assertFalse(b.removeNode2(500));

		//Recorridos
		assertEquals("-43\t2\t3\t7\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder2());
		assertEquals("10\t2\t-43\t7\t3\t100\t60\t30\t23\t13\t20\t15\t43\t40\t49\t50\t70\t65\t90\t230\t",b.preOrder2());
		assertEquals("-43\t3\t7\t2\t15\t20\t13\t23\t40\t50\t49\t43\t30\t65\t90\t70\t60\t230\t100\t10\t",b.postOrder2());
		
		//Borra un nodo con un hijo: 7 tiene como hijo el 3
		assertTrue(b.removeNode2(7));
		assertEquals("-43\t2\t3\t10\t13\t15\t20\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder2());
				
		//Borra un nodo con un hijo: 20 tiene como hijo al 15
		assertTrue(b.removeNode2(20));
		assertEquals("-43\t2\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder2());
		
		//Borra un nodo con dos hijos: 2 tiene como hijos al -43 y 2
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode2(2));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t100\t230\t",b.inOrder2());
	
		//Borra un nodo con dos sub�rboles: 100
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode2(100));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t60\t65\t70\t90\t230\t",b.inOrder2());
		
		//Borra un nodo con dos sub�rboles: 60
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode2(60));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t40\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder2());

		//Borra una hoja: 40
		assertTrue(b.removeNode2(40));
		assertEquals("-43\t3\t10\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder2());
		
		//Borra la raiz: 10
		assertTrue(b.removeNode2(10));
		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t50\t65\t70\t90\t230\t",b.inOrder2());
		
		//Borra un nodo con dos sub�rboles: 50
		//Busca el mayor del subarbol izquierdo (de los menores)
		assertTrue(b.removeNode2(50));

		assertEquals("-43\t3\t13\t15\t23\t30\t43\t49\t65\t70\t90\t230\t",b.inOrder2());
	}
}
