package AVL.V3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import AVL.AVLTree;

class TestAVLTree
{
	@Test
	void testRSD3()
	{
		AVLTree<Integer> T = new AVLTree<Integer>(); // arbol vacio
		
		assertTrue(T.addNode3(50));
		assertTrue(T.addNode3(25));
		assertTrue(T.addNode3(75));
		assertTrue(T.addNode3(10));
		assertTrue(T.addNode3(30));
		assertTrue(T.addNode3(90));
		
		assertEquals("10:BF=0	25:BF=0	30:BF=0	50:BF=0	75:BF=1	90:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RSD");
		
		assertTrue(T.addNode3(95)); // va a provocar una RSD
		assertEquals("10:BF=0	25:BF=0	30:BF=0	50:BF=0	75:BF=0	90:BF=0	95:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RSD");
		System.out.println();
	}
	
	@Test
	void testRSI3()
	{
		AVLTree<Integer> T = new AVLTree<Integer>(); // arbol vacio
		
		assertTrue(T.addNode3(50));
		assertTrue(T.addNode3(25));
		assertTrue(T.addNode3(75));
		assertTrue(T.addNode3(10));
		
		assertEquals("10:BF=0	25:BF=-1	50:BF=-1	75:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RSI");
		
		assertTrue(T.addNode3(5)); // va a provocar una RSI
		assertEquals("5:BF=0	10:BF=0	25:BF=0	50:BF=-1	75:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RSI");
		System.out.println();
	}
	
	@Test
	void testRDD3()
	{
		AVLTree<Integer> T = new AVLTree<Integer>(); // arbol vacio
		
		assertTrue(T.addNode3(50));
		assertTrue(T.addNode3(25));
		assertTrue(T.addNode3(75));
		assertTrue(T.addNode3(30));
		
		assertEquals("25:BF=1	30:BF=0	50:BF=-1	75:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RDD");
		
		assertTrue(T.addNode3(26)); // va a provocar una RDD
		assertEquals("25:BF=0	26:BF=0	30:BF=0	50:BF=-1	75:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RDD");
		System.out.println();
	}

	@Test
	void testRDI3()
	{
		AVLTree<Integer> T = new AVLTree<Integer>(); // arbol vacio
		
		assertTrue(T.addNode3(50));
		assertTrue(T.addNode3(25));
		assertTrue(T.addNode3(75));
		assertTrue(T.addNode3(60));
		
		assertEquals("25:BF=0	50:BF=1	60:BF=0	75:BF=-1\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RDI");
		
		assertTrue(T.addNode3(65)); // va a provocar una RDI
		assertEquals("25:BF=0	50:BF=1	60:BF=0	65:BF=0	75:BF=0\t", T.inOrder2().toString());
		System.out.println(T.inOrder2().toString() + "\t-Test RDI");
		System.out.println();
	}
}
