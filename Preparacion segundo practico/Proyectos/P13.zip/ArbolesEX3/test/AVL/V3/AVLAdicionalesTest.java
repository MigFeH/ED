package AVL.V3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import AVL.AVLNode;
import AVL.AVLTree;

class AVLAdicionalesTest
{
	
	@Test
	void padreDe3Test()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode3(N5.getInfo()));
		assertTrue(b.addNode3(N3.getInfo()));
		assertTrue(b.addNode3(N7.getInfo()));
		
		assertEquals(b.search3(N5.getInfo()), b.padreDe3(N3.getInfo()));
		assertEquals(b.search3(N5.getInfo()), b.padreDe3(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode3(N10.getInfo()));
		assertTrue(b.addNode3(N6.getInfo()));
		
		assertEquals(b.search3(N7.getInfo()), b.padreDe3(N10.getInfo()));
	}
	
	@Test
	void numAristas3Test()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode3(N5.getInfo()));
		assertTrue(b.addNode3(N3.getInfo()));
		assertTrue(b.addNode3(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode3(N10.getInfo()));
		assertTrue(b.addNode3(N6.getInfo()));
		
		assertEquals(2, b.numAristas3(N5.getInfo(), N10.getInfo()));
		assertEquals(1, b.numAristas3(N7.getInfo(), N10.getInfo()));
		assertEquals(0, b.numAristas3(N7.getInfo(), N7.getInfo()));
		
		AVLNode<Integer> N1 = new AVLNode<Integer>(1);
		AVLNode<Integer> N4 = new AVLNode<Integer>(4);
		
		assertTrue(b.addNode3(N1.getInfo()));
		assertTrue(b.addNode3(N4.getInfo()));
		
		assertEquals(2, b.numAristas3(N5.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas3(N3.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas3(N3.getInfo(), N4.getInfo()));
		assertEquals(2, b.numAristas3(N5.getInfo(), N4.getInfo()));
		
		AVLNode<Integer> N8 = new AVLNode<Integer>(8);
		AVLNode<Integer> N12 = new AVLNode<Integer>(12);
		
		assertTrue(b.addNode3(N8.getInfo()));
		assertTrue(b.addNode3(N12.getInfo()));
		
		assertEquals(1, b.numAristas3(N10.getInfo(), N8.getInfo()));
		assertEquals(1, b.numAristas3(N10.getInfo(), N12.getInfo()));
		assertEquals(2, b.numAristas3(N7.getInfo(), N8.getInfo()));
		assertEquals(2, b.numAristas3(N7.getInfo(), N12.getInfo()));
		assertEquals(3, b.numAristas3(N5.getInfo(), N8.getInfo()));
		assertEquals(3, b.numAristas3(N5.getInfo(), N12.getInfo()));
	}

}
