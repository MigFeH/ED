package AVL.V1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import AVL.AVLTree;

class TestTreeRotaciones {

	@Test
	void testRSD() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode(50));
		assertTrue(T.addNode(25));
		assertTrue(T.addNode(75));
		assertTrue(T.addNode(10));
		assertTrue(T.addNode(30));
		assertTrue(T.addNode(90));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=1\t90:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
		assertTrue(T.addNode(95));
		assertEquals("10:BF=0\t25:BF=0\t30:BF=0\t50:BF=0\t75:BF=0\t90:BF=0\t95:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());

	}

	@Test
	void testRSI() {
		AVLTree<Integer> T = new AVLTree<Integer>();
		assertTrue(T.addNode(50));
		assertTrue(T.addNode(25));
		assertTrue(T.addNode(75));
		assertTrue(T.addNode(10));
		assertEquals("10:BF=0\t25:BF=-1\t50:BF=-1\t75:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
		assertTrue(T.addNode(5));
		assertEquals("5:BF=0\t10:BF=0\t25:BF=0\t50:BF=-1\t75:BF=0\t",T.inOrder());
		System.out.println(T.inOrder());
	}
}
