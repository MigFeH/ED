package BST;

public class BSTree <T extends Comparable <T>>
{
	private BSTNode<T> raiz; // nodo raiz del arbol (el contenido de la raiz del arbol BST)
	
	public BSTree()
	{
		this.raiz = null;
	}
	
	/**
	 * @param clave
	 * @return NullPointerException, si la clave es null.
	 * nodo completo, si lo encuentra.
	 * null, si no lo encuentra o el arbol es null
	 */
	public BSTNode<T> search(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(this.raiz == null)
		{
			return null;
		}
		
		return searchRec(raiz, clave);
	}
	
	/**
	 * @param nodo
	 * @param clave
	 * @return null, si no encuentra la clave.
	 * nodo completo, si la encuentra
	 */
	private BSTNode<T> searchRec(BSTNode<T> nodo, T clave)
	{
		// la recursividad se para cuando la clave del nodo es null
		if(nodo == null)
		{
			return null;
		}
			
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			return searchRec(nodo.getLeft(), clave);
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			return searchRec(nodo.getRight(), clave);
		}
		return nodo;
	}

	/**
	 * @param clave
	 * @return NullPointerException, si clave es null.
	 * false, si la clave ya existe (no la inserta).
	 * true, si inserta la clave
	 */
	public boolean addNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(this.raiz == null)
		{
			this.raiz = new BSTNode<T>(clave);
			return true;
		}
		
		return addNodeRec(this.raiz, clave);
	}
	
	private boolean addNodeRec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) == 0) // clave existente en el arbol...
		{
			return false;
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null)
			{
				nodo.setLeft(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNodeRec(nodo.getLeft(), clave);
			}
		} 
		else /*if(clave.compareTo(nodo.getInfo()) > 0)*/ // clave a la der
		{
			if(nodo.getRight() == null)
			{
				nodo.setRight(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNodeRec(nodo.getRight(), clave);
			}
		}
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder()
	{
		return preOrderRec(raiz);
	}

	private String preOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return nodo.toString() + "\t" + preOrderRec(nodo.getLeft()) + preOrderRec(nodo.getRight());
	}

	/**
	 * izq, der, raiz
	 */
	public String postOrder()
	{
		return postOrderRec(raiz);
	}

	private String postOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return postOrderRec(nodo.getLeft()) + postOrderRec(nodo.getRight()) + nodo.toString() + "\t";
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder()
	{
		return inOrderRec(raiz);
	}
	
	private String inOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return inOrderRec(nodo.getLeft()) + nodo.toString() + "\t" + inOrderRec(nodo.getRight());
	}

	/**
	 * @param clave
	 * @return NullPointerException, clave pasada null.
	 * false, si el arbol es null (raiz es null) o si la clave no existe en el arbol;
	 * true, si borra la clave
	 */
	public boolean removeNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(this.raiz == null || search(clave) == null)
		{
			return false;
		}
		
		this.raiz = removeRec(raiz, clave);
		return true;
	}

	private BSTNode<T> removeRec(BSTNode<T> nodo, T clave)
	{
		/*
		 * Se recorre todo el arbol binario hasta que se encuentra el nodo a borrar
		 * 
		 * 1. Nodo a borrar con solo hijo izq
		 * 2. Nodo a borrar con solo hijo der
		 * 3. Nodo a borrar sin hijos -> se borra el nodo tal cual
		 * 4. Nodo a borrar con los dos hijos -> el sustituto es el mayor del subarbol izquierdo
		 */
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeRec(nodo.getLeft(), clave));
			return nodo;
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeRec(nodo.getRight(), clave));
			return nodo;
		}
		
		
		//--------- NODO ENCONTRADO ---------//

		if(nodo.getLeft() != null && nodo.getRight() == null) // solo hijo izq
		{
			return nodo.getLeft();
		}

		if(nodo.getRight() != null && nodo.getLeft() == null) // solo hijo der
		{
			return nodo.getRight();
		}

		if(nodo.getLeft() != null && nodo.getRight() != null) // hijo izq y der
		{
			BSTNode<T> mayor = mayorDelSubarbol(nodo.getLeft());
			nodo.setInfo(mayor.getInfo());
			BSTNode<T> aux = removeRec(nodo.getLeft(), mayor.getInfo());
			nodo.setLeft(aux);
			return nodo;
		}
		
		return null;
	}

	private BSTNode<T> mayorDelSubarbol(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
		{
			nodo = nodo.getRight();
		}
		return nodo;
	}
	
	//-------------------------------------------------------------------------------------------------------//
	
	/**
	 * @param clave
	 * @return NullPointerException, si la clave es null.
	 * nodo completo, si lo encuentra.
	 * null, si no lo encuentra o el arbol es null
	 */
	public BSTNode<T> search2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null) // arbol es null
			return null;
		return search2Rec(raiz, clave);
	}
	
	private BSTNode<T> search2Rec(BSTNode<T> nodo, T clave)
	{
		if(nodo == null) // nodo no encontrado
			return null;
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
			return search2Rec(nodo.getLeft(), clave);
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
			return search2Rec(nodo.getRight(), clave);
		
		return nodo; // nodo encontrado
	}

	/**
	 * @param clave
	 * @return NullPointerException, si clave es null.
	 * false, si la clave ya existe (no la inserta).
	 * true, si inserta la clave
	 */
	public boolean addNode2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(search2(clave) != null) // clave ya existente
			return false;
		if(raiz == null) // arbol vacio
		{
			raiz = new BSTNode<T>(clave);
			return true;
		}
		return addNode2Rec(raiz, clave);
	}
	
	private boolean addNode2Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null) // hijo izq libre
			{
				nodo.setLeft(new BSTNode<T>(clave));
				return true;
			}
			return addNode2Rec(nodo.getLeft(), clave);
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			if(nodo.getRight() == null) // hijo der libre
			{
				nodo.setRight(new BSTNode<T>(clave));
				return true;
			}
			return addNode2Rec(nodo.getRight(), clave);
		}
		return false;
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder2()
	{
		return preOrder2Rec(raiz);
	}
	
	private String preOrder2Rec(BSTNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return nodo.toString() + "\t" + preOrder2Rec(nodo.getLeft()) + preOrder2Rec(nodo.getRight());
	}

	/**
	 * izq, der, raiz
	 */
	public String postOrder2()
	{
		return postOrder2Rec(raiz);
	}
	
	private String postOrder2Rec(BSTNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return postOrder2Rec(nodo.getLeft()) + postOrder2Rec(nodo.getRight()) + nodo.toString() + "\t";
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder2()
	{
		return inOrder2Rec(raiz);
	}
	
	private String inOrder2Rec(BSTNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return inOrder2Rec(nodo.getLeft()) + nodo.toString() + "\t" + inOrder2Rec(nodo.getRight());
	}

	/**
	 * @param clave
	 * @return NullPointerException, clave pasada null.
	 * false, si el arbol es null (raiz es null) o si la clave no existe en el arbol;
	 * true, si borra la clave
	 */
	public boolean removeNode2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null || search2(clave) == null)
			return false;
		this.raiz = removeNode2Rec(raiz, clave);
		return true;
	}

	private BSTNode<T> removeNode2Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeNode2Rec(nodo.getLeft(), clave));
			return nodo;
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeNode2Rec(nodo.getRight(), clave));
			return nodo;
		} else
		{	
			if(nodo.getLeft() != null && nodo.getRight() == null)
				return nodo.getLeft();
			
			if(nodo.getLeft() == null && nodo.getRight() != null)
				return nodo.getRight();
			
			if(nodo.getLeft() != null && nodo.getRight() != null)
			{
				BSTNode<T> mayor = mayorDelSubarbol2(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				nodo.setLeft(removeNode2Rec(nodo.getLeft(), mayor.getInfo()));
				return nodo;
			}
			return null; // no tiene hijos
		}
	}

	private BSTNode<T> mayorDelSubarbol2(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
			nodo = nodo.getRight();
		return nodo;
	}
	
	//-------------------------------------------------------------------------------------------------------//

	/**
	 * @param clave
	 * @return NullPointerException, si la clave es null.
	 * nodo completo, si lo encuentra.
	 * null, si no lo encuentra o el arbol es null
	 */
	public BSTNode<T> search3(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null)
			return null;
		return search3Rec(raiz, clave);
	}
	
	private BSTNode<T> search3Rec(BSTNode<T> nodo, T clave)
	{
		if(nodo == null)
		{
			return null;
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			return search3Rec(nodo.getLeft(), clave);
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			return search3Rec(nodo.getRight(), clave);
		} else if(clave.compareTo(nodo.getInfo()) == 0) // clave encontrada
		{
			return nodo;
		}
		return null;
	}

	/**
	 * @param clave
	 * @return NullPointerException, si clave es null.
	 * false, si la clave ya existe (no la inserta).
	 * true, si inserta la clave
	 */
	public boolean addNode3(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(search3(clave) != null)
			return false;
		
		if(raiz == null)
		{
			raiz = new BSTNode<T>(clave);
			return true;
		}
		return addNode3Rec(raiz, clave);
	}
	
	private boolean addNode3Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null) // hay hueco
			{
				nodo.setLeft(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNode3Rec(nodo.getLeft(), clave);
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			if(nodo.getRight() == null) // hay hueco
			{
				nodo.setRight(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNode3Rec(nodo.getRight(), clave);
			}
		}
		
		return false; // por descarte
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder3()
	{
		return preOrder2Rec(raiz);
	}
	
	/**
	 * izq, der, raiz
	 */
	public String postOrder3()
	{
		return postOrder2Rec(raiz);
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder3()
	{
		return inOrder2Rec(raiz);
	}

	/**
	 * @param clave
	 * @return NullPointerException, clave pasada null.
	 * false, si el arbol es null (raiz es null) o si la clave no existe en el arbol;
	 * true, si borra la clave
	 */
	public boolean removeNode3(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null || search3(clave) == null) // elemento no existente en la estructura
			return false;
		raiz = removeNode3Rec(raiz, clave);
		return true;
	}

	private BSTNode<T> removeNode3Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeNode3Rec(nodo.getLeft(), clave));
			return nodo; // retornamos el nodo actualizado
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeNode3Rec(nodo.getRight(),clave));
			return nodo; // retornamos el nodo actualizado
		} else // clave encontrada
		{
			/*
			 * 1.Nodo sin hijos => se borra tal cual
			 * 2.Nodo con solo un hijo => su sustituto es dicho hijo
			 * 3.Nodo con ambos hijos => su sutituto es el mayor del subarbol izquierdo
			 */
			if(nodo.getLeft() != null && nodo.getRight() == null)
				return nodo.getLeft();
			
			if(nodo.getLeft() == null && nodo.getRight() != null)
				return nodo.getRight();
			
			if(nodo.getLeft() != null && nodo.getRight() != null)
			{
				BSTNode<T> mayor = mayorDelSubarbol3(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				nodo.setLeft(removeNode3Rec(nodo.getLeft(), mayor.getInfo()));
				return nodo;
			}	
			return null;
		}
	}

	private BSTNode<T> mayorDelSubarbol3(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
			nodo = nodo.getRight();
		return nodo;
	}
	
	//-------------------------------------------------------------------------------------------------------//

	/**
	 * @param clave
	 * @return NullPointerException, si la clave es null.
	 * nodo completo, si lo encuentra.
	 * null, si no lo encuentra o el arbol es null
	 */
	public BSTNode<T> search4(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null)
			return null;
		return search4Rec(raiz, clave);
	}
	
	private BSTNode<T> search4Rec(BSTNode<T> nodo, T clave)
	{
		if(nodo != null) // si el nodo no es null => podemos seguir buscando
		{
			if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
			{
				return search4Rec(nodo.getLeft(), clave);
			}

			if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
			{
				return search4Rec(nodo.getRight(), clave); // retorna lo que haya encontrado
			}
		}
		return nodo; // clave encontrada
	}

	/**
	 * @param clave
	 * @return NullPointerException, si clave es null.
	 * false, si la clave ya existe (no la inserta).
	 * true, si inserta la clave
	 */
	public boolean addNode4(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null)
		{
			raiz = new BSTNode<T>(clave);
			return true;
		}else if(search4(clave) != null) // clave existente en la estructura
		{
			return false;
		}
		return addNode4Rec(raiz, clave);
	}
	
	private boolean addNode4Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null) // hay hueco
			{
				nodo.setLeft(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNode4Rec(nodo.getLeft(), clave);
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			if(nodo.getRight() == null) // hay hueco
			{
				nodo.setRight(new BSTNode<T>(clave));
				return true;
			} else
			{
				return addNode4Rec(nodo.getRight(), clave);
			}
		}
		
		return false; // caso de descarte
	}

	/**
	 * @param clave
	 * @return NullPointerException, clave pasada null.
	 * false, si el arbol es null (raiz es null) o si la clave no existe en el arbol;
	 * true, si borra la clave
	 */
	public boolean removeNode4(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null || search4(clave) == null)
			return false;
		raiz = removeNode4Rec(raiz, clave);
		return true;
	}

	private BSTNode<T> removeNode4Rec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeNode4Rec(nodo.getLeft(), clave));
			return nodo;
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeNode4Rec(nodo.getRight(), clave));
			return nodo;
		} else // clave encontrada
		{
			/*
			 * Si no tiene hijos => se borra tal cual (lo ponemos a null) [retornamos null]
			 * Si solo tiene uno de los hijos => es sustituido por dicho hijo
			 * Si tiene ambos hijos => su sustituto es el mayor del subarbol izquierdo
			 */
			
			if(nodo.getLeft() != null && nodo.getRight() == null)
			{
				return nodo.getLeft();
			}
			
			if(nodo.getLeft() == null && nodo.getRight() != null)
			{
				return nodo.getRight();
			}
			
			if(nodo.getLeft() != null && nodo.getRight() != null)
			{
				BSTNode<T> mayor = mayorDelSubarbol4(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				nodo.setLeft(removeNode4Rec(nodo.getLeft(), mayor.getInfo()));
				return nodo;
			}
			
			return null; // no tiene hijos
		}
	}

	private BSTNode<T> mayorDelSubarbol4(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
			nodo = nodo.getRight();
		return nodo;
	}

}