package Hash;

public abstract class AbstractHash<T>
{
	/*
	 * Se definen las cabeceras de los metodos cuya implementacion dependera de la filosofia de tablas
	 * hash (abiertas o cerradas) y otros metodos comunes a cualquier implementacion
	 */
	
	abstract public int getNumOfElems();
	abstract public int getSize();
	abstract public boolean add(T elemento);
	abstract public HashNode<T> find(T elemento);
	abstract public boolean remove(T elemento);
	abstract public String toString();
	
	protected int fHash(T elemento)
	{
		int pos = elemento.hashCode()%getSize();
		if (pos < 0) return pos+getSize();
		else return pos;
	}
	
	protected boolean isPositivePrime(int numero)
	{
		for(int i = 2; i < numero; i++)
		{
			if(numero % i == 0)
				return false;
		}
		return true;
	}
	
	protected int nextPrimeNumber(int numero)
	{
		int num = numero+1;
		while(!isPositivePrime(num))
			num++;
		return num;
	}
	
	protected int previousPrimeNumber(int numero)
	{
		if(numero <= 3 || isPositivePrime(numero))
			return numero;
		int num = numero-1;
		while(!isPositivePrime(num))
			num--;
		if(num <= 3)
			return 3;
		return num;
	}
	
	abstract protected void reDispersion();
	abstract protected void inverseRedispersion();
	
	public double factorCarga()
	{
		return getNumOfElems()*1.0/getSize(); // numero de elementos insertados en la tabla / dimension de la tabla
	}
	
	//----------------------------------------------------------------------------------------------------------//
	
	abstract public int getNumOfElems2();
	abstract public int getSize2();
	abstract public boolean add2(T elemento);
	abstract public HashNode<T> find2(T elemento);
	abstract public boolean remove2(T elemento);
	
	protected int fHash2(T elemento)
	{
		int pos = elemento.hashCode() % getSize2();
		if(pos < 0)
			return pos + getSize2();
		return pos;
	}
	
	protected boolean isPositivePrime2(int numero)
	{
		for(int i = 2; i < numero; i++)
		{
			if(numero % i == 0)
				return false;
		}
		return true;
	}
	
	protected int nextPrimeNumber2(int numero)
	{
		int intento = 1;
		while(!isPositivePrime2(numero+intento))
			intento++;
		return numero+intento;
	}
	
	protected int previousPrimeNumber2(int numero)
	{
		if(numero <= 3 || isPositivePrime(numero))
			return numero;
		int num = numero-1;
		while(!isPositivePrime(num))
			num--;
		if(num <= 3)
			return 3;
		return num;
	}
	
	abstract protected void reDispersion2();
	abstract protected void inverseRedispersion2();
	
	public double factorCarga2()
	{
		return getNumOfElems2()*1.0/getSize2(); // el FC se calcula como: numero de elementos insertados / dimension de la tabla
	}

	//----------------------------------------------------------------------------------------------------------//
	
	abstract public int getNumOfElems3();
	abstract public int getSize3();
	abstract public boolean add3(T elemento);
	abstract public HashNode<T> find3(T elemento);
	abstract public boolean remove3(T elemento);
	
	protected int fHash3(T elemento)
	{
		int pos = elemento.hashCode() % getSize2();
		if(pos < 0)
			return pos + getSize2();
		return pos;
	}
	
	protected boolean isPositivePrime3(int numero)
	{
		for(int i = 2; i < numero; i++)
		{
			if(numero % i == 0)
				return false;
		}
		return true;
	}
	
	protected int nextPrimeNumber3(int numero)
	{
		int intento = 1;
		while(!isPositivePrime2(numero+intento))
			intento++;
		return numero+intento;
	}
	
	protected int previousPrimeNumber3(int numero)
	{
		if(numero <= 3 || isPositivePrime(numero))
			return numero;
		int num = numero-1;
		while(!isPositivePrime(num))
			num--;
		if(num <= 3)
			return 3;
		return num;
	}
	
	abstract protected void reDispersion3();
	abstract protected void inverseRedispersion3();
	
	public double factorCarga3()
	{
		return getNumOfElems3()*1.0/getSize3(); // el FC se calcula como: numero de elementos insertados / dimension de la tabla
	}
}
