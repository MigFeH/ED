package Hash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Exceptions.ElementNotPresentException;

class ClosedHashTableTest2
{
	@Test
	void testAdd2()
	{
		System.out.println();
		System.out.println("-------- Pruebas de Add2 --------");
		
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add2(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add2(5);
		System.out.println(T.toString());
		// A�ado el 20
		T.add2(20);
		System.out.println(T.toString());
		// A�ado el 19
		T.add2(19);
		System.out.println(T.toString());
		// A�ado el 18
		T.add2(18);
		System.out.println(T.toString());
		// A�ado el 30
		assertTrue(T.add2(30));
		System.out.println(T.toString());
	}
	
	@Test
	void testFind2()
	{
		System.out.println();
		System.out.println("-------- Pruebas de Find2 --------");
		
		// Crear una tabla hash vac�a de tama�o 4 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<>(4, 0);
		// Como 4 no es un n�mero primo me calcula el nuevo tama�o
		System.out.println(T.toString());
		// A�ado el 10
		T.add2(10);
		System.out.println(T.toString());
		// A�ado el 5
		T.add2(5);
		System.out.println(T.toString());
		// A�ado el 19
		T.add2(19);
		System.out.println(T.toString());
		
		HashNode<Integer> Nodo = T.find2(19);
		System.out.println(Nodo.getInfo().toString());
		System.out.println(Nodo.getStatus());
	}
	
	@Test
	void testRemove2() {
		// Crear una tabla hash vac�a de tama�o 11 con tipo de exploraci�n lineal
		ClosedHashTable<Integer> T = new ClosedHashTable<Integer>(11,0);
		T.add2(2);
		T.add2(11);
		T.add2(13);
		T.add2(24);
		System.out.println(T.toString());
		
		T.remove2(24);
		System.out.println(T.toString());
		
		try {
			T.remove2(35);
		}catch (ElementNotPresentException e) {
			assertEquals(e.getMessage(), "El elemento 35 no existe en la estructura");
		}
		System.out.println(T.toString());
	}

}
