package tutoriaGrupalGrafos2023;

import java.text.DecimalFormat;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphTG2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf=Double.POSITIVE_INFINITY;
	
	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado

	/**
	 * 
	 * @param tam
	 *            Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphTG2023(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}
	
	protected int getNumNodes() {
		return numNodes;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeTG(T node) {
		for (int i = 0; i < numNodes; i++) {
			if (nodes[i].equals(node)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro.
	 * Siempre lo inserta, no se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeTG(T node) {
		nodes[numNodes] = node;
		for (int i = 0; i <= numNodes; i++) {
			edges[numNodes][i] = false;
			edges[i][numNodes] = false;
		}
		numNodes++;
		return true;
	}


	/**
	 * Inserta una arista entre dos nodos con el peso indicado 
	 * Devuelve true siempre
	 * No comprueba nada. 
	 * @param source
	 *            nodo origen
	 * @param target
	 *            nodo destino
	 * @param edgeWeight
	 *            peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeTG(T source, T target, double edgeWeight) {
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		edges[posOrigen][posDestino] = true;
		weights[posOrigen][posDestino] = edgeWeight;
		return true;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos.
	 * Siempre la borra sin comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeTG(T source, T target) {
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos.
	 * No comprueba nada...
	 *  
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeTG(T source, T target) {
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		return weights[posOrigen][posDestino];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();
		
		cadena.append("NODES\n");
		for (int i = 0; i < numNodes; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena.append((edges[i][j]?df.format(weights[i][j]):"-") + "\t");
			}
			cadena.append("\n");
		}
	
		return cadena.toString();
	}
	
	public boolean isDrainNode(T c) {  
		// Completad el metodo...
		return false;
	}

	public int getNumberOfDrainNodes () {
		// Completad el metodo...
		return -1;
	}
	
	public DijkstraDataClass dijkstra(T nodoOrigen) {
		// Completad el metodo...
		return null;
	}
}
