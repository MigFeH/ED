package tutoriaGrupalGrafos2023;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphTG2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf = Double.POSITIVE_INFINITY;

	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado

	private double[][] A_floyd;
	private int[][] P_floyd;

	/**
	 * 
	 * @param tam Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphTG2023(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}

	protected int getNumNodes() {
		return numNodes;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeTG(T node) {
		int index = 0;
		for (T theNode : nodes) {
			if (theNode != null && theNode.equals(node)) {
				return index;
			}
			index++;
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro. Siempre lo inserta, no
	 * se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeTG(T node) {
		if (node == null) {
			throw new NullPointerException("Nodo a a�adir null");
		}
		if (nodes.length == numNodes) {
			throw new IllegalArgumentException("Nodo a añadir ya existente en el grafo");
		}

		if (numNodes > 0) // si el grafo tiene nodos...
		{
			if (existNode(node)) {
				return false;
			}
		}
		numNodes++;

		// a�adir nodo al vector de nodos
		int index = numNodes - 1;
		nodes[index] = node;

		// poner a false la fila y columna del nodo que se a�ade en la matriz de ejes
		for (int i = 0; i < edges.length; i++) {
			edges[index][i] = false;
			edges[i][index] = false;
		}
		// poner infinitos en la fila y columna del nodo que se a�ade en la matriz de
		// pesos
		for (int i = 0; i < weights.length; i++) {
			weights[index][i] = Inf;
			weights[i][index] = Inf;
		}

		return true;
	}

	/**
	 * Inserta una arista entre dos nodos con el peso indicado Devuelve true siempre
	 * No comprueba nada.
	 * 
	 * @param source     nodo origen
	 * @param target     nodo destino
	 * @param edgeWeight peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeTG(T origen, T destino, double peso)
	{
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if (!existNode(destino))
		{
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if (peso < 0.0)
		{
			throw new IllegalArgumentException("Peso de eje negativo");
		}
		if (existEdge(origen, destino)) // si existe el eje...
		{
			return false;
		} else // sino...
		{
			edges[getNodeTG(origen)][getNodeTG(destino)] = true;
			weights[getNodeTG(origen)][getNodeTG(destino)] = peso;

			return true;
		}
	}

	/**
	 * @param origen  nodo de tipo T
	 * @param destino nodo de tipo
	 * @return true o false en funcion de la existencia del eje que une a los nodos
	 *         pasados por parametro
	 */
	public boolean existEdge(T origen, T destino) {
		// si hay un true en la casilla de ejes (origen, destino) entonces retornamos
		// true
		int index_origen = getNodeTG(origen);
		int index_destino = getNodeTG(destino);

		if (edges[index_origen][index_destino]) {
			return true;
		}
		return false;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos. Siempre la borra sin
	 * comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeTG(T source, T target) {
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos. No comprueba nada...
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeTG(T origen, T destino) {
		if (!existNode(origen)) {
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if (!existNode(destino)) {
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if (!existEdge(origen, destino)) {
			return -1;
		}
		return weights[getNodeTG(origen)][getNodeTG(destino)];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();

		cadena.append("NODES\n");
		for (int i = 0; i < numNodes; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena.append((edges[i][j] ? df.format(weights[i][j]) : "-") + "\t");
			}
			cadena.append("\n");
		}

		return cadena.toString();
	}

	public boolean isDrainNode(T c)
	{
		// El nodo sumidero es aquel que no es el origen de ningun eje pero si el destino
		for(int i = 0; i < numNodes; i++)
		{
			if(existEdge(nodes[i], c) && !c.equals(nodes[i]) && !existEdge(c, nodes[i]))
			{
				return true;
			}
		}

		return false;
	}

	public int getNumberOfDrainNodes()
	{
		// El nodo sumidero es aquel que no es el origen de ningun eje pero si el destino
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isDrainNode(nodes[i]))
			{
				res = res + 1;
			}
		}
		
		return res;
	}

	/**
	 * Calcula el camino de coste minimo desde el nodoOrigen al resto de nodos del
	 * grafo
	 */
	public DijkstraDataClass dijkstra(T nodoOrigen) {
		if (!existNode(nodoOrigen) || nodoOrigen == null) {
			throw new IllegalArgumentException(nodoOrigen + " no existente en el grafo");
		}

		double[] D_dijkstra = inicializar_D_Dijkstra(nodoOrigen); // vector de pesos
		int[] P_dijkstra = inicializar_P_Dijkstra(nodoOrigen); // vector desde que nodo se accede a uno (almacena
																// posiciones)

		boolean[] visitados_dijkstra = inicializar_visitados_dijkstra(nodoOrigen);
		ArrayList<T> S_dijkstra = inicializar_S_dijkstra(nodoOrigen);

		while (!todosVisitadosDijkstra(visitados_dijkstra))
		{
			// Paso 2: buscar nodo w de S-nodos (no visitados) tal que D[w] sea min
			T nodo_pivote = buscarPivoteDijkstra(visitados_dijkstra, D_dijkstra);
			int indice_nodo_pivote = getNodeTG(nodo_pivote);

			// agregar nodo_pivote al conjunto solucion S
			S_dijkstra.add(nodo_pivote);

			// marcar nodo_pivote como vivsitado
			visitados_dijkstra[indice_nodo_pivote] = true;

			// Paso 3: para cada nodo de S-nodos...
			for (int i = 0; i < nodes.length; i++)
			{
				if (!isNodoVisitadoDijkstra(nodes[i], visitados_dijkstra)) // nodo no visitado...
				{
					T nodo_M = nodes[i];
					int indice_nodo_M = getNodeTG(nodo_M);

					if (D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M] < D_dijkstra[indice_nodo_M])
					{
						D_dijkstra[indice_nodo_M] = D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M]; // actualizamos D
						P_dijkstra[indice_nodo_M] = indice_nodo_pivote; // actualizamos P
					}
				}
			}
		}

		return new DijkstraDataClass(numNodes, getNodeTG(nodoOrigen), D_dijkstra, P_dijkstra);
	}

	private boolean isNodoVisitadoDijkstra(T nodo, boolean[] visitados_dijkstra) {
		return visitados_dijkstra[getNodeTG(nodo)];
	}

	private T buscarPivoteDijkstra(boolean[] visitados_dijkstra, double[] d_dijkstra) {
		double aux = Inf;
		T res = null;

		for (int i = 0; i < d_dijkstra.length; i++) {
			if (!visitados_dijkstra[i] && d_dijkstra[i] <= aux) // nodo no visitado
			{
				aux = d_dijkstra[i];
				res = getNodes()[i];
			}
		}
		return res;
	}

	private boolean todosVisitadosDijkstra(boolean[] visitados_dijkstra) {
		for (int i = 0; i < visitados_dijkstra.length; i++) {
			if (!visitados_dijkstra[i]) {
				return false;
			}
		}
		return true;
	}

	private ArrayList<T> inicializar_S_dijkstra(T nodoOrigen) {
		ArrayList<T> res = new ArrayList<>();
		res.add(nodoOrigen);
		return res;
	}

	private boolean[] inicializar_visitados_dijkstra(T nodoOrigen) {
		boolean[] res = new boolean[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getNodeTG(nodoOrigen) == i) {
				res[i] = true;
			}
			res[i] = false;
		}

		return res;
	}

	private int[] inicializar_P_Dijkstra(T nodoOrigen) {
		int[] res = new int[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getEdges()[getNodeTG(nodoOrigen)][i]) // hay eje del nodoOrigen a otro nodo...
			{
				res[i] = getNodeTG(nodoOrigen); // indice del nodoOrigen
			} else // si no hay eje del nodoOrigen a otro nodo o el indice del nodoOrigen es el
					// mismo que i...
			{
				res[i] = -1; // no se llega
			}

		}

		return res;
	}

	private boolean existNode(T nodoOrigen) {
		for (T theNode : nodes) {
			if (theNode != null && theNode.equals(nodoOrigen)) {
				return true;
			}
		}
		return false;
	}

	private double[] inicializar_D_Dijkstra(T nodoOrigen) {
		double[] res = new double[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getNodeTG(nodoOrigen) == i) {
				res[i] = 0; // el peso de ir de un nodo a si mismo es de 0
			} else {
				res[i] = getWeights()[getNodeTG(nodoOrigen)][i]; // dentro de la matriz de pesos la fila del nodo origen
			}
		}

		return res;
	}

	public boolean floyd() {
		if (numNodes == 0) // grafo vacio...
		{
			return false;
		}

		this.A_floyd = inicializar_A_Floyd(); // matriz A de pesos de un nodo a otro
		this.P_floyd = inicializar_P_Floyd(); // matriz P con el indice del nodo desde el que accedemos a otro

		for (int a = 0; a < numNodes; a++) // para cada nodo de nodos...
		{
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					if (i == j) {
						continue;
					}
					if (A_floyd[i][j] > A_floyd[i][a] + A_floyd[a][j]) {
						A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j];
						P_floyd[i][j] = a;
					}
				}
			}
		}
		return true;
	}

	private int[][] inicializar_P_Floyd() {
		int[][] res = new int[numNodes][numNodes];

		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				res[i][j] = -1; // se inicializa con todo a -1
			}
		}

		return res;
	}

	private double[][] inicializar_A_Floyd() {
		double[][] res = new double[numNodes][numNodes];

		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (i == j) // el peso de ir de un nodo al mismo es 0
				{
					res[i][j] = 0;
				} else {
					if (!existEdge(nodes[i], nodes[j])) // si no hay eje entre un nodo y otro --> infinito
					{
						res[i][j] = Inf;
					} else // si hay eje entre los dos nodos --> peso del eje que los une
					{
						res[i][j] = getEdgeTG(nodes[i], nodes[j]);
					}
				}
			}
		}

		return res;
	}

	public double[][] getFloydA() {
		return this.A_floyd;
	}

	public int[][] getFloydP() {
		return this.P_floyd;
	}

	public double minCostPath(T origen, T destino)
	{
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("El elemento " + origen + " no existe en la estructura");
		} else if (!existNode(destino))
		{
			throw new IllegalArgumentException("El elemento " + destino + " no existe en la estructura");
		}

		// tras ejecutar floyd (ya se hace en los test antes de invocar este metodo)
		// buscamos en A_floyd el coste entre el nodo origen y destino
		return getFloydA()[getNodeTG(origen)][getNodeTG(destino)];
	}

	/**
	 * Devuelve el camino de coste minimo que se pasan como parametro usando la
	 * matriz P de Floyd
	 * 
	 * Si el nodo origen es igual al nodo destino: Origen<tab> Si no hay camino
	 * entre el nodo origen y el nodo destino: Origen<tab>(Infinito)<tab>Destino Si
	 * hay camino:
	 * Origen<tab>(coste0)<tab>Intermedio1<tab>(coste1)...IntermedioN<tab>(costeN)<tab>Destino<tab>
	 */
	public String path(T origen, T destino)
	{
		if (!existNode(origen) || !existNode(destino))
		{
			return "";
		}

		String res = origen + "";

		if (getFloydA()[getNodeTG(origen)][getNodeTG(destino)] == Inf) // no hay camino entre origen y destino
		{
			return res + "\t(" + Inf + ")\t" + destino;
		}

		if (origen.equals(destino)) {
			return res;
		}

		return res + recursivePath(origen, destino) + destino;
	}

	private String recursivePath(T origen, T destino)
	{
		if (origen.equals(destino)) {
			return "\t";
		}

		int pos_nodo_origen = getNodeTG(origen);
		int pos_nodo_destino = getNodeTG(destino);

		// hay camino entre origen y destino

		int pos_nodo_intermedio = getFloydP()[pos_nodo_origen][pos_nodo_destino];

		if (pos_nodo_intermedio != -1) // hay nodo intermedio...
		{
			T nodo_intermedio = nodes[pos_nodo_intermedio];
			double coste = getFloydA()[pos_nodo_origen][pos_nodo_intermedio];

			if (coste != Inf) // hay camino al nodo intermedio
			{
				return recursivePath(origen, nodo_intermedio) + nodo_intermedio
						+ recursivePath(nodo_intermedio, destino);
			}

		}

		return "\t(" + getFloydA()[pos_nodo_origen][pos_nodo_destino] + ")\t"; // no hay nodo intermedio, retornamos el coste del origen al destino de la iteracion respectiva (el origen o destino puede ser un nodo intermedio anterior!)...
	}

	public String recorridoProfundidad(T nodoOrigen)
	{
		if(!existNode(nodoOrigen))
		{
			return "";
		}
		
		boolean[] visitados = inicializar_visitados_recorridoProfundidad();
		ArrayList<T> candidatos = new ArrayList<>();
		ArrayList<T> s = new ArrayList<>();
		
		// agregar el nodoOrigen a candidatos
		candidatos.add(nodoOrigen);
		
		
		while(candidatos.size() > 0) // mientras no esten todos vistados...
		{
			T nodo_candidato = candidatos.get(0);
			
			if(visitados[getNodeTG(nodo_candidato)]) // nodo visitado en candidatos se borra de candidatos
			{
				candidatos.remove(0);
			} else
			{
				visitados[getNodeTG(nodo_candidato)] = true;
				
				candidatos.remove(0);
				
				s.add(nodo_candidato);
				
				int posicion = 0;
				
				for(int i = 0; i < numNodes; i++)
				{
					if(getEdgeTG(nodo_candidato, nodes[i]) != -1 && !visitados[i] && !nodo_candidato.equals(nodes[i])) // si hay eje entre el candidato y el nodo; el nodo no esta visitado; y no es el candidato...
					{
						candidatos.add(posicion, nodes[i]);
						posicion++;
					}
				}
			}
		}
		
		return recorridoProfundidadToString(s);
		
	}

	private String recorridoProfundidadToString(ArrayList<T> s)
	{
		String res = "";
		for(int i = 0; i < s.size(); i++)
		{
			res = res + s.get(i) + "\t";
		}
		return res;
	}

	private boolean[] inicializar_visitados_recorridoProfundidad()
	{
		boolean[] res = new boolean[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			res[i] = false;
		}
		
		return res;
	}
	
	public double excentricidad()
	{
		double res = Inf;
		
		// se aplica Floyd (distancia de coste minima de cada nodo al resto de nodos)	
		
		// buscamos en A el peso maximo de cada columna
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j) // no computamos sobre la diagonal!!!
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaMaximoExcentricidad(valoresColumna);
		}
		
		// buscamos en maximos el valor mas bajo y retornamos dicho valor
		for(int i = 0; i < numNodes; i++)
		{
			if(maximos[i] < res)
			{
				res = maximos[i];
			}
		}
		
		return res;
	}

	private double buscaMaximoExcentricidad(double[] valoresColumna)
	{
		double res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(valoresColumna[i] > res)
			{
				res = valoresColumna[i];
			}
		}
		
		return res;
	}
	
	public T centroGrafo()
	{
		T res = null;
		double min = Inf;
		
		// Se aplica Floyd (distancia de coste minima de cada nodo al resto de nodos)
		
		// El centro de un grafo es el nodo de excentricidad minima 
		
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j) // no computamos con la diagonal!!!
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaMaximoExcentricidad(valoresColumna);
		}
		
		for(int i = 0; i < numNodes; i++)
		{
			if(maximos[i] < min)
			{
				res = nodes[i];
				min = maximos[i];
			}
		}
		
		return res;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<String> prim(T nodoOrigen)
	{
		ArrayList<String> res = new ArrayList<>();
		
		// partiendo de un nodo buscamos su eje con el menor coste que conecte con otro nodo no visitado
		boolean[] visitados = inicializar_visitados_prim();
		
		// ponemos a visitado el nodoOrigen
		visitados[getNodeTG(nodoOrigen)] = true;
		
		T[] nodosInicio = (T[]) new Object[numNodes];
		
		for(int i = 0; i < numNodes-1; i++)
		{
			nodosInicio[i] = nodoOrigen;
			
			// buscar el eje con origen el nodoOrigenDeLaIteracion y destino cualquiera accesible desde el nodo hablado
			T nodoComienzo = nodoOrigen;
			
			T nodoFinal = buscaNodosDestino(nodoComienzo, visitados);
			
			String texto_comienzo = nodoComienzo + "";
			String texto_final = nodoFinal + "";
			
			res.add(texto_comienzo + texto_final);
			
			visitados[getNodeTG(nodoFinal)] = true;
			
			nodoOrigen = nodoFinal;
		}
		
		return res;
	}

	private T buscaNodosDestino(T nodoComienzo, boolean[] visitados)
	{
		T res = null;
		double max = Inf;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(existEdge(nodoComienzo, getNodes()[i]) && getEdgeTG(nodoComienzo, nodes[i]) < max && !visitados[i])
			{
				res = nodes[i];
				max = getEdgeTG(nodoComienzo, nodes[i]);
			}
		}
		
		return res;
	}

	private boolean[] inicializar_visitados_prim()
	{
		return new boolean[numNodes];
	}
	
	public boolean isBuclesInNodo(T nodo)
	{
		if(!existNode(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		return getEdges()[getNodeTG(nodo)][getNodeTG(nodo)];
	}
	
	public int numBuclesGrafo()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isBuclesInNodo(nodes[i]))
			{
				contador++;
			}
		}
		return contador;
	}
	
	public boolean isSourceNode(T nodo)
	{
		// un nodo fuente es aquel que no es el nodo destino de ningun eje sino solo el origen
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodo.equals(nodes[i]) && existEdge(nodo, nodes[i]) && !existEdge(nodes[i], nodo))
			{
				return true;
			}
		}
		return false;
	}
	
	public int getNumberOfSourceNodes()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isSourceNode(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public boolean isIsolatedNode(T nodo)
	{
		if(!existNode(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodo.equals(nodes[i]) && !existEdge(nodo, nodes[i]) && !existEdge(nodes[i], nodo))
			{
				return true;
			}
		}
		return false;
	}
	
	public int getNumberOfIsolatedNodes()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isIsolatedNode(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public DijkstraDataClass dijkstra2(T nodoOrigen)
	{
		// camino de coste minimo de un nodoOrigen al resto de nodos
		
		if(!existNode(nodoOrigen))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodoOrigen == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		double[] D_dijkstra = inicializar_D_Dijkstra2(nodoOrigen); // almacena los costes
		int[] P_dijkstra = inicializar_P_Dijkstra2(nodoOrigen); // almacena los indices de los nodos desde los que se accede a cada nodo
																// SE INICIALIZA CON -1 LAS CASILLAS DE LOS NODOS A LOS QUE NO SE LLEGA 
																// DESDE EL NODO ORIGEN Y EL RESTO DE CASILLAS A LAS QUE SI SON ACCESIBLES 
																// DIRECTAMENTE DESDE NODO ORIGEN LAS INICIALIZAMOS CON EL INDICE DEL NODO ORIGEN
		
		ArrayList<T> S = new ArrayList<>();
		boolean[] visitados = inicializar_visitados_dijkstra2();
		
		S.add(nodoOrigen);
		visitados[getNodeTG(nodoOrigen)] = true;
		
		
		while(!isAllVisited(visitados))
		{
			// Paso 2: buscar un nodo w perteneciente a S-nodos tal que su D[w] sea minimo
			T nodo_pivote = buscar_Pivote_Dijkstra2(D_dijkstra, visitados);
			int index_nodo_pivote = getNodeTG(nodo_pivote);
			
			// lo agregamos a S y lo marcamos como visitado
			S.add(nodo_pivote);
			visitados[index_nodo_pivote] = true;
			
			// Paso 3: para un nodo m de nodos-S calcular...
			for(int i = 0; i < numNodes; i++)
			{
				if(!visitados[i]) // si no es un nodo pivote(no esta visitado)
				{
					int index_nodo_m = i;
					
					// d[m] --> min(d[m], d[pivote] + weights[pivote][m])
					if(D_dijkstra[index_nodo_pivote] + getWeights()[index_nodo_pivote][index_nodo_m] < D_dijkstra[index_nodo_m])
					{
						D_dijkstra[index_nodo_m] = D_dijkstra[index_nodo_pivote] + getWeights()[index_nodo_pivote][index_nodo_m]; // actualizamos D
						P_dijkstra[index_nodo_m] = index_nodo_pivote; // actualizamos P
					}
				}
			}
		}
		
		return new DijkstraDataClass(numNodes, getNodeTG(nodoOrigen), D_dijkstra, P_dijkstra);
		
	}
	
	private boolean isAllVisited(boolean[] visitados)
	{
		for(int i = 0; i < visitados.length; i++)
		{
			if(!visitados[i])
			{
				return false;
			}
		}
		return true;
	}

	private T buscar_Pivote_Dijkstra2(double[] d_dijkstra, boolean[] visitados)
	{
		T res = null;
		double corte = Inf;
		
		for(int i = 0; i < d_dijkstra.length; i++)
		{
			if(!visitados[i] && d_dijkstra[i] <= corte) // nodo no visitado y coste mas bajo que el corte...
			{
				res = nodes[i];
				corte = d_dijkstra[i];
			}
		}
		
		return res;
	}

	private boolean[] inicializar_visitados_dijkstra2()
	{
		return new boolean[numNodes];
	}

	private int[] inicializar_P_Dijkstra2(T nodoOrigen)
	{
		int[] res = new int[numNodes];

		for (int i = 0; i < numNodes; i++)
		{
			if(getEdges()[getNodeTG(nodoOrigen)][i]) // hay eje del nodoOrigen a otro nodo...
			{
				res[i] = getNodeTG(nodoOrigen); // indice del nodoOrigen
			} else // si no hay eje del nodoOrigen a otro nodo o el indice del nodoOrigen es el
					// mismo que i...
			{
				res[i] = -1; // no se llega
			}
		}

		return res;
	}

	private double[] inicializar_D_Dijkstra2(T nodoOrigen)
	{
		double[] res = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getNodeTG(nodoOrigen) == i)
			{
				res[i] = 0;
				continue;
			}
			res[i] = getWeights()[getNodeTG(nodoOrigen)][i];
		}
		
		return res;
	}

	public boolean floyd2()
	{
		if(numNodes == 0) // grafo vacio
		{
			return false;
		}
		
		// camino de coste minimo de cada nodo al resto de nodos
		this.A_floyd = inicializar_A_floyd2(); // matriz de pesos
		this.P_floyd = inicializar_P_floyd2(); // matriz con los indices de los nodos desde los que se accede
		
		// para cada nodo del grafo hacer...
		for(int a = 0; a < numNodes; a++)
		{
			for(int i = 0; i < numNodes; i++)
			{
				for(int j = 0; j < numNodes; j++)
				{
					if(i != j && i != a && j != a) // que no se seleccione la diagonal; ni la fila del pivote; ni la columna del pivote
					{
						// A[i][j] --> min(A[i][j], A[i][a] + A[a][j])
						if(A_floyd[i][a] + A_floyd[a][j] < A_floyd[i][j])
						{
							A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j]; // actualizamos A
							P_floyd[i][j] = a;
						}
					}
				}
			}
		}
		
		return true;
	}
	
	private int[][] inicializar_P_floyd2()
	{
		int[][] res = new int[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				res[i][j] = -1;
			}
		}
		
		return res;
	}

	private double[][] inicializar_A_floyd2()
	{
		double[][] res = getWeights();
		
		for(int i = 0; i < numNodes; i++)
		{
			res[i][i] = 0; // peso de ir de un nodo a si mismo es 0 (diagonal de A de ceros)
		}
		
		return res;
	}

	public double minCostPath2(T origen, T destino)
	{
		// se ejecuta floyd2 antes
		
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("El elemento " + origen + " no existe en la estructura");
		}
		if (!existNode(destino))
		{
			throw new IllegalArgumentException("El elemento " + destino + " no existe en la estructura");
		}
		if(origen == null)
		{
			throw new IllegalArgumentException("Nodo origen null");
		}
		if(destino == null)
		{
			throw new IllegalArgumentException("Nodo destino null");
		}
		
		return getFloydA()[getNodeTG(origen)][getNodeTG(destino)];
	}
	
	public String path2(T origen, T destino)
	{
		
	}
	
	public boolean addNode2(T nodo)
	{
		
	}
	
	protected int getNode2(T nodo)
	{
		
	}
	
	public boolean existNode2(T nodo)
	{
		
	}
	
	public double getEdge2(T origen, T destino)
	{
		
	}
	
	public boolean existEdge2(T origen, T destino)
	{
		
	}
	
	public boolean addEdge2(T origen, T destino, double peso)
	{
		
	}
	
	public boolean removeNode2(T nodo)
	{
		
	}
	
	public boolean removeEdge(T origen, T destino)
	{
		
	}
	
	
}
