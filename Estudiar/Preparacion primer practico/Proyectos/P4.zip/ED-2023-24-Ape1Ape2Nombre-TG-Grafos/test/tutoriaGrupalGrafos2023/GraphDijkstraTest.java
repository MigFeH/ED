package tutoriaGrupalGrafos2023;

import static org.junit.Assert.*;

import org.junit.Test;


public class GraphDijkstraTest {

	@Test
	public void testDijkstra1() {
		System.out.println("Pruebas evaluaci�n Dijkstra");
		GraphTG2023<String> G=new GraphTG2023<String>(8);
		// Insertar nodos
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		assertTrue(G.addEdgeTG("Nodo A","Nodo C", 5));
		assertTrue(G.addEdgeTG("Nodo A","Nodo E", 5));
		
		assertTrue(G.addEdgeTG("Nodo B","Nodo A", 4));
		assertTrue(G.addEdgeTG("Nodo B","Nodo F", 4));
		assertTrue(G.addEdgeTG("Nodo B","Nodo G", 2));

		assertTrue(G.addEdgeTG("Nodo C","Nodo B", 4));
		assertTrue(G.addEdgeTG("Nodo C","Nodo E", 1));
		assertTrue(G.addEdgeTG("Nodo C","Nodo G", 7));
		
		assertTrue(G.addEdgeTG("Nodo D","Nodo F", 6));
		
		assertTrue(G.addEdgeTG("Nodo F","Nodo H", 9));
		System.out.println(G.toString());
		
		// Dijkstra
		DijkstraDataClass D= G.dijkstra("Nodo A");
		System.out.print("Dijkstra - Nodo A ->  D[");
		//Obtiene el vector D
		double d[]=D.getdDijkstra();
		for (int i=0; i<d.length-1; i++) 
			System.out.print(d[i]+",");
		System.out.println(d[d.length-1]+"]");
		System.out.println("\n");
		assertEquals(d[0],0.0,0.0001);
		assertEquals(d[1],9.0,0.0001);
		assertEquals(d[2],5.0,0.0001);
		assertEquals(d[3],Double.POSITIVE_INFINITY,0.0001);
		assertEquals(d[4],5.0,0.0001);
		assertEquals(d[5],13.0,0.0001);
		assertEquals(d[6],11.0,0.0001);
		assertEquals(d[7],22.0,0.0001);
		
		System.out.print("Dijkstra - Nodo A ->  P[");
		//Obtiene el vector P con posiciones de nodos. Si no hay camino -1
		int p[]=D.getpDijkstra();
		for (int i=0; i<p.length-1; i++) 
			System.out.print(p[i]+",");
		System.out.println(p[p.length-1]+"]");
		assertEquals(p[0],-1);
		assertEquals(p[1],2);
		assertEquals(p[2],0);
		assertEquals(p[3],-1);
		assertEquals(p[4],0);
		assertEquals(p[5],1);
		assertEquals(p[6],1);
		assertEquals(p[7],5);
	}
	
	@Test
	public void testDijkstra2() {
		System.out.println("Pruebas evaluaci�n Dijkstra");
		GraphTG2023<String> G=new GraphTG2023<String>(8);
		// Insertar nodos
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		assertTrue(G.addEdgeTG("Nodo A","Nodo C", 5));
		assertTrue(G.addEdgeTG("Nodo A","Nodo E", 5));
		
		assertTrue(G.addEdgeTG("Nodo B","Nodo A", 4));
		assertTrue(G.addEdgeTG("Nodo B","Nodo F", 4));
		assertTrue(G.addEdgeTG("Nodo B","Nodo G", 2));

		assertTrue(G.addEdgeTG("Nodo C","Nodo B", 4));
		assertTrue(G.addEdgeTG("Nodo C","Nodo E", 1));
		assertTrue(G.addEdgeTG("Nodo C","Nodo G", 7));
		
		assertTrue(G.addEdgeTG("Nodo D","Nodo F", 6));
		
		assertTrue(G.addEdgeTG("Nodo F","Nodo H", 9));
		System.out.println(G.toString());
		
		// Dijkstra
		DijkstraDataClass D= G.dijkstra2("Nodo A");
		System.out.print("Dijkstra - Nodo A ->  D[");
		//Obtiene el vector D
		double d[]=D.getdDijkstra();
		for (int i=0; i<d.length-1; i++) 
			System.out.print(d[i]+",");
		System.out.println(d[d.length-1]+"]");
		System.out.println("\n");
		assertEquals(d[0],0.0,0.0001);
		assertEquals(d[1],9.0,0.0001);
		assertEquals(d[2],5.0,0.0001);
		assertEquals(d[3],Double.POSITIVE_INFINITY,0.0001);
		assertEquals(d[4],5.0,0.0001);
		assertEquals(d[5],13.0,0.0001);
		assertEquals(d[6],11.0,0.0001);
		assertEquals(d[7],22.0,0.0001);
		
		System.out.print("Dijkstra - Nodo A ->  P[");
		//Obtiene el vector P con posiciones de nodos. Si no hay camino -1
		int p[]=D.getpDijkstra();
		for (int i=0; i<p.length-1; i++) 
			System.out.print(p[i]+",");
		System.out.println(p[p.length-1]+"]");
		assertEquals(p[0],-1);
		assertEquals(p[1],2);
		assertEquals(p[2],0);
		assertEquals(p[3],-1);
		assertEquals(p[4],0);
		assertEquals(p[5],1);
		assertEquals(p[6],1);
		assertEquals(p[7],5);
	}
}
