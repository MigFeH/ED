package tutoriaGrupalGrafos2023;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphTG2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf=Double.POSITIVE_INFINITY;
	
	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado

	/**
	 * 
	 * @param tam
	 *            Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphTG2023(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}
	
	protected int getNumNodes() {
		return numNodes;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeTG(T node) {
		int index = 0;
		for(T theNode: nodes)
		{
			if(theNode != null && theNode.equals(node))
			{
				return index; 
			}
			index++;
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro.
	 * Siempre lo inserta, no se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeTG(T node) {
		if(node == null)
		{
			throw new NullPointerException("Nodo a a�adir null");
		}
		if(nodes.length == numNodes)
		{
			throw new IllegalArgumentException("Nodo a añadir ya existente en el grafo");
		}
		
		if(numNodes > 0) // si el grafo tiene nodos...
		{
			if(existNode(node))
			{
				return false;
			}
		}
		numNodes++;

		// a�adir nodo al vector de nodos
		int index = numNodes - 1;
		nodes[index] = node;

		// poner a false la fila y columna del nodo que se a�ade en la matriz de ejes
		for (int i = 0; i < edges.length; i++) {
			edges[index][i] = false;
			edges[i][index] = false;
		}
		// poner infinitos en la fila y columna del nodo que se a�ade en la matriz de
		// pesos
		for (int i = 0; i < weights.length; i++) {
			weights[index][i] = Inf;
			weights[i][index] = Inf;
		}

		return true;
	}


	/**
	 * Inserta una arista entre dos nodos con el peso indicado 
	 * Devuelve true siempre
	 * No comprueba nada. 
	 * @param source
	 *            nodo origen
	 * @param target
	 *            nodo destino
	 * @param edgeWeight
	 *            peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeTG(T origen, T destino, double peso) {
		if(!existNode(origen))
		{
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if(!existNode(destino))
		{
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if(peso < 0.0)
		{
			throw new IllegalArgumentException("Peso de eje negativo");
		}
		if(existEdge(origen, destino)) // si existe el eje...
		{
			return false;
		}
		else // sino...
		{
			edges[getNodeTG(origen)][getNodeTG(destino)] = true;
			weights[getNodeTG(origen)][getNodeTG(destino)] = peso;
			
			return true;
		}
	}
	
	/**
	 * @param origen nodo de tipo T
	 * @param destino nodo de tipo 
	 * @return true o false en funcion de la existencia del eje que une a los nodos pasados por parametro
	 */
	public boolean existEdge(T origen, T destino)
	{
		// si hay un true en la casilla de ejes (origen, destino) entonces retornamos true
		int index_origen = getNodeTG(origen);
		int index_destino = getNodeTG(destino);
		
		if(edges[index_origen][index_destino])
		{
			return true;
		}
		return false;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos.
	 * Siempre la borra sin comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeTG(T source, T target) {
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos.
	 * No comprueba nada...
	 *  
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeTG(T origen, T destino) {
		if(!existNode(origen))
		{
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if(!existNode(destino))
		{
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if(!existEdge(origen, destino))
		{
			return -1;
		}
		return weights[getNodeTG(origen)][getNodeTG(destino)];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();
		
		cadena.append("NODES\n");
		for (int i = 0; i < numNodes; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena.append((edges[i][j]?df.format(weights[i][j]):"-") + "\t");
			}
			cadena.append("\n");
		}
	
		return cadena.toString();
	}
	
	public boolean isDrainNode(T c) {  
		// Completad el metodo... NODO SUMIDERO
		
		return false;
	}

	public int getNumberOfDrainNodes () {
		// Completad el metodo...
		return -1;
	}
	
	/**
	 * Calcula el camino de coste minimo desde el nodoOrigen al resto de nodos del grafo
	 */
	public DijkstraDataClass dijkstra(T nodoOrigen) {
		if(!existNode(nodoOrigen) || nodoOrigen == null)
		{
			throw new IllegalArgumentException(nodoOrigen + " no existente en el grafo");
		}
		
		double[] D_dijkstra = inicializar_D_Dijkstra(nodoOrigen); // vector de pesos
		int[] P_dijkstra = inicializar_P_Dijkstra(nodoOrigen); // vector desde que nodo se accede a uno (almacena posiciones)
		
		boolean[] visitados_dijkstra = inicializar_visitados_dijkstra(nodoOrigen);
		ArrayList<T> S_dijkstra = inicializar_S_dijkstra(nodoOrigen);
		
		while(!todosVisitadosDijkstra(visitados_dijkstra))
		{
			// Paso 2: buscar nodo w de S-nodos (no visitados) tal que D[w] sea min
			T nodo_pivote = buscarPivoteDijkstra(visitados_dijkstra, D_dijkstra);
			int indice_nodo_pivote = getNodeTG(nodo_pivote);
			
			// agregar nodo_pivote al conjunto solucion S
			S_dijkstra.add(nodo_pivote);
			
			// marcar nodo_pivote como vivsitado
			visitados_dijkstra[indice_nodo_pivote] = true;
			
			// Paso 3: para cada nodo de S-nodos...
			for(int i = 0; i < nodes.length; i++)
			{
				if(!isNodoVisitadoDijkstra(nodes[i], visitados_dijkstra)) // nodo no visitado...
				{
					T nodo_M = nodes[i];
					int indice_nodo_M = getNodeTG(nodo_M);
					
					if(D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M] < D_dijkstra[indice_nodo_M])
					{
						D_dijkstra[indice_nodo_M] = D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M]; // actualizamos D
						P_dijkstra[indice_nodo_M] = indice_nodo_pivote; // actualizamos P
					}
				}
			}
		}
		
		return new DijkstraDataClass(numNodes, getNodeTG(nodoOrigen), D_dijkstra, P_dijkstra);
	}

	private boolean isNodoVisitadoDijkstra(T nodo, boolean[] visitados_dijkstra)
	{
		return visitados_dijkstra[getNodeTG(nodo)];
	}

	private T buscarPivoteDijkstra(boolean[] visitados_dijkstra, double[] d_dijkstra)
	{
		double aux = Inf;
		T res = null;
		
		for(int i = 0; i < d_dijkstra.length; i++)
		{
			if(!visitados_dijkstra[i] && d_dijkstra[i] <= aux) // nodo no visitado
			{
				aux = d_dijkstra[i];
				res = getNodes()[i];
			}
		}
		return res;
	}

	private boolean todosVisitadosDijkstra(boolean[] visitados_dijkstra)
	{
		for(int i = 0; i < visitados_dijkstra.length; i++)
		{
			if(!visitados_dijkstra[i])
			{
				return false;
			}
		}
		return true;
	}

	private ArrayList<T> inicializar_S_dijkstra(T nodoOrigen)
	{
		ArrayList<T> res = new ArrayList<>();
		res.add(nodoOrigen);
		return res;
	}

	private boolean[] inicializar_visitados_dijkstra(T nodoOrigen)
	{
		boolean[] res = new boolean[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getNodeTG(nodoOrigen) == i)
			{
				res[i] = true;
			}
			res[i] = false;
		}
				
		return res;
	}

	private int[] inicializar_P_Dijkstra(T nodoOrigen)
	{
		int[] res = new int[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getEdges()[getNodeTG(nodoOrigen)][i]) // hay eje del nodoOrigen a otro nodo...
			{
				res[i] = getNodeTG(nodoOrigen); // indice del nodoOrigen
			} else // si no hay eje del nodoOrigen a otro nodo o el indice del nodoOrigen es el mismo que i...
			{
				res[i] = -1; // no se llega
			}
			
		}
		
		return res;
	}

	private boolean existNode(T nodoOrigen)
	{
		for(T theNode: nodes)
		{
			if(theNode != null && theNode.equals(nodoOrigen))
			{
				return true; 
			}
		}
		return false;
	}

	private double[] inicializar_D_Dijkstra(T nodoOrigen)
	{
		double[] res = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getNodeTG(nodoOrigen) == i)
			{
				res[i] = 0; // el peso de ir de un nodo a si mismo es de 0
			} else
			{
				res[i] = getWeights()[getNodeTG(nodoOrigen)][i]; // dentro de la matriz de pesos la fila del nodo origen
			}
		}
		
		return res;
	}
}
