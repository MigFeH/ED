package tutoriaGrupalGrafos2023;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GraphTest {
	@Test
	public void T2_testAddNode() {
		System.out.println("T2 -->TestAddNode ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(8);
		
		// Insertar nodos correctamente
		for (int i=0;i<6;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// Muestra el grafo
		System.out.print(G.toString());

		//Inserta un Null
		try {
			G.addNodeTG(null);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("Element to insert is null.",e.getMessage());
		}
		//Insertar un nodo que ya existe
		assertFalse(G.addNodeTG("Nodo A"));

		//Sigo insertando
		assertTrue(G.addNodeTG("Nodo G"));
		assertTrue(G.addNodeTG("Nodo H"));	
		//No hay espacio
		try{
			assertTrue(G.addNodeTG("E"));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento E no se puede insertar porque la estructura est� llena",e.getMessage());
		}
	}		

	@Test
	public void T3_testGetNode() {
		System.out.println("T3 -->TestGetNode ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// El nodo no existe
		assertEquals(-1,G.getNodeTG("Nodo W"));
		
		// El nodo existe
		for (int i=0;i<8;i++){
			assertEquals(i,G.getNodeTG("Nodo "+(char)('A'+i)));			
		}
	}
	
	@Test
	public void T4_testAddEdge() {
		System.out.println("T4 -->TestAddEdge ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// No exiten los nodos
		try {
			G.addEdgeTG("W","I",5.0);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento W no existe en la estructura",e.getMessage());
		}
		
		// Existen los nodos pero el peso es negativo
		try {
			assertTrue(G.addEdgeTG("Nodo A", "Nodo B",-2));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
//			assertEquals("Weight edge could not be less or equals to 0",e.getMessage());
		}
		
		// Inserta ejes
		assertTrue(G.addEdgeTG("Nodo A", "Nodo B",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo E",1));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdgeTG("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo C",1));
		
		// Muestra el grafo
		System.out.print(G.toString());
		
		//Inserta un eje que ya existe
		assertFalse(G.addEdgeTG("Nodo H", "Nodo C",1));
		
		// No exiten el primer nodo
		try {
			G.getEdgeTG("Nodo W","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
//			assertEquals("El elemento Nodo W no existe en la estructura",e.getMessage());
		}
		
		// Existe el primer nodo pero no el segundo
		try {
			G.getEdgeTG("Nodo A","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo I no existe en la estructura",e.getMessage());
		}
		
		//Existen los nodos pero no el eje
		assertEquals(-1, G.getEdgeTG("Nodo A","Nodo H"),0.0);
		
		// El eje existe
		assertEquals(2,G.getEdgeTG("Nodo A", "Nodo B"),0.0);
		assertEquals(2,G.getEdgeTG("Nodo A", "Nodo D"),0.0);
		assertEquals(4,G.getEdgeTG("Nodo A", "Nodo F"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo B", "Nodo C"),0.0);
		assertEquals(5,G.getEdgeTG("Nodo B", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdgeTG("Nodo D", "Nodo E"),0.0);
		assertEquals(4,G.getEdgeTG("Nodo D", "Nodo F"),0.0);
		
		assertEquals(6,G.getEdgeTG("Nodo E", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo F", "Nodo C"),0.0);
		assertEquals(3,G.getEdgeTG("Nodo F", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo G", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdgeTG("Nodo H", "Nodo C"),0.0);
	}		
	
	@Test
	public void T5_testGetEdge() {
		System.out.println("T5 -->TestGetEdge ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdgeTG("Nodo A", "Nodo B",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo E",1));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdgeTG("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo C",1));
	}
	
	@Test
	public void T6_testGRemoveNode2() {
		System.out.println("T6 -->TestRemoveNode2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdge2("Nodo A", "Nodo B",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo D",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo B", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdge2("Nodo D", "Nodo E",1));
		assertTrue(G.addEdge2("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdge2("Nodo F", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdge2("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdge2("Nodo H", "Nodo C",1));
		
		// Nodo null
		try {
			G.removeNode2(null);
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("Element to insert is null.",e.getMessage());
		}
		
		// El nodo no existe
		assertFalse(G.removeNode2("Nodo W"));
		
		//Borrar Nodo A: Borra el eje de A a B de A a D y de A a F
		assertTrue(G.removeNode2("Nodo A"));
		System.out.println("DESPUES DE BORRAR EL NODO A");
		System.out.println(G.toString());
		
		//Borrar Nodo G: Borra el eje de G a H, de F a G y de E a G
		assertTrue(G.removeNode2("Nodo G"));
		System.out.println("DESPUES DE BORRAR EL NODO G");
		System.out.println(G.toString());
		
		//Borrar Nodo H: Borra el eje de H a C y de B a H
		assertTrue(G.removeNode2("Nodo H"));
		System.out.println("DESPUES DE BORRAR EL NODO H");
		System.out.println(G.toString());
	}
	
	
	
	@Test
	public void T7_testGRemoveEdge() {
		System.out.println("T7 -->TestRemoveEdge ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdgeTG("Nodo A", "Nodo B",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo E",1));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdgeTG("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo C",1));
		
		// El primer nodo ya no existe
		try {
			G.removeEdgeTG("Nodo W","Nodo X");
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo W no existe en la estructura",e.getMessage());
		}
		
		// El primer nodo existe pero el segundo no
		try {
			G.removeEdgeTG("Nodo A","Nodo X");
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo X no existe en la estructura",e.getMessage());
		}
		
		//Existen los nodos pero no el eje
		assertFalse(G.removeEdgeTG("Nodo A","Nodo H"));

		
		//Borrar el eje de A a F
		assertTrue(G.removeEdgeTG("Nodo A","Nodo F"));
		System.out.println("DESPUES DE BORRAR EL EJE DE A a F");
		System.out.println(G.toString());
		
		//Borrar el eje de E a G
		assertTrue(G.removeEdgeTG("Nodo E","Nodo G"));
		System.out.println("DESPUES DE BORRAR EL EJE DE E a G");
		System.out.println(G.toString());
		
		//Borrar el eje de H a C
		assertTrue(G.removeEdgeTG("Nodo H","Nodo C"));
		System.out.println("DESPUES DE BORRAR EL EJE DE H a C");
		System.out.println(G.toString());
	}
	
	@Test
	public void T8_testAddNode2() {
		System.out.println("T8 -->TestAdd2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(8);
		
		// Insertar nodos correctamente
		for (int i=0;i<6;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// Muestra el grafo
		System.out.print(G.toString());

		//Inserta un Null
		try {
			G.addNode2(null);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("Element to insert is null.",e.getMessage());
		}
		//Insertar un nodo que ya existe
		assertFalse(G.addNode2("Nodo A"));

		//Sigo insertando
		assertTrue(G.addNode2("Nodo G"));
		assertTrue(G.addNode2("Nodo H"));	
		//No hay espacio
		try{
			assertTrue(G.addNode2("E"));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento E no se puede insertar porque la estructura est� llena",e.getMessage());
		}
	}		

	@Test
	public void T9_testGetNode2() {
		System.out.println("T9 -->TestGetNode2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// El nodo no existe
		assertEquals(-1,G.getNode2("Nodo W"));
		
		// El nodo existe
		for (int i=0;i<8;i++){
			assertEquals(i,G.getNode2("Nodo "+(char)('A'+i)));			
		}
	}
	
	@Test
	public void T10_testAddEdge2() {
		System.out.println("T10 -->TestAddEdge2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// No exiten los nodos
		try {
			G.addEdge2("W","I",5.0);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento W no existe en la estructura",e.getMessage());
		}
		
		// Existen los nodos pero el peso es negativo
		try {
			assertTrue(G.addEdge2("Nodo A", "Nodo B",-2));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
//			assertEquals("Weight edge could not be less or equals to 0",e.getMessage());
		}
		
		// Inserta ejes
		assertTrue(G.addEdge2("Nodo A", "Nodo B",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo D",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo B", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdge2("Nodo D", "Nodo E",1));
		assertTrue(G.addEdge2("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdge2("Nodo F", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdge2("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdge2("Nodo H", "Nodo C",1));
		
		// Muestra el grafo
		System.out.print(G.toString());
		
		//Inserta un eje que ya existe
		assertFalse(G.addEdge2("Nodo H", "Nodo C",1));
		
		// No exiten el primer nodo
		try {
			G.getEdge2("Nodo W","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
//			assertEquals("El elemento Nodo W no existe en la estructura",e.getMessage());
		}
		
		// Existe el primer nodo pero no el segundo
		try {
			G.getEdge2("Nodo A","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo I no existe en la estructura",e.getMessage());
		}
		
		//Existen los nodos pero no el eje
		assertEquals(-1, G.getEdge2("Nodo A","Nodo H"),0.0);
		
		// El eje existe
		assertEquals(2,G.getEdge2("Nodo A", "Nodo B"),0.0);
		assertEquals(2,G.getEdge2("Nodo A", "Nodo D"),0.0);
		assertEquals(4,G.getEdge2("Nodo A", "Nodo F"),0.0);
		
		assertEquals(2,G.getEdge2("Nodo B", "Nodo C"),0.0);
		assertEquals(5,G.getEdge2("Nodo B", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdge2("Nodo D", "Nodo E"),0.0);
		assertEquals(4,G.getEdge2("Nodo D", "Nodo F"),0.0);
		
		assertEquals(6,G.getEdge2("Nodo E", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdge2("Nodo F", "Nodo C"),0.0);
		assertEquals(3,G.getEdge2("Nodo F", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdge2("Nodo G", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdge2("Nodo H", "Nodo C"),0.0);
	}		
	
	@Test
	public void T11_testGetEdge2() {
		System.out.println("T11 -->TestGetEdge2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdge2("Nodo A", "Nodo B",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo D",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo B", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdge2("Nodo D", "Nodo E",1));
		assertTrue(G.addEdge2("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdge2("Nodo F", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdge2("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdge2("Nodo H", "Nodo C",1));
	}
	
	@Test
	public void T12_testGRemoveEdge2() {
		System.out.println("T12 -->TestRemoveEdge2 ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNode2("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdge2("Nodo A", "Nodo B",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo D",2));
		assertTrue(G.addEdge2("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo B", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdge2("Nodo D", "Nodo E",1));
		assertTrue(G.addEdge2("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdge2("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdge2("Nodo F", "Nodo C",2));
		assertTrue(G.addEdge2("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdge2("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdge2("Nodo H", "Nodo C",1));
		
		// El primer nodo ya no existe
		try {
			G.removeEdge2("Nodo W","Nodo X");
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo W no existe en la estructura",e.getMessage());
		}
		
		// El primer nodo existe pero el segundo no
		try {
			G.removeEdge2("Nodo A","Nodo X");
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo X no existe en la estructura",e.getMessage());
		}
		
		//Existen los nodos pero no el eje
		assertFalse(G.removeEdge2("Nodo A","Nodo H"));

		
		//Borrar el eje de A a F
		assertTrue(G.removeEdge2("Nodo A","Nodo F"));
		System.out.println("DESPUES DE BORRAR EL EJE DE A a F");
		System.out.println(G.toString());
		
		//Borrar el eje de E a G
		assertTrue(G.removeEdge2("Nodo E","Nodo G"));
		System.out.println("DESPUES DE BORRAR EL EJE DE E a G");
		System.out.println(G.toString());
		
		//Borrar el eje de H a C
		assertTrue(G.removeEdge2("Nodo H","Nodo C"));
		System.out.println("DESPUES DE BORRAR EL EJE DE H a C");
		System.out.println(G.toString());
	}
}