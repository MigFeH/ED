package tutoriaGrupalGrafos2023;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class GraphPrimTest {

	@Test
    public void testPrim() {
        GraphTG2023<String> grafo = new GraphTG2023<>(7);
        grafo.addNodeTG("A");
        grafo.addNodeTG("B");
        grafo.addNodeTG("C");
        grafo.addNodeTG("D");
        grafo.addNodeTG("E");
        grafo.addNodeTG("F");

        grafo.addEdgeTG("A", "B", 3);
        grafo.addEdgeTG("B", "A", 3);
        grafo.addEdgeTG("A", "C", 3);
        grafo.addEdgeTG("C", "A", 3);
        grafo.addEdgeTG("A", "D", 1);
        grafo.addEdgeTG("D", "A", 1);
        grafo.addEdgeTG("D", "C", 2);
        grafo.addEdgeTG("C", "D", 2);
        grafo.addEdgeTG("D", "E", 1);
        grafo.addEdgeTG("E", "D", 1);
        grafo.addEdgeTG("C", "F", 4);
        grafo.addEdgeTG("F", "C", 4);
        grafo.addEdgeTG("C", "E", 2);
        grafo.addEdgeTG("E", "C", 2);
        grafo.addEdgeTG("B", "C", 1);
        grafo.addEdgeTG("C", "B", 1);
        grafo.addEdgeTG("B", "F", 2);
        grafo.addEdgeTG("F", "B", 2);
        

        ArrayList<String> resultadoPrim = grafo.prim("A");

        String[] salidaEsperada = {"AD", "DE", "EC", "CB", "BF"};
        
        for(int i = 0; i < resultadoPrim.size(); i++)
        {
        	assertEquals(salidaEsperada[i], resultadoPrim.get(i));
        }
    }

}
