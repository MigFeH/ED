package tutoriaGrupalGrafos2023;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphTG2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf = Double.POSITIVE_INFINITY;

	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado

	private double[][] A_floyd;
	private int[][] P_floyd;

	/**
	 * 
	 * @param tam Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphTG2023(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}

	protected int getNumNodes() {
		return numNodes;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeTG(T node) {
		int index = 0;
		for (T theNode : nodes) {
			if (theNode != null && theNode.equals(node)) {
				return index;
			}
			index++;
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro. Siempre lo inserta, no
	 * se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeTG(T node) {
		if (node == null) {
			throw new NullPointerException("Nodo a a�adir null");
		}
		if (nodes.length == numNodes) {
			throw new IllegalArgumentException("Nodo a añadir ya existente en el grafo");
		}

		if (numNodes > 0) // si el grafo tiene nodos...
		{
			if (existNode(node)) {
				return false;
			}
		}
		numNodes++;

		// a�adir nodo al vector de nodos
		int index = numNodes - 1;
		nodes[index] = node;

		// poner a false la fila y columna del nodo que se a�ade en la matriz de ejes
		for (int i = 0; i < edges.length; i++) {
			edges[index][i] = false;
			edges[i][index] = false;
		}
		// poner infinitos en la fila y columna del nodo que se a�ade en la matriz de
		// pesos
		for (int i = 0; i < weights.length; i++) {
			weights[index][i] = Inf;
			weights[i][index] = Inf;
		}

		return true;
	}

	/**
	 * Inserta una arista entre dos nodos con el peso indicado Devuelve true siempre
	 * No comprueba nada.
	 * 
	 * @param source     nodo origen
	 * @param target     nodo destino
	 * @param edgeWeight peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeTG(T origen, T destino, double peso)
	{
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if (!existNode(destino))
		{
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if (peso < 0.0)
		{
			throw new IllegalArgumentException("Peso de eje negativo");
		}
		if (existEdge(origen, destino)) // si existe el eje...
		{
			return false;
		} else // sino...
		{
			edges[getNodeTG(origen)][getNodeTG(destino)] = true;
			weights[getNodeTG(origen)][getNodeTG(destino)] = peso;

			return true;
		}
	}

	/**
	 * @param origen  nodo de tipo T
	 * @param destino nodo de tipo
	 * @return true o false en funcion de la existencia del eje que une a los nodos
	 *         pasados por parametro
	 */
	public boolean existEdge(T origen, T destino) {
		// si hay un true en la casilla de ejes (origen, destino) entonces retornamos
		// true
		int index_origen = getNodeTG(origen);
		int index_destino = getNodeTG(destino);

		if (edges[index_origen][index_destino]) {
			return true;
		}
		return false;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos. Siempre la borra sin
	 * comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeTG(T source, T target) {
		if(!existEdge2(source, target))
		{
			return false;
		}
		
		int posOrigen = getNodeTG(source);
		int posDestino = getNodeTG(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos. No comprueba nada...
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeTG(T origen, T destino) {
		if (!existNode(origen)) {
			throw new IllegalArgumentException("Nodo origen no existente en el grafo");
		}
		if (!existNode(destino)) {
			throw new IllegalArgumentException("Nodo destino no existente en el grafo");
		}
		if (!existEdge(origen, destino)) {
			return -1;
		}
		return weights[getNodeTG(origen)][getNodeTG(destino)];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();

		cadena.append("NODES\n");
		for (int i = 0; i < numNodes; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena.append((edges[i][j] ? df.format(weights[i][j]) : "-") + "\t");
			}
			cadena.append("\n");
		}

		return cadena.toString();
	}

	public boolean isDrainNode(T c)
	{
		// El nodo sumidero es aquel que no es el origen de ningun eje pero si el destino
		for(int i = 0; i < numNodes; i++)
		{
			if(existEdge(nodes[i], c) && !c.equals(nodes[i]) && !existEdge(c, nodes[i]))
			{
				return true;
			}
		}

		return false;
	}

	public int getNumberOfDrainNodes()
	{
		// El nodo sumidero es aquel que no es el origen de ningun eje pero si el destino
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isDrainNode(nodes[i]))
			{
				res = res + 1;
			}
		}
		
		return res;
	}

	/**
	 * Calcula el camino de coste minimo desde el nodoOrigen al resto de nodos del
	 * grafo
	 */
	public DijkstraDataClass dijkstra(T nodoOrigen) {
		if (!existNode(nodoOrigen) || nodoOrigen == null) {
			throw new IllegalArgumentException(nodoOrigen + " no existente en el grafo");
		}

		double[] D_dijkstra = inicializar_D_Dijkstra(nodoOrigen); // vector de pesos
		int[] P_dijkstra = inicializar_P_Dijkstra(nodoOrigen); // vector desde que nodo se accede a uno (almacena
																// posiciones)

		boolean[] visitados_dijkstra = inicializar_visitados_dijkstra(nodoOrigen);
		ArrayList<T> S_dijkstra = inicializar_S_dijkstra(nodoOrigen);

		while (!todosVisitadosDijkstra(visitados_dijkstra))
		{
			// Paso 2: buscar nodo w de S-nodos (no visitados) tal que D[w] sea min
			T nodo_pivote = buscarPivoteDijkstra(visitados_dijkstra, D_dijkstra);
			int indice_nodo_pivote = getNodeTG(nodo_pivote);

			// agregar nodo_pivote al conjunto solucion S
			S_dijkstra.add(nodo_pivote);

			// marcar nodo_pivote como vivsitado
			visitados_dijkstra[indice_nodo_pivote] = true;

			// Paso 3: para cada nodo de S-nodos...
			for (int i = 0; i < nodes.length; i++)
			{
				if (!isNodoVisitadoDijkstra(nodes[i], visitados_dijkstra)) // nodo no visitado...
				{
					T nodo_M = nodes[i];
					int indice_nodo_M = getNodeTG(nodo_M);

					if (D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M] < D_dijkstra[indice_nodo_M])
					{
						D_dijkstra[indice_nodo_M] = D_dijkstra[indice_nodo_pivote] + getWeights()[indice_nodo_pivote][indice_nodo_M]; // actualizamos D
						P_dijkstra[indice_nodo_M] = indice_nodo_pivote; // actualizamos P
					}
				}
			}
		}

		return new DijkstraDataClass(numNodes, getNodeTG(nodoOrigen), D_dijkstra, P_dijkstra);
	}

	private boolean isNodoVisitadoDijkstra(T nodo, boolean[] visitados_dijkstra) {
		return visitados_dijkstra[getNodeTG(nodo)];
	}

	private T buscarPivoteDijkstra(boolean[] visitados_dijkstra, double[] d_dijkstra) {
		double aux = Inf;
		T res = null;

		for (int i = 0; i < d_dijkstra.length; i++) {
			if (!visitados_dijkstra[i] && d_dijkstra[i] <= aux) // nodo no visitado
			{
				aux = d_dijkstra[i];
				res = getNodes()[i];
			}
		}
		return res;
	}

	private boolean todosVisitadosDijkstra(boolean[] visitados_dijkstra) {
		for (int i = 0; i < visitados_dijkstra.length; i++) {
			if (!visitados_dijkstra[i]) {
				return false;
			}
		}
		return true;
	}

	private ArrayList<T> inicializar_S_dijkstra(T nodoOrigen) {
		ArrayList<T> res = new ArrayList<>();
		res.add(nodoOrigen);
		return res;
	}

	private boolean[] inicializar_visitados_dijkstra(T nodoOrigen) {
		boolean[] res = new boolean[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getNodeTG(nodoOrigen) == i) {
				res[i] = true;
			}
			res[i] = false;
		}

		return res;
	}

	private int[] inicializar_P_Dijkstra(T nodoOrigen) {
		int[] res = new int[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getEdges()[getNodeTG(nodoOrigen)][i]) // hay eje del nodoOrigen a otro nodo...
			{
				res[i] = getNodeTG(nodoOrigen); // indice del nodoOrigen
			} else // si no hay eje del nodoOrigen a otro nodo o el indice del nodoOrigen es el
					// mismo que i...
			{
				res[i] = -1; // no se llega
			}

		}

		return res;
	}

	private boolean existNode(T nodoOrigen) {
		for (T theNode : nodes) {
			if (theNode != null && theNode.equals(nodoOrigen)) {
				return true;
			}
		}
		return false;
	}

	private double[] inicializar_D_Dijkstra(T nodoOrigen) {
		double[] res = new double[numNodes];

		for (int i = 0; i < numNodes; i++) {
			if (getNodeTG(nodoOrigen) == i) {
				res[i] = 0; // el peso de ir de un nodo a si mismo es de 0
			} else {
				res[i] = getWeights()[getNodeTG(nodoOrigen)][i]; // dentro de la matriz de pesos la fila del nodo origen
			}
		}

		return res;
	}

	public boolean floyd() {
		if (numNodes == 0) // grafo vacio...
		{
			return false;
		}

		this.A_floyd = inicializar_A_Floyd(); // matriz A de pesos de un nodo a otro
		this.P_floyd = inicializar_P_Floyd(); // matriz P con el indice del nodo desde el que accedemos a otro

		for (int a = 0; a < numNodes; a++) // para cada nodo de nodos...
		{
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					if (i == j) {
						continue;
					}
					if (A_floyd[i][j] > A_floyd[i][a] + A_floyd[a][j]) {
						A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j];
						P_floyd[i][j] = a;
					}
				}
			}
		}
		return true;
	}

	private int[][] inicializar_P_Floyd() {
		int[][] res = new int[numNodes][numNodes];

		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				res[i][j] = -1; // se inicializa con todo a -1
			}
		}

		return res;
	}

	private double[][] inicializar_A_Floyd() {
		double[][] res = new double[numNodes][numNodes];

		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (i == j) // el peso de ir de un nodo al mismo es 0
				{
					res[i][j] = 0;
				} else {
					if (!existEdge(nodes[i], nodes[j])) // si no hay eje entre un nodo y otro --> infinito
					{
						res[i][j] = Inf;
					} else // si hay eje entre los dos nodos --> peso del eje que los une
					{
						res[i][j] = getEdgeTG(nodes[i], nodes[j]);
					}
				}
			}
		}

		return res;
	}

	public double[][] getFloydA() {
		return this.A_floyd;
	}

	public int[][] getFloydP() {
		return this.P_floyd;
	}

	public double minCostPath(T origen, T destino)
	{
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("El elemento " + origen + " no existe en la estructura");
		} else if (!existNode(destino))
		{
			throw new IllegalArgumentException("El elemento " + destino + " no existe en la estructura");
		}

		// tras ejecutar floyd (ya se hace en los test antes de invocar este metodo)
		// buscamos en A_floyd el coste entre el nodo origen y destino
		return getFloydA()[getNodeTG(origen)][getNodeTG(destino)];
	}

	/**
	 * Devuelve el camino de coste minimo que se pasan como parametro usando la
	 * matriz P de Floyd
	 * 
	 * Si el nodo origen es igual al nodo destino: 
	 * 	Origen<tab> 
	 * 
	 * Si no hay camino entre el nodo origen y el nodo destino: 
	 * 	Origen<tab>(Infinito)<tab>Destino 
	 * 
	 * Si hay camino:
	 * 	Origen<tab>(coste0)<tab>Intermedio1<tab>(coste1)...IntermedioN<tab>(costeN)<tab>Destino<tab>
	 */
	public String path(T origen, T destino)
	{
		if (!existNode(origen) || !existNode(destino))
		{
			return "";
		}

		String res = origen + "";

		if (getFloydA()[getNodeTG(origen)][getNodeTG(destino)] == Inf) // no hay camino entre origen y destino
		{
			return res + "\t(" + Inf + ")\t" + destino;
		}

		if (origen.equals(destino)) {
			return res;
		}

		return res + recursivePath(origen, destino) + destino;
	}

	private String recursivePath(T origen, T destino)
	{
		if (origen.equals(destino)) {
			return "\t";
		}

		int pos_nodo_origen = getNodeTG(origen);
		int pos_nodo_destino = getNodeTG(destino);

		// hay camino entre origen y destino

		int pos_nodo_intermedio = getFloydP()[pos_nodo_origen][pos_nodo_destino];

		if (pos_nodo_intermedio != -1) // hay nodo intermedio...
		{
			T nodo_intermedio = nodes[pos_nodo_intermedio];
			double coste = getFloydA()[pos_nodo_origen][pos_nodo_intermedio];

			if (coste != Inf) // hay camino al nodo intermedio
			{
				return recursivePath(origen, nodo_intermedio) + nodo_intermedio
						+ recursivePath(nodo_intermedio, destino);
			}

		}

		return "\t(" + getFloydA()[pos_nodo_origen][pos_nodo_destino] + ")\t"; // no hay nodo intermedio, retornamos el coste del origen al destino de la iteracion respectiva (el origen o destino puede ser un nodo intermedio anterior!)...
	}

	public String recorridoProfundidad(T nodoOrigen)
	{
		if(!existNode(nodoOrigen))
		{
			return "";
		}
		
		boolean[] visitados = inicializar_visitados_recorridoProfundidad();
		ArrayList<T> candidatos = new ArrayList<>();
		ArrayList<T> s = new ArrayList<>();
		
		// agregar el nodoOrigen a candidatos
		candidatos.add(nodoOrigen);
		
		
		while(candidatos.size() > 0) // mientras no esten todos vistados...
		{
			T nodo_candidato = candidatos.get(0);
			
			if(visitados[getNodeTG(nodo_candidato)]) // nodo visitado en candidatos se borra de candidatos
			{
				candidatos.remove(0);
			} else
			{
				visitados[getNodeTG(nodo_candidato)] = true;
				
				candidatos.remove(0);
				
				s.add(nodo_candidato);
				
				int posicion = 0;
				
				for(int i = 0; i < numNodes; i++)
				{
					if(getEdgeTG(nodo_candidato, nodes[i]) != -1 && !visitados[i] && !nodo_candidato.equals(nodes[i])) // si hay eje entre el candidato y el nodo; el nodo no esta visitado; y no es el candidato...
					{
						candidatos.add(posicion, nodes[i]);
						posicion++;
					}
				}
			}
		}
		
		return recorridoProfundidadToString(s);
		
	}

	private String recorridoProfundidadToString(ArrayList<T> s)
	{
		String res = "";
		for(int i = 0; i < s.size(); i++)
		{
			res = res + s.get(i) + "\t";
		}
		return res;
	}

	private boolean[] inicializar_visitados_recorridoProfundidad()
	{
		boolean[] res = new boolean[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			res[i] = false;
		}
		
		return res;
	}
	
	public double excentricidad()
	{
		double res = Inf;
		
		// se aplica Floyd (distancia de coste minima de cada nodo al resto de nodos)	
		
		// buscamos en A el peso maximo de cada columna
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j) // no computamos sobre la diagonal!!!
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaMaximoExcentricidad(valoresColumna);
		}
		
		// buscamos en maximos el valor mas bajo y retornamos dicho valor
		for(int i = 0; i < numNodes; i++)
		{
			if(maximos[i] < res)
			{
				res = maximos[i];
			}
		}
		
		return res;
	}

	private double buscaMaximoExcentricidad(double[] valoresColumna)
	{
		double res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(valoresColumna[i] > res)
			{
				res = valoresColumna[i];
			}
		}
		
		return res;
	}
	
	public T centroGrafo()
	{
		T res = null;
		double min = Inf;
		
		// Se aplica Floyd (distancia de coste minima de cada nodo al resto de nodos)
		
		// El centro de un grafo es el nodo de excentricidad minima 
		
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j) // no computamos con la diagonal!!!
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaMaximoExcentricidad(valoresColumna);
		}
		
		for(int i = 0; i < numNodes; i++)
		{
			if(maximos[i] < min)
			{
				res = nodes[i];
				min = maximos[i];
			}
		}
		
		return res;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<String> prim(T nodoOrigen)
	{
		ArrayList<String> res = new ArrayList<>();
		
		// partiendo de un nodo buscamos su eje con el menor coste que conecte con otro nodo no visitado
		boolean[] visitados = inicializar_visitados_prim();
		
		// ponemos a visitado el nodoOrigen
		visitados[getNodeTG(nodoOrigen)] = true;
		
		T[] nodosInicio = (T[]) new Object[numNodes];
		
		for(int i = 0; i < numNodes-1; i++)
		{
			nodosInicio[i] = nodoOrigen;
			
			// buscar el eje con origen el nodoOrigenDeLaIteracion y destino cualquiera accesible desde el nodo hablado
			T nodoComienzo = nodoOrigen;
			
			T nodoFinal = buscaNodosDestino(nodoComienzo, visitados);
			
			String texto_comienzo = nodoComienzo + "";
			String texto_final = nodoFinal + "";
			
			res.add(texto_comienzo + texto_final);
			
			visitados[getNodeTG(nodoFinal)] = true;
			
			nodoOrigen = nodoFinal;
		}
		
		return res;
	}

	private T buscaNodosDestino(T nodoComienzo, boolean[] visitados)
	{
		T res = null;
		double max = Inf;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(existEdge(nodoComienzo, getNodes()[i]) && getEdgeTG(nodoComienzo, nodes[i]) < max && !visitados[i])
			{
				res = nodes[i];
				max = getEdgeTG(nodoComienzo, nodes[i]);
			}
		}
		
		return res;
	}

	private boolean[] inicializar_visitados_prim()
	{
		return new boolean[numNodes];
	}
	
	public boolean isBuclesInNodo(T nodo)
	{
		if(!existNode(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		return getEdges()[getNodeTG(nodo)][getNodeTG(nodo)];
	}
	
	public int numBuclesGrafo()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isBuclesInNodo(nodes[i]))
			{
				contador++;
			}
		}
		return contador;
	}
	
	public boolean isSourceNode(T nodo)
	{
		// un nodo fuente es aquel que no es el nodo destino de ningun eje sino solo el origen
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodo.equals(nodes[i]) && existEdge(nodo, nodes[i]) && !existEdge(nodes[i], nodo))
			{
				return true;
			}
		}
		return false;
	}
	
	public int getNumberOfSourceNodes()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isSourceNode(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public boolean isIsolatedNode(T nodo)
	{
		if(!existNode(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodo.equals(nodes[i]) && !existEdge(nodo, nodes[i]) && !existEdge(nodes[i], nodo))
			{
				return true;
			}
		}
		return false;
	}
	
	public int getNumberOfIsolatedNodes()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isIsolatedNode(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public DijkstraDataClass dijkstra2(T nodoOrigen)
	{
		// camino de coste minimo de un nodoOrigen al resto de nodos
		
		if(!existNode(nodoOrigen))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(nodoOrigen == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		double[] D_dijkstra = inicializar_D_Dijkstra2(nodoOrigen); // almacena los costes
		int[] P_dijkstra = inicializar_P_Dijkstra2(nodoOrigen); // almacena los indices de los nodos desde los que se accede a cada nodo
																// SE INICIALIZA CON -1 LAS CASILLAS DE LOS NODOS A LOS QUE NO SE LLEGA 
																// DESDE EL NODO ORIGEN Y EL RESTO DE CASILLAS A LAS QUE SI SON ACCESIBLES 
																// DIRECTAMENTE DESDE NODO ORIGEN LAS INICIALIZAMOS CON EL INDICE DEL NODO ORIGEN
		
		ArrayList<T> S = new ArrayList<>();
		boolean[] visitados = inicializar_visitados_dijkstra2();
		
		S.add(nodoOrigen);
		visitados[getNodeTG(nodoOrigen)] = true;
		
		
		while(!isAllVisited(visitados))
		{
			// Paso 2: buscar un nodo w perteneciente a S-nodos tal que su D[w] sea minimo
			T nodo_pivote = buscar_Pivote_Dijkstra2(D_dijkstra, visitados);
			int index_nodo_pivote = getNodeTG(nodo_pivote);
			
			// lo agregamos a S y lo marcamos como visitado
			S.add(nodo_pivote);
			visitados[index_nodo_pivote] = true;
			
			// Paso 3: para un nodo m de nodos-S calcular...
			for(int i = 0; i < numNodes; i++)
			{
				if(!visitados[i]) // si no es un nodo pivote(no esta visitado)
				{
					int index_nodo_m = i;
					
					// d[m] --> min(d[m], d[pivote] + weights[pivote][m])
					if(D_dijkstra[index_nodo_pivote] + getWeights()[index_nodo_pivote][index_nodo_m] < D_dijkstra[index_nodo_m])
					{
						D_dijkstra[index_nodo_m] = D_dijkstra[index_nodo_pivote] + getWeights()[index_nodo_pivote][index_nodo_m]; // actualizamos D
						P_dijkstra[index_nodo_m] = index_nodo_pivote; // actualizamos P
					}
				}
			}
		}
		
		return new DijkstraDataClass(numNodes, getNodeTG(nodoOrigen), D_dijkstra, P_dijkstra);
		
	}
	
	private boolean isAllVisited(boolean[] visitados)
	{
		for(int i = 0; i < visitados.length; i++)
		{
			if(!visitados[i])
			{
				return false;
			}
		}
		return true;
	}

	private T buscar_Pivote_Dijkstra2(double[] d_dijkstra, boolean[] visitados)
	{
		T res = null;
		double corte = Inf;
		
		for(int i = 0; i < d_dijkstra.length; i++)
		{
			if(!visitados[i] && d_dijkstra[i] <= corte) // nodo no visitado y coste mas bajo que el corte...
			{
				res = nodes[i];
				corte = d_dijkstra[i];
			}
		}
		
		return res;
	}

	private boolean[] inicializar_visitados_dijkstra2()
	{
		return new boolean[numNodes];
	}

	private int[] inicializar_P_Dijkstra2(T nodoOrigen)
	{
		int[] res = new int[numNodes];

		for (int i = 0; i < numNodes; i++)
		{
			if(getEdges()[getNodeTG(nodoOrigen)][i]) // hay eje del nodoOrigen a otro nodo...
			{
				res[i] = getNodeTG(nodoOrigen); // indice del nodoOrigen
			} else // si no hay eje del nodoOrigen a otro nodo o el indice del nodoOrigen es el
					// mismo que i...
			{
				res[i] = -1; // no se llega
			}
		}

		return res;
	}

	private double[] inicializar_D_Dijkstra2(T nodoOrigen)
	{
		double[] res = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getNodeTG(nodoOrigen) == i)
			{
				res[i] = 0;
				continue;
			}
			res[i] = getWeights()[getNodeTG(nodoOrigen)][i];
		}
		
		return res;
	}

	public boolean floyd2()
	{
		if(numNodes == 0) // grafo vacio
		{
			return false;
		}
		
		// camino de coste minimo de cada nodo al resto de nodos
		this.A_floyd = inicializar_A_floyd2(); // matriz de pesos
		this.P_floyd = inicializar_P_floyd2(); // matriz con los indices de los nodos desde los que se accede
		
		// para cada nodo del grafo hacer...
		for(int a = 0; a < numNodes; a++)
		{
			for(int i = 0; i < numNodes; i++)
			{
				for(int j = 0; j < numNodes; j++)
				{
					if(i != j && i != a && j != a) // que no se seleccione la diagonal; ni la fila del pivote; ni la columna del pivote
					{
						// A[i][j] --> min(A[i][j], A[i][a] + A[a][j])
						if(A_floyd[i][a] + A_floyd[a][j] < A_floyd[i][j])
						{
							A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j]; // actualizamos A
							P_floyd[i][j] = a;
						}
					}
				}
			}
		}
		
		return true;
	}
	
	private int[][] inicializar_P_floyd2()
	{
		int[][] res = new int[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				res[i][j] = -1;
			}
		}
		
		return res;
	}

	private double[][] inicializar_A_floyd2()
	{
		double[][] res = getWeights();
		
		for(int i = 0; i < numNodes; i++)
		{
			res[i][i] = 0; // peso de ir de un nodo a si mismo es 0 (diagonal de A de ceros)
		}
		
		return res;
	}

	public double minCostPath2(T origen, T destino)
	{
		// se ejecuta floyd2 antes
		
		if (!existNode(origen))
		{
			throw new IllegalArgumentException("El elemento " + origen + " no existe en la estructura");
		}
		if (!existNode(destino))
		{
			throw new IllegalArgumentException("El elemento " + destino + " no existe en la estructura");
		}
		if(origen == null)
		{
			throw new IllegalArgumentException("Nodo origen null");
		}
		if(destino == null)
		{
			throw new IllegalArgumentException("Nodo destino null");
		}
		
		return getFloydA()[getNodeTG(origen)][getNodeTG(destino)];
	}
	
	public String path2(T origen, T destino)
	{
		if(!existNode(origen) || !existNode(destino))
		{
			return "";
		}
		
		String res = origen + "";
		
		if(origen.equals(destino))
		{
			return res;
		}
		
		if(getFloydA()[getNodeTG(origen)][getNodeTG(destino)] == Inf) // no hay camino entre los nodos...
		{
			return res + "\t(" + Inf + ")\t" + destino;
		}
		
		return res + recursivePath2(origen, destino) + destino;
	}
	
	private String recursivePath2(T origen, T destino)
	{
		int index_nodo_intermedio = getFloydP()[getNodeTG(origen)][getNodeTG(destino)];
		T nodo_intermedio = nodes[index_nodo_intermedio];
		
		// si hay nodo intermedio... se llama recursivamente y etc
		if(index_nodo_intermedio != -1)
		{
			// si hay camino del origen al intermedio --> hay del intermedio al destino
			double coste = getFloydA()[getNodeTG(origen)][index_nodo_intermedio];
			if(coste != Inf) // hay camino del nodo origen al intermedio
			{
				return "" + recursivePath(origen, nodo_intermedio) + nodo_intermedio + 
						recursivePath(nodo_intermedio, destino);
			}
		}
		// sino retornamos el valor del coste de origen a destino (el destino u origen pueden ser un intermedio)
		return "\t(" + getFloydA()[getNodeTG(origen)][getNodeTG(destino)] + ")\t";
		
	}

	public boolean addNode2(T nodo)
	{
		if(nodo == null)
		{
			throw new NullPointerException();
		}
		
		if(nodes.length == numNodes)
		{
			throw new IllegalArgumentException("Nodo no insertado porque la estructura (grafo) ya esta llena");
		}
		
		if(existNode(nodo))
		{
			return false;
		}
		
		nodes[numNodes] = nodo;
		numNodes++;
		
		for(int i = 0; i < numNodes; i++)
		{
			weights[i][numNodes-1] = Inf;
			weights[numNodes-1][i] = Inf;
			
			edges[i][numNodes-1] = false;
			edges[numNodes-1][i] = false;
		}
		
		return true;
	}
	
	protected int getNode2(T nodo)
	{
		for(int i = 0; i < numNodes; i++)
		{
			if(nodes[i].equals(nodo))
			{
				return i;
			}
		}
		return -1;
	}
	
	public boolean existNode2(T nodo)
	{
		for(int i = 0; i < numNodes; i++)
		{
			if(nodes[i].equals(nodo))
			{
				return true;
			}
		}
		return false;
	}
	
	public double getEdge2(T origen, T destino)
	{
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		if(!edges[getNode2(origen)][getNode2(destino)])
		{
			return -1;
		}
		return weights[getNode2(origen)][getNode2(destino)];
	}
	
	public boolean existEdge2(T origen, T destino)
	{
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		return edges[getNode2(origen)][getNode2(destino)];
	}
	
	public boolean addEdge2(T origen, T destino, double peso)
	{
		if(peso < 0)
		{
			throw new IllegalArgumentException("Peso del eje negativo");
		}
		
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		if(existEdge2(origen, destino))
		{
			return false;
		}
		
		weights[getNode2(origen)][getNode2(destino)] = peso;
		edges[getNode2(origen)][getNode2(destino)] = true;
		
		return true;
	}
	
	public boolean removeNode2(T nodo)
	{
		if(nodo == null)
		{
			throw new NullPointerException();
		}
		
		if(!existNode2(nodo))
		{
			return false;
		}
		
		int index_remove_node = getNode2(nodo);
		nodes[index_remove_node] = nodes[numNodes-1];
		
		for(int i = 0; i < numNodes; i++)
		{
			weights[i][index_remove_node] = weights[i][numNodes-1];
			weights[index_remove_node][i] = weights[numNodes-1][i];
			
			weights[i][numNodes-1] = Inf;
			weights[numNodes-1][i] = Inf;
			
			edges[i][index_remove_node] = edges[i][numNodes-1];
			edges[index_remove_node][i] = edges[numNodes-1][i];
			
			edges[i][numNodes-1] = false;
			edges[numNodes-1][i] = false;
		}
		numNodes--;
		
		return true;
	}
	
	public boolean removeEdge2(T origen, T destino)
	{
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		if(!existEdge2(origen, destino))
		{
			return false;
		}
		
		weights[getNode2(origen)][getNode2(destino)] = Inf;
		edges[getNode2(origen)][getNode2(destino)] = false;
		
		return true;
	}
	
	public double Excentricidad2(T nodo)
	{
		// se aplica Floyd antes (lo hacemos en los test)
		double res = 0;
		
		// la excentricidad de un nodo es la mayor distancia entre ese nodo y el resto de nodos del grafo
		// para ello se miran los valores de la columna del nodo pasado por parametro en la matriz A de Floyd
		
		for(int i = 0; i < numNodes; i++)
		{
			if(i != getNodeTG(nodo))
			{
				if(getFloydA()[i][getNodeTG(nodo)] > res)
				{
					res = getFloydA()[i][getNodeTG(nodo)];
				}
			}
		}
		
		return res;
	}
	
	public T centroGrafo2()
	{
		// se aplica Floyd antes (lo hacemos en los tests)
		
		// el centro de un grafo es el nodo con menor excentricidad
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j)
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaMaximoExcentricidad2(valoresColumna);
		}
		
		return buscaExcentricidadMinima2(maximos);
	}

	private T buscaExcentricidadMinima2(double[] maximos)
	{
		double cotaSuperior = Inf;
		T res = null;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(maximos[i] < cotaSuperior)
			{
				cotaSuperior = maximos[i];
				res = nodes[i];
			}
		}
		
		return res;
	}

	private double buscaMaximoExcentricidad2(double[] valoresColumna)
	{
		double res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(valoresColumna[i] > res)
			{
				res = valoresColumna[i];
			}
		}
		
		return res;
	}
	
	public double longitudCaminoMasCorto(T origen, T destino)
	{
		// se aplica Floyd antes de tal forma que la matriz A se inicializa con un 1 en aquellas 
		// posiciones donde hay un valor de peso que no sea infinito. La diagonal sigue siendo cero
		
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		if(origen.equals(destino))
		{
			return 0; // el coste de ir de un nodo a si mismo es de 0
		}
		
		if(floydParaCaminoMasCorto())
		{
			int contador = 1;
			
			String res = path2(origen, destino);
			
			String[] palabras = res.split("\t");
			
			if(palabras[1].equals("(" + Inf + ")"))
			{
				return Inf;
			}
			
			// va de dos en dos empezando en el 0 (0,2,4,...)
			
			for(int i = 0; i < palabras.length; i = i + 2)
			{
				contador++;
			}
			
			return contador;
		}
		return -1;
	}

	private boolean floydParaCaminoMasCorto()
	{
		if(numNodes == 0)
		{
			return false;
		}
		
		this.A_floyd = inicializar_A_floyd_camino_corto();
		this.P_floyd = inicializar_P_floyd_camino_corto();
		
		for(int a = 0; a < numNodes; a++) // para cada nodo del grafo...
		{
			for(int i = 0; i < numNodes; i++)
			{
				for(int j = 0; j < numNodes; j++)
				{
					if(i != j && i != a && j != a) // no operamos con las diagonales; columna y fila distinta a la del pivote
					{
						// A[i][j] --> min(A[i][j], A[i][a] + A[a][j])
						if(A_floyd[i][a] + A_floyd[a][j] < A_floyd[i][j])
						{
							A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j]; // actualizamos A
							P_floyd[i][j] = a; // actualizamos P
						}
					}
				}
			}
		}
		return true;
	}

	private int[][] inicializar_P_floyd_camino_corto()
	{
		int[][] res = new int[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				res[i][j] = -1;
			}
		}
		
		return res;
	}

	private double[][] inicializar_A_floyd_camino_corto()
	{
		// inicializamos con un 1 en aquellas posiciones donde hay un valor de peso que no sea infinito
		double[][] res = new double[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				if(i == j)
				{
					res[i][j] = 0; // la diagonal sigue siendo 0
				} else
				{
					if(getWeights()[i][j] != Inf)
					{
						res[i][j] = 1;
					} else
					{
						res[i][j] = Inf;
					}
				}
			}
		}
		
		return res;
	}
	
	public String recorridoProfundidad2(T nodoOrigen)
	{
		if(!existNode(nodoOrigen))
		{
			return "";
		}
		
		
		ArrayList<T> recorrido = new ArrayList<>();
		boolean[] visitados = new boolean[numNodes];
		ArrayList<T> candidatos = new ArrayList<>();
		
		candidatos.add(nodoOrigen);
		
		while(candidatos.size() > 0)
		{
			T nodo_pivote = candidatos.get(0);
			
			if(visitados[getNodeTG(nodo_pivote)])
			{
				candidatos.remove(0);
			} else
			{
				recorrido.add(nodo_pivote);
				
				candidatos.remove(0);
				
				visitados[getNodeTG(nodo_pivote)] = true;
				
				int posicion = 0;
				
				for(int i = 0; i < numNodes; i++)
				{
					if(!visitados[i] && existEdge(nodo_pivote, nodes[i]) && !nodo_pivote.equals(nodes[i])) // nodo no visitado; hay eje entre nodo_pivote y otro nodo; el nodo no es el pivote...
					{
						candidatos.add(posicion, nodes[i]);
						posicion++;
					}
				}
			}
		}
		
		return recorridoProfundidad2ToString(recorrido);
	}

	private String recorridoProfundidad2ToString(ArrayList<T> recorrido)
	{
		String res = "";
		
		for(int i = 0; i < recorrido.size(); i++)
		{
			res = res + recorrido.get(i) + "\t";
		}
		
		return res;
	}
	
	
	public DijkstraDataClass dijkstra3(T nodoOrigen)
	{
		double[] D_dijkstra = inicializar_D_Dijkstra3(nodoOrigen);
		int[] P_dijkstra = inicializar_P_Dijkstra3(nodoOrigen);
		
		boolean[] visitados = new boolean[numNodes];
		visitados[getNode2(nodoOrigen)] = true;
		
		while(!isTodosVisitados(visitados))
		{
			// Paso 2: buscar nodo w de nodes-S (no visitado) tal que su D[w] sea minimo
			T nodo_pivote = buscarNodoPivote(D_dijkstra, visitados);
			int index_nodo_pivote = getNode2(nodo_pivote);
			
			visitados[index_nodo_pivote] = true;
			
			// Paso 3: para cada nodo m de nodes-S (no visitado) calcular...
			for(int i = 0; i < numNodes; i++)
			{
				if(!visitados[i] && !nodes[i].equals(nodo_pivote)) // nodo no visitado; nodo no es el pivote
				{
					// D[m] --> min(D[m], D[pivote] + weights[pivote][m])
					if(D_dijkstra[index_nodo_pivote] + weights[index_nodo_pivote][i] < D_dijkstra[i])
					{
						D_dijkstra[i] = D_dijkstra[index_nodo_pivote] + weights[index_nodo_pivote][i]; // actualizamos D
						P_dijkstra[i] = index_nodo_pivote; // actualizamos P
					}
				}
			}
			
		}
		
		return new DijkstraDataClass(numNodes, getNode2(nodoOrigen), D_dijkstra, P_dijkstra);
	}
	
	private T buscarNodoPivote(double[] d_dijkstra, boolean[] visitados)
	{
		T res = null;
		double cota = Inf;
		
		for(int i = 0; i < visitados.length; i++)
		{
			if(!visitados[i] && d_dijkstra[i] <= cota) // no esta visitado; coste mas bajo que la cota
			{
				cota = d_dijkstra[i];
				res = nodes[i];
			}
		}
		
		return res;
	}

	private boolean isTodosVisitados(boolean[] visitados)
	{
		for(int i = 0; i < visitados.length; i++)
		{
			if(!visitados[i])
			{
				return false;
			}
		}
		return true;
	}

	private int[] inicializar_P_Dijkstra3(T nodoOrigen)
	{
		int[] res = new int[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(i == getNode2(nodoOrigen))
			{
				res[i] = -1;
			} else
			{
				if(existEdge(nodoOrigen, nodes[i]))
				{
					res[i] = getNode2(nodoOrigen);
				} else
				{
					res[i] = -1;
				}
			}
		}
		
		return res;
	}

	private double[] inicializar_D_Dijkstra3(T nodoOrigen)
	{
		double[] res = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			if(i == getNode2(nodoOrigen))
			{
				res[i] = 0;
			} else
			{
				res[i] = getWeights()[getNode2(nodoOrigen)][i];
			}
		}
		
		return res;
	}

	public boolean isSourceNode2(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		// un nodo fuente es aquel que no es el destino de ningun eje pero si el origen de, al menos, 
		// un eje
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodes[i].equals(nodo) && existEdge(nodo, nodes[i]) && !existEdge(nodes[i], nodo)) // que el nodo destino no sea el origen
			{
				return true;
			}
		}
		return false;
	}
	
	public boolean isDrainNode2(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		// un nodo sumidero es aquel que no es el origen de ningun eje pero si el destino de, al menos,
		// un eje
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodes[i].equals(nodo) && existEdge2(nodes[i], nodo) && !existEdge2(nodo, nodes[i])) // que el nodo origen no sea el destino
			{
				return true;
			}
		}
		return false;
	}
	
	public boolean isIsolatedNode2(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		// un nodo aislado es aquel que no es el destino ni el origen de ningun eje
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodes[i].equals(nodo) && !existEdge2(nodes[i], nodo) && !existEdge2(nodo, nodes[i])) // que el nodo origen no sea el destino
			{
				return true;
			}
		}
		return false;
	}
	
	public int getNumberOfSourceNodes2()
	{
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isSourceNode2(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public int getNumberOfDrainNodes2()
	{
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isDrainNode2(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public int getNumberOfIsolatedNodes2()
	{
		int contador = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isIsolatedNode2(nodes[i]))
			{
				contador++;
			}
		}
		
		return contador;
	}
	
	public int getNodeGrade(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		// el grado de un nodo es la suma de el numero de entradas y de salidas de ese nodo
		int grado_entrada = getGradoEntradaNodo(nodo);
		int grado_salida = getGradoSalidaNodo(nodo);
		
		return grado_entrada + grado_salida;
	}
	
	private int getGradoSalidaNodo(T nodo)
	{
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodes[i].equals(nodo) && existEdge(nodes[i], nodo) && !existEdge(nodo, nodes[i]))
			{
				res++;
			}
		}
		
		return res;
	}

	private int getGradoEntradaNodo(T nodo)
	{
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(!nodes[i].equals(nodo) && !existEdge(nodes[i], nodo) && existEdge(nodo, nodes[i]))
			{
				res++;
			}
		}
		
		return res;
	}

	public boolean isLoopInNode(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		return existEdge(nodo, nodo);
	}
	
	public int getNumberOfLoops()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(isLoopInNode(nodes[i]))
			{
				res++;
			}
		}
		
		return res;
	}
	
	public int getCardinality()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		// es el numero de ejes que tiene el grafo
		
		int res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				if(existEdge2(nodes[i], nodes[j]))
				{
					res++;
				}
			}
		}
		
		return res;
	}
	
	public int getGraphGrade()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		// es el grado mas alto de un nodo
		
		ArrayList<Integer> listaGrados = new ArrayList<>();
		
		for(int i = 0; i < numNodes; i++)
		{
			listaGrados.add(getNodeGrade(nodes[i]));
		}
		
		return buscarGradoMaximo(listaGrados);
	}
	
	private int buscarGradoMaximo(ArrayList<Integer> listaGrados)
	{
		int res = 0;
		
		for(int i = 0; i < listaGrados.size(); i++)
		{
			if(listaGrados.get(i) > res)
			{
				res = listaGrados.get(i);
			}
		}
		
		return res;
	}

	public double Excentricidad3(T nodo)
	{
		if(nodo == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		if(!existNode2(nodo))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		// se aplica floyd antes (lo hacemos en los tests)
		
		// es la distancia mas lejana desde el nodo origen al resto de nodos
		// para ello se busca el valor mas alto en la columna del nodo origen en la matriz A de floyd
		
		double res = 0;
		
		for(int i = 0; i < numNodes; i++)
		{
			if(getFloydA()[i][getNode2(nodo)] > res)
			{
				res = getFloydA()[i][getNode2(nodo)];
			}
		}
		
		return res;
	}

	public boolean floyd3()
	{
		if(numNodes == 0)
		{
			return false;
		}
		
		this.A_floyd = inicializar_A_floyd3();
		this.P_floyd = inicializar_P_floyd3();
		
		for(int a = 0; a < numNodes; a++)
		{
			for(int i = 0; i < numNodes; i++)
			{
				for(int j = 0; j < numNodes; j++)
				{
					if(i != a && j != a && i != j)
					{
						// A[i][j] --> min(A[i][j], A[i][a] + A[a][j])
						if(A_floyd[i][a] + A_floyd[a][j] < A_floyd[i][j])
						{
							A_floyd[i][j] = A_floyd[i][a] + A_floyd[a][j]; // actualizamos A
							P_floyd[i][j] = a; // actualizamos P
						}
					}
				}
			}
			
		}
		
		return true;
	}
	
	private int[][] inicializar_P_floyd3()
	{
		int[][] res = new int[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				res[i][j] = -1;
			}
		}
		
		return res;
	}

	private double[][] inicializar_A_floyd3()
	{
		double[][] res = new double[numNodes][numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			for(int j = 0; j < numNodes; j++)
			{
				if(i == j)
				{
					res[i][j] = 0;
				} else
				{
					res[i][j] = getWeights()[i][j];
				}
			}
		}
		
		return res;
	}

	public T centroGrafo3()
	{
		if(numNodes == 0)
		{
			throw new IllegalArgumentException("Grafo sin nodos");
		}
		
		// se aplica floyd antes (lo hacemos en los tests)
		
		// es el nodo con menor excentricidad
		T res = null;
		double cota = Inf;
		
		double[] maximos = new double[numNodes];
		
		for(int i = 0; i < numNodes; i++)
		{
			double[] valoresColumna = new double[numNodes];
			
			for(int j = 0; j < numNodes; j++)
			{
				if(i != j) // no operamos con la diagonal
				{
					valoresColumna[j] = getFloydA()[j][i];
				}
			}
			
			maximos[i] = buscaValorMaximo(valoresColumna);
		}
		
		for(int i = 0; i < maximos.length; i++)
		{
			if(maximos[i] < cota)
			{
				cota = maximos[i];
				res = nodes[i];
			}
		}
		
		return res;
	}
	
	private double buscaValorMaximo(double[] valoresColumna)
	{
		double res = 0;
		
		for(int i = 0; i < valoresColumna.length; i++)
		{
			if(valoresColumna[i] > res)
			{
				res = valoresColumna[i];
			}
		}
		
		return res;
	}

	public double getLongitudCaminoMasCorto(T origen, T destino)
	{
		if(origen == null || destino == null)
		{
			throw new IllegalArgumentException("Nodo null");
		}
		
		if(!existNode(origen) || !existNode(destino))
		{
			throw new IllegalArgumentException("Nodo no existente en el grafo");
		}
		
		double contador = 0;
		
		String camino = path2(origen, destino);
		
		String[] palabras = camino.split("\t");
		
		if(palabras[1].equals("(" + Inf + ")"))
		{
			return Inf;
		}
		
		for(int i = 0; i < palabras.length + 1; i++)
		{
			contador++;
		}
		
		return contador;
	}
}
