package tutoriaGrupalGrafos2023;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GraphFloydTest {

	@Test
	public void T1_testFloyd() {
		System.out.println("Pruebas evaluaci�n Floyd");
		GraphTG2023<String> G = new GraphTG2023<String>(8);
		
		// Grafo vacio
		assertFalse(G.floyd());
		
		// Insertar nodos
		for (int i = 0; i < 8; i++) {
			assertTrue(G.addNodeTG("Nodo " + (char) ('A' + i)));
		}

		assertTrue(G.addEdgeTG("Nodo A", "Nodo C", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo E", 8));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C", 2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo D", 5));
		
		assertTrue(G.addEdgeTG("Nodo C", "Nodo A", 6));
		assertTrue(G.addEdgeTG("Nodo C", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F", 9));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo H", 1));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo C", 4));
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo D", 1));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo H", 9));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo F", 3));
		System.out.println(G.toString());

		// Floyd
		G.floyd();
		System.out.println("FLOYD\n");
		double A[][] = G.getFloydA();
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (A[i][j] == Float.POSITIVE_INFINITY)
					System.out.print("--\t");
				else
					System.out.print(A[i][j] + "\t");
			}
			System.out.println();
		}

		double salida[][] = {
				{ 0.0, Float.POSITIVE_INFINITY, 3.0, 3.0, 8.0, 7.0, 5.0, 4.0 },
				{ 8.0, 0.0, 2.0, 5.0, 16.0, 9.0, 4.0, 6.0 },
				{ 6.0, Float.POSITIVE_INFINITY, 0.0, 9.0, 14.0, 13.0, 2.0, 10.0 },
				{ Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
						Float.POSITIVE_INFINITY, 0.0, Float.POSITIVE_INFINITY,
						4.0, Float.POSITIVE_INFINITY, 1.0 },
				{ 10.0, Float.POSITIVE_INFINITY,4.0, 13.0, 0.0, 17.0, 2.0, 14.0 },
				{ Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
						Float.POSITIVE_INFINITY, 1.0 ,
						Float.POSITIVE_INFINITY, 0.0, Float.POSITIVE_INFINITY,
						2.0 },
				{ Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
						Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
						Float.POSITIVE_INFINITY, 0.0, Float.POSITIVE_INFINITY },
				{ Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
						Float.POSITIVE_INFINITY, 4.0,
						Float.POSITIVE_INFINITY, 3.0, Float.POSITIVE_INFINITY,
						0.0 } };
		assertArrayEquals(salida,A);
	}
	
	@Test
	public void T2_testMinCostPath() {
		System.out.println("Pruebas evaluaci�n MinCostPath");
		GraphTG2023<String> G = new GraphTG2023<String>(8);

		// Insertar nodos
		for (int i = 0; i < 8; i++) {
			assertTrue(G.addNodeTG("Nodo " + (char) ('A' + i)));
		}

		assertTrue(G.addEdgeTG("Nodo A", "Nodo C", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo E", 8));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C", 2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo D", 5));
		
		assertTrue(G.addEdgeTG("Nodo C", "Nodo A", 6));
		assertTrue(G.addEdgeTG("Nodo C", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F", 9));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo H", 1));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo C", 4));
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo D", 1));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo H", 9));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo F", 3));
		System.out.println(G.toString());

		G.floyd();
		
		// minCostPath
		assertEquals(0,G.minCostPath("Nodo B", "Nodo A"),8.0);
		assertEquals(0,G.minCostPath("Nodo H", "Nodo F"),3.0);
		assertEquals(Float.POSITIVE_INFINITY,G.minCostPath("Nodo H", "Nodo A"),Float.POSITIVE_INFINITY);
		// El primer nodo no existe
		try {
			G.minCostPath("Nodo J", "Nodo A");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("El elemento Nodo J no existe en la estructura",e.getMessage());
		}
		
		// El segundo nodo no existe
		try {
			G.minCostPath("Nodo A", "Nodo P");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			assertEquals("El elemento Nodo P no existe en la estructura",e.getMessage());
		}

		
	}
	
	@Test
	public void T3_testPath() {
		System.out.println("Pruebas evaluaci�n Path");
		GraphTG2023<String> G = new GraphTG2023<String>(8);

		// Insertar nodos
		for (int i = 0; i < 8; i++) {
			assertTrue(G.addNodeTG("Nodo " + (char) ('A' + i)));
		}

		assertTrue(G.addEdgeTG("Nodo A", "Nodo C", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D", 3));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo E", 8));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C", 2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo D", 5));
		
		assertTrue(G.addEdgeTG("Nodo C", "Nodo A", 6));
		assertTrue(G.addEdgeTG("Nodo C", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F", 9));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo H", 1));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo C", 4));
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G", 2));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo D", 1));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo H", 9));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo F", 3));
		System.out.println(G.toString());
		
		G.floyd();
		
		// Mismo nodo
		System.out.print("De Nodo A a Nodo A --> ");
		System.out.println(G.path("Nodo A", "Nodo A"));
		assertEquals("Nodo A",G.path("Nodo A", "Nodo A"));
		// No hay camino
		System.out.print("De Nodo A a Nodo B --> ");
		System.out.println(G.path("Nodo A", "Nodo B"));
		assertEquals("Nodo A\t(Infinity)\tNodo B",G.path("Nodo A", "Nodo B"));
		// No existen los nodos
		System.out.print("De Nodo A a Nodo J --> ");
		System.out.println(G.path("Nodo A", "Nodo J"));
		assertEquals("",G.path("Nodo A", "Nodo J"));
		System.out.print("De Nodo J a Nodo A --> ");
		System.out.println(G.path("Nodo J", "Nodo A"));
		assertEquals("",G.path("Nodo J", "Nodo A"));
		System.out.print("De Nodo J a Nodo K --> ");
		System.out.println(G.path("Nodo J", "Nodo K"));
		assertEquals("",G.path("Nodo J", "Nodo K"));

		// Existen los nodos y hay camino
		System.out.print("De Nodo E a Nodo D --> ");
		System.out.println(G.path("Nodo E", "Nodo D"));
		System.out.println(G.minCostPath("Nodo E", "Nodo D"));
		assertEquals("Nodo E\t(4.0)\tNodo C\t(6.0)\tNodo A\t(3.0)\tNodo D",G.path("Nodo E", "Nodo D"));
	}
	
	@Test
	public void T4_testExcentricidad() {
		System.out.println("Pruebas evaluaci�n Excentricidad");
		GraphTG2023<String> G = new GraphTG2023<String>(8);

		// Insertar nodos
		for (int i = 0; i < 4; i++) {
			assertTrue(G.addNodeTG("Nodo " + (char) ('A' + i)));
		}

		assertTrue(G.addEdgeTG("Nodo A", "Nodo B", 2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo C", 8));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C", 3));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo D", 6));
		
		assertTrue(G.addEdgeTG("Nodo C", "Nodo D", 1));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo B", 2));
		System.out.println(G.toString());
		
		G.floyd();
		System.out.println("FLOYD\n");
		double A[][] = G.getFloydA();
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (A[i][j] == Float.POSITIVE_INFINITY)
					System.out.print("--\t");
				else
					System.out.print(A[i][j] + "\t");
			}
			System.out.println();
		}
		
		assertEquals(3, G.excentricidad(), 1.0);
	}
	
	@Test
	public void T5_testCentroGrafo() {
		System.out.println("Pruebas evaluaci�n Centro grafo");
		GraphTG2023<String> G = new GraphTG2023<String>(8);

		// Insertar nodos
		for (int i = 0; i < 4; i++) {
			assertTrue(G.addNodeTG("Nodo " + (char) ('A' + i)));
		}

		assertTrue(G.addEdgeTG("Nodo A", "Nodo B", 2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo C", 8));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C", 3));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo D", 6));
		
		assertTrue(G.addEdgeTG("Nodo C", "Nodo D", 1));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo B", 2));
		System.out.println(G.toString());
		
		G.floyd();
		System.out.println("FLOYD\n");
		double A[][] = G.getFloydA();
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (A[i][j] == Float.POSITIVE_INFINITY)
					System.out.print("--\t");
				else
					System.out.print(A[i][j] + "\t");
			}
			System.out.println();
		}
		
		assertEquals("Nodo B", G.centroGrafo());
	}
}
	

