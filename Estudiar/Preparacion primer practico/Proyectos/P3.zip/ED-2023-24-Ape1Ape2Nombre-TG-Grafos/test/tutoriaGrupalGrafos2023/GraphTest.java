package tutoriaGrupalGrafos2023;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GraphTest {
	@Test
	public void T2_testAdd() {
		System.out.println("T2 -->TestAdd ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(8);
		
		// Insertar nodos correctamente
		for (int i=0;i<6;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// Muestra el grafo
		System.out.print(G.toString());

		//Inserta un Null
		try {
			G.addNodeTG(null);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("Element to insert is null.",e.getMessage());
		}
		//Insertar un nodo que ya existe
		assertFalse(G.addNodeTG("Nodo A"));

		//Sigo insertando
		assertTrue(G.addNodeTG("Nodo G"));
		assertTrue(G.addNodeTG("Nodo H"));	
		//No hay espacio
		try{
			assertTrue(G.addNodeTG("E"));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			//assertEquals("El elemento E no se puede insertar porque la estructura est� llena",e.getMessage());
		}
	}		

	@Test
	public void T3_testGetNode() {
		System.out.println("T3 -->TestGetNode ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// El nodo no existe
		assertEquals(-1,G.getNodeTG("Nodo W"));
		
		// El nodo existe
		for (int i=0;i<8;i++){
			assertEquals(i,G.getNodeTG("Nodo "+(char)('A'+i)));			
		}
	}
	
	@Test
	public void T4_testAddEdge() {
		System.out.println("T4 -->TestAddEdge ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// No exiten los nodos
		try {
			G.addEdgeTG("W","I",5.0);
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento W no existe en la estructura",e.getMessage());
		}
		
		// Existen los nodos pero el peso es negativo
		try {
			assertTrue(G.addEdgeTG("Nodo A", "Nodo B",-2));
			fail();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
//			assertEquals("Weight edge could not be less or equals to 0",e.getMessage());
		}
		
		// Inserta ejes
		assertTrue(G.addEdgeTG("Nodo A", "Nodo B",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo E",1));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdgeTG("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo C",1));
		
		// Muestra el grafo
		System.out.print(G.toString());
		
		//Inserta un eje que ya existe
		assertFalse(G.addEdgeTG("Nodo H", "Nodo C",1));
		
		// No exiten el primer nodo
		try {
			G.getEdgeTG("Nodo W","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
//			assertEquals("El elemento Nodo W no existe en la estructura",e.getMessage());
		}
		
		// Existe el primer nodo pero no el segundo
		try {
			G.getEdgeTG("Nodo A","Nodo I");
			fail();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			//assertEquals("El elemento Nodo I no existe en la estructura",e.getMessage());
		}
		
		//Existen los nodos pero no el eje
		assertEquals(-1, G.getEdgeTG("Nodo A","Nodo H"),0.0);
		
		// El eje existe
		assertEquals(2,G.getEdgeTG("Nodo A", "Nodo B"),0.0);
		assertEquals(2,G.getEdgeTG("Nodo A", "Nodo D"),0.0);
		assertEquals(4,G.getEdgeTG("Nodo A", "Nodo F"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo B", "Nodo C"),0.0);
		assertEquals(5,G.getEdgeTG("Nodo B", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdgeTG("Nodo D", "Nodo E"),0.0);
		assertEquals(4,G.getEdgeTG("Nodo D", "Nodo F"),0.0);
		
		assertEquals(6,G.getEdgeTG("Nodo E", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo F", "Nodo C"),0.0);
		assertEquals(3,G.getEdgeTG("Nodo F", "Nodo G"),0.0);
		
		assertEquals(2,G.getEdgeTG("Nodo G", "Nodo H"),0.0);
		
		assertEquals(1,G.getEdgeTG("Nodo H", "Nodo C"),0.0);
	}		
	
	@Test
	public void T5_testGetEdge() {
		System.out.println("T5 -->TestGetEdge ********************\n");
		GraphTG2023<String> G=new GraphTG2023<String>(10);
		
		// Insertar nodos correctamente
		for (int i=0;i<8;i++){
			assertTrue(G.addNodeTG("Nodo "+(char)('A'+i)));			
		}
		
		// Inserta ejes
		assertTrue(G.addEdgeTG("Nodo A", "Nodo B",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo D",2));
		assertTrue(G.addEdgeTG("Nodo A", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo B", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo B", "Nodo H",5));
		
		assertTrue(G.addEdgeTG("Nodo D", "Nodo E",1));
		assertTrue(G.addEdgeTG("Nodo D", "Nodo F",4));
		
		assertTrue(G.addEdgeTG("Nodo E", "Nodo G",6));
		
		assertTrue(G.addEdgeTG("Nodo F", "Nodo C",2));
		assertTrue(G.addEdgeTG("Nodo F", "Nodo G",3));
		
		assertTrue(G.addEdgeTG("Nodo G", "Nodo H",2));
		
		assertTrue(G.addEdgeTG("Nodo H", "Nodo C",1));
	}
}