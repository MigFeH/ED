package BST;

import org.junit.jupiter.api.Test;

class TestNode {

	@Test
	void test()
	{
		// Crear un nodo sin hijos
		System.out.println("Nodo sin hijos");
		
		BSTNode<String> N = new BSTNode<>("Nodo Uno");
		System.out.println(N.toString());
		
		if(N.getLeft() == null)
		{
			System.out.println("El hijo izquierdo es null");
		}
		
		if(N.getRight() == null)
		{
			System.out.println("El hijo derecho es null");
		}
		
		// --------------- NODO CON HIJO DERECHO --------------- //
		
		// Un nodo con hijo derecho
		System.out.println("\nNodo con hijo derecho");
		
		BSTNode<Integer> N1 = new BSTNode<>(10);
		System.out.println("Nodo :" + N1.toString());
		
		// Asignar un nodo por la derecha
		BSTNode<Integer> N1der = new BSTNode<>(15);
		N1.setRight(N1der);
		
		if(N1.getLeft() == null)
		{
			System.out.println("El hijo izquierdo es null");
		} else
		{
			System.out.println("Hijo izquierdo: " + N1.getLeft().toString());
		}
		
		if(N1.getRight() == null)
		{
			System.out.println("El hijo derecho es null");
		} else
		{
			System.out.println("Hijo derecho: " + N1.getRight().toString());
		}
		
		// --------------- NODO CON HIJO DERECHO E IZQUIERDO --------------- //
		
		// Un nodo con hijo derecho e izquierdo
		System.out.println("\nNodo con hijo derecho e izquierdo");

		BSTNode<Integer> N2 = new BSTNode<>(10);
		System.out.println("Nodo: " + N2.toString());

		// Asignar un nodo por la derecha
		BSTNode<Integer> N2der = new BSTNode<>(15);
		N2.setRight(N2der);
		N2.setLeft(new BSTNode<Integer>(5));
		if(N2.getLeft() == null)
		{
			System.out.println("El hijo izquierdo es null");
		} else
		{
			System.out.println("Hijo izquierdo: " + N2.getLeft().toString());
		}

		if(N2.getRight() == null)
		{
			System.out.println("El hijo derecho es null");
		} else
		{
			System.out.println("Hijo derecho: " + N2.getRight().toString());
		}
		
		
	}

}
