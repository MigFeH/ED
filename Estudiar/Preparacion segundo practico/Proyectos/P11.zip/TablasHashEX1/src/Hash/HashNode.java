package Hash;

public class HashNode<T>
{
	// implementa un elemento de una tabla hash
	public static final int BORRADO = -1;
	public static final int VACIO = 0;
	public static final int LLENO = 1;
	
	private T info; // el contenido de un elemento de la tabla hash
	private int estado; /* el estado de un elemento de la tabla hash
	 					-1: BORRADO
	 					0: VACIO
	 					1: LLENO */
	
	public HashNode()
	{
		this.info = null;
		this.estado = VACIO;
	}
	
	public T getInfo()
	{
		return this.info;
	}
	
	public void setInfo(T elemento)
	{
		this.info = elemento;
		this.estado = LLENO;
	}
	
	/**
	 * Cambia el estado del nodo de la tabla hash para que sea BORRADO, 
	 * pero no le asigna null a info
	 */
	public void remove()
	{
		this.estado = BORRADO;
	}
	
	public int getStatus()
	{
		return this.estado;
	}
	
	public String toString()
	{
		StringBuilder cadena = new StringBuilder("{");
		switch(getStatus()){
		case LLENO:
		cadena.append(info.toString());
		break;
		case VACIO:
		cadena.append("_E_");
		break;
		case BORRADO:
		cadena.append("_D_");
		}
		cadena.append("}");
		return cadena.toString();
		}

}
