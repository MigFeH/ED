package AVL;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AVLAdicionalesTest
{

	@Test
	void padreDeTest()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode(N5.getInfo()));
		assertTrue(b.addNode(N3.getInfo()));
		assertTrue(b.addNode(N7.getInfo()));
		
		assertEquals(b.search(N5.getInfo()), b.padreDe(N3.getInfo()));
		assertEquals(b.search(N5.getInfo()), b.padreDe(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode(N10.getInfo()));
		assertTrue(b.addNode(N6.getInfo()));
		
		System.out.println(b.preOrder());
		
		assertEquals(b.search(N7.getInfo()), b.padreDe(N10.getInfo()));
		
		


	}

}
