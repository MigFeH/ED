package BST;

public class BSTree <T extends Comparable <T>>
{
	private BSTNode<T> raiz; // nodo raiz del arbol (el contenido de la raiz del arbol BST)
	
	public BSTree()
	{
		this.raiz = null;
	}
	
	/**
	 * @param clave
	 * @return NullPointerException, si la clave es null.
	 * nodo completo, si lo encuentra.
	 * null, si no lo encuentra o el �rbol es null
	 */
	public BSTNode<T> search(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element null");
		}
		if(this.raiz == null)
		{
			return null;
		}
		
		return searchRec(raiz, clave);
	}
	
	/**
	 * @param nodo
	 * @param clave
	 * @return null, si no encuentra la clave.
	 * nodo completo, si la encuentra
	 */
	private BSTNode<T> searchRec(BSTNode<T> nodo, T clave)
	{
		if(nodo.getInfo() == clave)
		{
			return nodo;
		}
		// si clave < nodo => recorremos izquierda
		if(nodo.getLeft() != null && clave.compareTo(nodo.getInfo()) < 0)
		{
			return searchRec(nodo.getLeft(), clave);
		}
		
		// si clave > nodo => recorremos derecha
		if(nodo.getRight() != null && clave.compareTo(nodo.getInfo()) > 0)
		{
			return searchRec(nodo.getRight(), clave);
		}
		
		// sino => no hemos encontrado clave => retornamos null
		return null;
	}

	/**
	 * @param clave
	 * @return NullPointerException, si clave es null.
	 * false, si la clave ya existe (no la inserta).
	 * true, si inserta la clave
	 */
	public boolean addNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(this.raiz == null)
		{
			this.raiz = new BSTNode<T>(clave);
			return true;
		}
		
		return addNodeRec(raiz, clave);
	}
	
	private boolean addNodeRec(BSTNode<T> nodo, T clave)
	{
		if(nodo.getInfo() == clave) // caso basico: nodo existente en el arbol
		{
			return false;
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave < nodo...
		{
			if(nodo.getLeft() == null) // hay hueco a la izquierda del nodo...
			{
				nodo.setLeft(new BSTNode<T>(clave));
				return true;
			} else // no hay hueco a la izquierda del nodo...
			{
				return addNodeRec(nodo.getLeft(), clave);
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave > nodo...
		{
			if(nodo.getRight() == null) // hay hueco a la derecha del nodo...
			{
				nodo.setRight(new BSTNode<T>(clave));
				return true;
			} else // no hay hueco a la derecha del nodo...
			{
				return addNodeRec(nodo.getRight(), clave);
			}
		}
		
		return false; // elemento no insertado
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder()
	{
		return preOrderRec(raiz);
	}
	
	private String preOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso de parada
		{
			return "";
		}
		return nodo.toString() + "\t" + preOrderRec(nodo.getLeft()) + preOrderRec(nodo.getRight());
	}

	/**
	 * izq, der, raiz
	 */
	public String postOrder()
	{
		return postOrderRec(raiz);
	}
	
	private String postOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso de parada
		{
			return "";
		}
		return postOrderRec(nodo.getLeft()) + postOrderRec(nodo.getRight()) + nodo.toString() + "\t";
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder()
	{
		 return inOrderRec(raiz);
	}
	 
	private String inOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso de parada
		{
			return "";
		}
		return inOrderRec(nodo.getLeft()) + nodo.toString() + "\t" + inOrderRec(nodo.getRight());
	}
	
	/**
	 * @param clave
	 * @return NullPointerException, clave pasada null.
	 * false, si el arbol es null (raiz es null) o si la clave no existe en el arbol;
	 * true, si borra la clave
	 */
	public boolean removeNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(search(clave) == null || this.raiz == null) // clave no existe en el arbol || arbol vacio...
		{
			return false;
		}
		raiz = removeNodeRec(raiz, clave);
		return true;
	}

	private BSTNode<T> removeNodeRec(BSTNode<T> nodo, T clave)
	{
		// BUSQUEDA DEL NODO A BORRAR
		
		
		if(clave.compareTo(nodo.getInfo()) < 0) // a la izq
		{
			BSTNode<T> nuevo_nodo = removeNodeRec(nodo.getLeft(), clave); // devuelve el subarbol izq modificado
			nodo.setLeft(nuevo_nodo); // asignamos la actualizacion
			return nodo; // retornamos el nodo actualizado
		} else if(clave.compareTo(nodo.getInfo()) > 0) // a la der
		{
			BSTNode<T> nuevo_nodo = removeNodeRec(nodo.getRight(), clave); // devuelve el subarbol der modificado
			nodo.setRight(nuevo_nodo); // asignamos la actualizacion
			return nodo; // retornamos el nodo actualizado
		} 
		
		
		// DEVOLVEMOS EL SUSTITUTO
		
		else // nodo encontrado
		{
			if(nodo.getLeft() == null) // hijo izquierdo null => retornamos el derecho
			{
				return nodo.getRight();
			} else // hijo izquierdo existente
			{
				if(nodo.getRight() == null) // hijo derecho null => retornamos el izquierdo
				{
					return nodo.getLeft();
				} else // hijo derecho existente => hijo izquierdo y derecho existentes
				{
					BSTNode<T> mayor = mayorDelSubarbolIzquierdo(nodo.getLeft());
					nodo.setInfo(mayor.getInfo());
					BSTNode<T> nuevo_sub_izq = removeNodeRec(nodo.getLeft(), mayor.getInfo()); // para quitar el nodo repetido
					nodo.setLeft(nuevo_sub_izq); // actualizamos el subarbol izq
					return nodo;
				}
			}
		}	
	}

	private BSTNode<T> mayorDelSubarbolIzquierdo(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
		{
			nodo = nodo.getRight();
		}
		return nodo;
	}
}
