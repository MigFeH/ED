package ColasPrioridad;

public class BinaryHeap <T extends Comparable <T>> implements PriorityQueue<T>
{
	private T[] monticulo; // vector de elementos de un determinado tamaño
	private int numElementos; // numeros de elementos insertados en el vector
	
	@SuppressWarnings("unchecked")
	public BinaryHeap(int n)
	{
		this.monticulo = (T[]) new Object[n];
		this.numElementos = 0;
	}
	
	/**
	 * Si recibe como parámetro un valor null, lanza una excepción del tipo NullPointerException.
	 * Si no cabe, no lo inserta retorna false.
	 * true si inserta la clave.
	 * false si ya existe (no lo inserta)
	 */
	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert null.");
		}
		if(monticulo.length == numElementos || search(elemento) != null)
		{
			return false;
		}
		
		monticulo[numElementos-1] = elemento;
		numElementos++;
		
		filtradoAscendente(numElementos-1); // de abajo a arriba
		
		return true;
	}

	private Object search(T elemento)
	{
		for(int i = 0; i < monticulo.length; i++)
		{
			if(monticulo[i] != null && monticulo[i].compareTo(elemento) == 0)
			{
				return monticulo[i];
			}
		}
		return null;
	}

	@Override
	public T sacar()
	{
		
	}

	@Override
	public boolean remove(T elemento)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEmpty()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void clear()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean cambiarPrioridad(int pos, T elemento)
	{
		// TODO Auto-generated method stub
		return false;
	}
	
	public String toString()
	{
		// Elementos separados por tabuladores. No hay tabulador al final.
	}
	
	private void filtradoAscendente(int pos)
	{
		/* Filtrado ascendente a partir de la posición pasada como
		parámetro. Es necesario realizarlo cada vez que se inserta un
		nuevo elemento o cuando se borra */
	}
	
	 private void filtradoDescendente(int pos)
	 {
		 /* Filtrado descendente a partir de la posición pasada como
	 parámetro. Es necesario realizarlo cada vez que se borra un
	 elemento o se invoca al método sacar */
	 }
	
}
