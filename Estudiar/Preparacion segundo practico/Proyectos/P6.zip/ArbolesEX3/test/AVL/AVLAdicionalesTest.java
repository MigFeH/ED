package AVL;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AVLAdicionalesTest
{

	@Test
	void padreDeTest()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode(N5.getInfo()));
		assertTrue(b.addNode(N3.getInfo()));
		assertTrue(b.addNode(N7.getInfo()));
		
		assertEquals(b.search(N5.getInfo()), b.padreDe(N3.getInfo()));
		assertEquals(b.search(N5.getInfo()), b.padreDe(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode(N10.getInfo()));
		assertTrue(b.addNode(N6.getInfo()));
		
		assertEquals(b.search(N7.getInfo()), b.padreDe(N10.getInfo()));
	}
	
	@Test
	void numAristasTest()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode(N5.getInfo()));
		assertTrue(b.addNode(N3.getInfo()));
		assertTrue(b.addNode(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode(N10.getInfo()));
		assertTrue(b.addNode(N6.getInfo()));
		
		assertEquals(2, b.numAristas(N5.getInfo(), N10.getInfo()));
		assertEquals(1, b.numAristas(N7.getInfo(), N10.getInfo()));
		assertEquals(0, b.numAristas(N7.getInfo(), N7.getInfo()));
		
		AVLNode<Integer> N1 = new AVLNode<Integer>(1);
		AVLNode<Integer> N4 = new AVLNode<Integer>(4);
		
		assertTrue(b.addNode(N1.getInfo()));
		assertTrue(b.addNode(N4.getInfo()));
		
		assertEquals(2, b.numAristas(N5.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas(N3.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas(N3.getInfo(), N4.getInfo()));
		assertEquals(2, b.numAristas(N5.getInfo(), N4.getInfo()));
		
		AVLNode<Integer> N8 = new AVLNode<Integer>(8);
		AVLNode<Integer> N12 = new AVLNode<Integer>(12);
		
		assertTrue(b.addNode(N8.getInfo()));
		assertTrue(b.addNode(N12.getInfo()));
		
		assertEquals(1, b.numAristas(N10.getInfo(), N8.getInfo()));
		assertEquals(1, b.numAristas(N10.getInfo(), N12.getInfo()));
		assertEquals(2, b.numAristas(N7.getInfo(), N8.getInfo()));
		assertEquals(2, b.numAristas(N7.getInfo(), N12.getInfo()));
		assertEquals(3, b.numAristas(N5.getInfo(), N8.getInfo()));
		assertEquals(3, b.numAristas(N5.getInfo(), N12.getInfo()));
	}
	
	@Test
	void padreDe2Test()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode2(N5.getInfo()));
		assertTrue(b.addNode2(N3.getInfo()));
		assertTrue(b.addNode2(N7.getInfo()));
		
		assertEquals(b.search2(N5.getInfo()), b.padreDe2(N3.getInfo()));
		assertEquals(b.search2(N5.getInfo()), b.padreDe2(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode2(N10.getInfo()));
		assertTrue(b.addNode2(N6.getInfo()));
		
		assertEquals(b.search2(N7.getInfo()), b.padreDe2(N10.getInfo()));
	}
	
	@Test
	void numAristas2Test()
	{
		AVLTree<Integer> b = new AVLTree<>();
		
		AVLNode<Integer> N5 = new AVLNode<Integer>(5);
		AVLNode<Integer> N3 = new AVLNode<Integer>(3);
		AVLNode<Integer> N7 = new AVLNode<Integer>(7);
		
		assertTrue(b.addNode2(N5.getInfo()));
		assertTrue(b.addNode2(N3.getInfo()));
		assertTrue(b.addNode2(N7.getInfo()));
		
		AVLNode<Integer> N10 = new AVLNode<Integer>(10);
		AVLNode<Integer> N6 = new AVLNode<Integer>(6);
		
		assertTrue(b.addNode2(N10.getInfo()));
		assertTrue(b.addNode2(N6.getInfo()));
		
		assertEquals(2, b.numAristas2(N5.getInfo(), N10.getInfo()));
		assertEquals(1, b.numAristas2(N7.getInfo(), N10.getInfo()));
		assertEquals(0, b.numAristas2(N7.getInfo(), N7.getInfo()));
		
		AVLNode<Integer> N1 = new AVLNode<Integer>(1);
		AVLNode<Integer> N4 = new AVLNode<Integer>(4);
		
		assertTrue(b.addNode2(N1.getInfo()));
		assertTrue(b.addNode2(N4.getInfo()));
		
		assertEquals(2, b.numAristas2(N5.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas2(N3.getInfo(), N1.getInfo()));
		assertEquals(1, b.numAristas2(N3.getInfo(), N4.getInfo()));
		assertEquals(2, b.numAristas2(N5.getInfo(), N4.getInfo()));
		
		AVLNode<Integer> N8 = new AVLNode<Integer>(8);
		AVLNode<Integer> N12 = new AVLNode<Integer>(12);
		
		assertTrue(b.addNode2(N8.getInfo()));
		assertTrue(b.addNode2(N12.getInfo()));
		
		assertEquals(1, b.numAristas2(N10.getInfo(), N8.getInfo()));
		assertEquals(1, b.numAristas2(N10.getInfo(), N12.getInfo()));
		assertEquals(2, b.numAristas2(N7.getInfo(), N8.getInfo()));
		assertEquals(2, b.numAristas2(N7.getInfo(), N12.getInfo()));
		assertEquals(3, b.numAristas2(N5.getInfo(), N8.getInfo()));
		assertEquals(3, b.numAristas2(N5.getInfo(), N12.getInfo()));
	}

}
