package AVL;

public class AVLNode <T extends Comparable <T>>
{
	private T info; // el contenido, de tipo generico, del nodo
	private AVLNode<T> left; // nodo hijo izquierdo
	private AVLNode<T> right; // nodo hijo derecho
	private int balanceFactor; // factor de balance del nodo
	private int height; // altura del nodo
	
	
	public AVLNode(T clave)
	{
		setInfo(clave);
		setLeft(null);
		setRight(null);
		this.balanceFactor = 0;
		this.height = 0;
	}
	
	public void setInfo(T clave)
	{
		this.info = clave;
	}
	
	public T getInfo()
	{
		return this.info;
	}
	
	public void setLeft(AVLNode<T> nodo)
	{
		this.left = nodo;
	}
	
	public void setRight(AVLNode<T> nodo)
	{
		this.right = nodo;
	}
	
	public AVLNode<T> getLeft()
	{
		return this.left;
	}
	
	public AVLNode<T> getRight()
	{
		return this.right;
	}
	
	public int getHeight()
	{
		return this.height;
	}
	
	public int getBF()
	{
		return this.balanceFactor;
	}
	
	public String toString()
	{
		return info.toString()+":BF="+ getBF();
	}

	public void updateBFHeight()
	{
		int altL, altR;
		if (this.getLeft() == null) altL = -1;
		else altL = this.getLeft().getHeight();
		if (this.getRight() == null) altR = -1;
		else altR = this.getRight().getHeight();
		this.balanceFactor = altR - altL;
		if (altL > altR) height = altL + 1;
		else height = altR + 1;
	}
}
