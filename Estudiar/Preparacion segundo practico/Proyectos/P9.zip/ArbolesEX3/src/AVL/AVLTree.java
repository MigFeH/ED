package AVL;

public class AVLTree<T extends Comparable<T>>
{
	private AVLNode<T> raiz; // Nodo raiz del arbol AVL
	private int aristas;
	
	public AVLTree()
	{
		this.raiz = null;
	}
	
	public AVLNode<T> search(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(this.raiz == null)
		{
			return null;
		}
		
		return searchRec(raiz, clave);
	}
	
	private AVLNode<T> searchRec(AVLNode<T> nodo, T clave)
	{
		if(nodo == null)
		{
			return null;
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			return searchRec(nodo.getLeft(), clave);
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			return searchRec(nodo.getRight(), clave);
		}
		
		return nodo;
	}

	/**
	 * Si recibe como parametro un valor null, no lo inserta y lanza una excepcion del tipo NullPointerException
	 * true si inserta la clave
	 * false si ya existe (no lo inserta)
	 * @param clave
	 */
	public boolean addNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(search(clave) != null)
		{
			return false;
		}
		
		if(this.raiz == null)
		{
			this.raiz = new AVLNode<T>(clave);
			this.raiz.updateBFHeight();
			return true;
		}
		
		this.raiz = addNodeRec(raiz, clave);
		updateAndBalanceIfNecesary(raiz);
		return true;
	}
	
	private AVLNode<T> addNodeRec(AVLNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null)
			{
				// insertamos
				nodo.setLeft(new AVLNode<T>(clave));
				return updateAndBalanceIfNecesary(nodo);
			} else
			{
				nodo.setLeft(addNodeRec(nodo.getLeft(), clave));
				return updateAndBalanceIfNecesary(nodo);
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			if(nodo.getRight() == null)
			{
				// insertamos
				nodo.setRight(new AVLNode<T>(clave));
				return updateAndBalanceIfNecesary(nodo);
			} else
			{
				nodo.setRight(addNodeRec(nodo.getRight(), clave));
				return updateAndBalanceIfNecesary(nodo);
			}
		}
		return nodo; // condicion de parada (si la clave no es > o < que un nodo, es porque el nodo es null, descartamos la posibilidad de que sea porque el nodo se repite porque lo hemos comprobado en el add no recursivo)
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder()
	{
		return preOrderRec(raiz);
	}
	
	private String preOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return nodo.toString() + "\t" + preOrderRec(nodo.getLeft()) + preOrderRec(nodo.getRight());
	}

	/**
	 * izq, der, raiz
	 */
	public String postOrder()
	{
		return postOrderRec(raiz);
	}
	
	private String postOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return postOrderRec(nodo.getLeft()) + postOrderRec(nodo.getRight()) + "\t" + nodo.toString();
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder()
	{
		return inOrderRec(raiz);
	}
	
	private String inOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null)
		{
			return "";
		}
		return inOrderRec(nodo.getLeft()) + nodo.toString() + "\t" + inOrderRec(nodo.getRight());
	}

	public boolean removeNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(search(clave) == null || this.raiz == null) // clave no existe en el arbol
		{
			return false;
		}
		
		this.raiz = removeNodeRec(raiz, clave);
		return true;
	}
	
	private AVLNode<T> removeNodeRec(AVLNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeNodeRec(nodo.getRight(), clave));
			return updateAndBalanceIfNecesary(nodo);
		} else if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeNodeRec(nodo.getLeft(), clave));
			return updateAndBalanceIfNecesary(nodo);
		} else // lo hemos encontrado
		{
			if(nodo.getLeft() == null && nodo.getRight() == null) // no tiene hijos...
			{
				return null;
			} else if(nodo.getLeft() == null && nodo.getRight() != null) // solo tiene hijo derecho...
			{
				return nodo.getRight();
			} else if(nodo.getLeft() != null && nodo.getRight() == null) // solo tiene hijo izquierdo...
			{
				return nodo.getLeft();
			} else // tiene dos hijos
			{
				AVLNode<T> mayor = buscarMayorDelSubArbol(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				AVLNode<T> aux = removeNodeRec(nodo.getLeft(), mayor.getInfo());
				nodo.setLeft(aux);
				return updateAndBalanceIfNecesary(nodo);
			}
		}
	}

	private AVLNode<T> buscarMayorDelSubArbol(AVLNode<T> nodo)
	{
		while(nodo.getRight() != null)
		{
			nodo = nodo.getRight();
		}
		return nodo;
	}

	private AVLNode<T> updateAndBalanceIfNecesary(AVLNode<T> nodo)
	{
		nodo.updateBFHeight();
		if (nodo.getBF() == -2)
		{
			if (nodo.getLeft().getBF() == 1)
			{
				nodo = doubleLeftRotation(nodo);
			} else
			{
				nodo = singleLeftRotation(nodo);
			}
		} else if(nodo.getBF() == 2)
		{
			if (nodo.getRight().getBF() == -1)
			{
				nodo = doubleRightRotation(nodo);
			} else
			{
				nodo = singleRightRotation(nodo);
			}
		}
		return nodo;
	}
	
	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getLeft();
		nodo.setLeft(aux.getRight());
		nodo = updateAndBalanceIfNecesary(nodo);
		aux.setRight(nodo);
		aux = updateAndBalanceIfNecesary(aux);
		System.out.println("Se ha aplicado RSI");
		return aux;
	}
	
	private AVLNode<T> singleRightRotation (AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getRight();
		nodo.setRight(aux.getLeft());
		nodo = updateAndBalanceIfNecesary(nodo);
		aux.setLeft(nodo);
		aux = updateAndBalanceIfNecesary(aux);
		System.out.println("Se ha aplicado RSD");
		return aux;
	}
	
	private AVLNode<T> doubleLeftRotation (AVLNode<T> nodo)
	{
		// rsd sobre el subarbol izquierdo de N
		AVLNode<T> aux = singleRightRotation(nodo.getLeft());
		nodo.setLeft(aux);

		// rsi sobre nodo N
		return singleLeftRotation(nodo);
	}
	
	private AVLNode<T> doubleRightRotation (AVLNode<T> nodo)
	{
		// rsi sobre el subarbol derecho de N
		AVLNode<T> aux = singleLeftRotation(nodo.getRight());
		nodo.setRight(aux);

		// rsd sobre nodo N
		return singleRightRotation(nodo);
	}
	
	/**
	 * Implementar un metodo que devuelva el padre de un valor de tipo T que se le pasa como parametro.
	 * @param clave
	 * @return el nodo padre completo.
	 * null si no tiene padre o el elemento pasado como parametro no existe o el elemento o el arbol es null
	 */
	public AVLNode<T> padreDe(T clave)
	{
		if(clave == null /* elemento es null */ || raiz == null /* arbol es null */ || search(clave) == null /* elemento pasado como parametro no existe */|| raiz.getInfo().compareTo(clave) == 0 /* si es la raiz => no tiene padre */)
		{
			return null;
		}
		
		return padreDeRec(raiz, clave);
	}

	private AVLNode<T> padreDeRec(AVLNode<T> nodo, T clave)
	{	
		AVLNode<T> aux = null;
		
		if(clave.compareTo(nodo.getInfo()) == 0)
		{
			return nodo;
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq...
		{
			aux = padreDeRec(nodo.getLeft(), clave);
			if(aux.getInfo().compareTo(clave) == 0)
			{
				return nodo;
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der...
		{
			aux = padreDeRec(nodo.getRight(), clave);
			if(aux.getInfo().compareTo(clave) == 0)
			{
				return nodo;
			}
		}
		
		return aux; // nodo hijo encontrado
	}
	
	/**
	 * Implementar un metodo que devuelva el numero de aristas que hay desde clave1 hasta clave2 teniendo en 
	 * cuenta que no hay ciclos y clave1 siempre es un ancestro de clave2. 
	 * Devolvera el numero de aristas 
	 * o 0 si clave1 es null o clave2 es null o el arbol es null o clave1 y clave2 son iguales
	 */
	public int numAristas(T clave1, T clave2)
	{
		if(clave1 == null || clave2 == null || raiz == null || clave1.compareTo(clave2) == 0)
		{
			return 0;
		}
		
		this.aristas = 0;
		return numAristasRec(clave1, clave2)-1;
	}

	private int numAristasRec(T clave1, T clave2)
	{
		AVLNode<T> padre = search(clave1);
		AVLNode<T> hijo = search(clave2);
		
		// entre n nodos consecutivos hay n-1 aristas
		// tenemos que contar el numero de hijos por los que pasamos hasta encontrar el de la clave2
		if(hijo.getInfo().compareTo(padre.getInfo()) < 0) // hijo a la izq del padre
		{
			clave1 = padre.getLeft().getInfo();
			clave2 = hijo.getInfo();
			numAristasRec(clave1, clave2); /* llamada recursiva */
		}
		
		if(hijo.getInfo().compareTo(padre.getInfo()) > 0) // hijo a la der del padre
		{
			clave1 = padre.getRight().getInfo();
			clave2 = hijo.getInfo();
			numAristasRec(clave1, clave2); /* llamada recursiva */
		}
		
		this.aristas = this.aristas + 1;
		return this.aristas;
	}
	
	//-------------------------------------------------------------------------------------------------------//
	
	public AVLNode<T> search2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null)
			return null;
		return search2Rec(raiz, clave);
	}
	
	private AVLNode<T> search2Rec(AVLNode<T> nodo, T clave)
	{
		if(nodo == null)
			return null;
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
			return search2Rec(nodo.getLeft(), clave);
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
			return search2Rec(nodo.getRight(), clave);
		return nodo; // nodo encontrado
	}

	/**
	 * Si recibe como parametro un valor null, no lo inserta y lanza una excepcion del tipo NullPointerException
	 * true si inserta la clave
	 * false si ya existe (no lo inserta)
	 * @param clave
	 */
	public boolean addNode2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(search2(clave) != null)
			return false;
		if(raiz == null)
		{
			this.raiz = new AVLNode<T>(clave);
			raiz.updateBFHeight();
			return true;
		}
		this.raiz = addNode2Rec(raiz, clave);
		this.raiz = updateAndBalanceIfNecesary2(raiz);
		return true;
	}
	
	private AVLNode<T> addNode2Rec(AVLNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			if(nodo.getLeft() == null) // hay hueco
			{
				nodo.setLeft(new AVLNode<T>(clave));
				return updateAndBalanceIfNecesary2(nodo);
			} else
			{
				nodo.setLeft(addNode2Rec(nodo.getLeft(), clave));
				return updateAndBalanceIfNecesary2(nodo);
			}
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			if(nodo.getRight() == null) // hay hueco
			{
				nodo.setRight(new AVLNode<T>(clave));
				return updateAndBalanceIfNecesary2(nodo);
			} else
			{
				nodo.setRight(addNode2Rec(nodo.getRight(), clave));
				return updateAndBalanceIfNecesary2(nodo);
			}
		}
		
		return nodo; // retornamos el nodo para que compile ya que siempre habra hueco para insertar; tambien sirve si retornamos null
	}

	/**
	 * raiz, izq, der
	 */
	public String preOrder2()
	{
		return preOrder2Rec(raiz);
	}
	
	private String preOrder2Rec(AVLNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return nodo.toString() + "\t" + preOrder2Rec(nodo.getLeft()) + preOrder2Rec(nodo.getRight());
	}

	/**
	 * izq, der, raiz
	 */
	public String postOrder2()
	{
		return postOrder2Rec(raiz);
	}
	
	private String postOrder2Rec(AVLNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return postOrder2Rec(nodo.getLeft()) + postOrder2Rec(nodo.getRight()) + nodo.toString() + "\t"; 
	}

	/**
	 * izq, raiz, der
	 */
	public String inOrder2()
	{
		return inOrder2Rec(raiz);
	}
	
	private String inOrder2Rec(AVLNode<T> nodo)
	{
		if(nodo == null)
			return "";
		return inOrder2Rec(nodo.getLeft()) + nodo.toString() + "\t" + inOrder2Rec(nodo.getRight());
	}

	public boolean removeNode2(T clave)
	{
		if(clave == null)
			throw new NullPointerException("Element to insert is null.");
		if(raiz == null /* arbol vacio */ || search2(clave) == null /* clave no existente en el arbol */)
			return false;
		this.raiz = removeNode2Rec(raiz, clave);
		return true;
	}
	
	private AVLNode<T> removeNode2Rec(AVLNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			nodo.setLeft(removeNode2Rec(nodo.getLeft(), clave));
			return updateAndBalanceIfNecesary2(nodo);
		} else if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			nodo.setRight(removeNode2Rec(nodo.getRight(), clave));
			return updateAndBalanceIfNecesary2(nodo);
		} else // clave encontrada
		{
			if(nodo.getLeft() == null && nodo.getRight() == null) // no tiene hijos => se borra tal cual
				return null;
			else if(nodo.getLeft() != null && nodo.getRight() == null) // solo hijo izq => lo sustituye este
				return nodo.getLeft();
			else if(nodo.getLeft() == null && nodo.getRight() != null) // solo hijo der => lo sustituye este
				return nodo.getRight();
			else // ambos hijos => lo sustituye el mayor del subarbol izq
			{
				AVLNode<T> mayor = buscarMayorDelSubarbol2(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				nodo.setLeft(removeNode2Rec(nodo.getLeft(), mayor.getInfo()));
				return updateAndBalanceIfNecesary2(nodo);
			}
		}
	}

	private AVLNode<T> buscarMayorDelSubarbol2(AVLNode<T> nodo)
	{
		while(nodo.getRight() != null)
			nodo = nodo.getRight();
		return nodo;
	}

	private AVLNode<T> updateAndBalanceIfNecesary2(AVLNode<T> nodo)
	{
		nodo.updateBFHeight();
		if(nodo.getBF() == -2)
		{
			if(nodo.getLeft().getBF() == 1)
				nodo = doubleLeftRotation2(nodo);
			else
				nodo = singleLeftRotation2(nodo);
		} else if(nodo.getBF() == 2)
		{
			if(nodo.getRight().getBF() == -1)
				nodo = doubleRightRotation2(nodo);
			else
				nodo = singleRightRotation2(nodo);
		}
		return nodo;
	}

	private AVLNode<T> singleRightRotation2(AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getRight();
		nodo.setRight(aux.getLeft());
		nodo = updateAndBalanceIfNecesary2(nodo);
		
		aux.setLeft(nodo);
		aux = updateAndBalanceIfNecesary2(aux);
		System.out.println("Se ha aplicado RSD");
		return aux;
	}

	private AVLNode<T> doubleRightRotation2(AVLNode<T> nodo)
	{
		// rsi sobre el subarbol derecho de N
		AVLNode<T> aux = singleLeftRotation2(nodo.getRight());
		nodo.setRight(aux);
		
		// rsd sobre N
		return singleRightRotation2(nodo);
	}

	private AVLNode<T> singleLeftRotation2(AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getLeft();
		nodo.setLeft(aux.getRight());
		nodo = updateAndBalanceIfNecesary2(nodo);
		
		aux.setRight(nodo);
		aux = updateAndBalanceIfNecesary2(aux);
		System.out.println("Se ha aplicado RSI");
		return aux;
	}

	private AVLNode<T> doubleLeftRotation2(AVLNode<T> nodo)
	{
		// rsd sobre el subarbol izquierdo de N
		AVLNode<T> aux = singleRightRotation2(nodo.getLeft());
		nodo.setLeft(aux);
		
		// rsi sobre N
		return singleLeftRotation2(nodo);
	}
	
	/**
	 * Implementar un metodo que devuelva el padre de un valor de tipo T que se le pasa como parametro.
	 * @param clave
	 * @return el nodo padre completo.
	 * null si no tiene padre o el elemento pasado como parametro no existe o el elemento o el arbol es null
	 */
	public AVLNode<T> padreDe2(T clave)
	{
		if(clave == null || raiz == null || search2(clave) == null)
			return null;
		return padreDe2Rec(raiz, clave);
	}
	
	private AVLNode<T> padreDe2Rec(AVLNode<T> nodo, T clave)
	{
		AVLNode<T> aux = null;
		
		
		if(clave.compareTo(nodo.getInfo()) == 0)
		{
			return nodo; // retornamos el hijo (indica que ha sido encontrado) => condicion de parada
		}
		if(clave.compareTo(nodo.getInfo()) < 0) // clave a la izq
		{
			aux = padreDe2Rec(nodo.getLeft(), clave); // para forzar la recursividad, en cuanto se encuentre el hijo buscado se parara
			if(nodo.getLeft().getInfo().compareTo(clave) == 0)
			{
				return nodo; // el hijo encontrado coincide con la clave del hijo a buscar => retornamos el padre
			}
		}
		if(clave.compareTo(nodo.getInfo()) > 0) // clave a la der
		{
			aux = padreDe2Rec(nodo.getRight(), clave);
			if(nodo.getRight().getInfo().compareTo(clave) == 0)
			{
				return nodo; // el hijo encontrado coincide con la clave del hijo a buscar => retornamos el padre
			}
		}
		
		return aux;
	}

	/**
	 * Implementar un metodo que devuelva el numero de aristas que hay desde clave1 hasta clave2 teniendo en 
	 * cuenta que no hay ciclos y clave1 siempre es un ancestro de clave2. 
	 * Devolvera el numero de aristas 
	 * o 0 si clave1 es null o clave2 es null o el arbol es null o clave1 y clave2 son iguales
	 */
	public int numAristas2(T clave1, T clave2)
	{
		if(clave1 == null || clave2 == null || raiz == null || clave1.compareTo(clave2) == 0)
			return 0;
		
	}
}
