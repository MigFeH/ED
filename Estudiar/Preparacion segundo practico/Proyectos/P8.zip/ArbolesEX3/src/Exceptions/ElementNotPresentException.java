package Exceptions;

public class ElementNotPresentException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ElementNotPresentException(Object element) {
		super("El elemento " + element + " no existe en la estructura");
	}

	public ElementNotPresentException(String message) {
		super(message);
	}

}