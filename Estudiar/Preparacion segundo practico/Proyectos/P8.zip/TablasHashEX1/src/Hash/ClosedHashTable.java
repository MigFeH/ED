package Hash;

import java.lang.reflect.Array;

import Exceptions.ElementNotPresentException;

public class ClosedHashTable<T> extends AbstractHash<T>
{
	// implementa una tabla hash cerrada
	public static final int LINEAL = 0;
	public static final int CUADRATICA = 1;
	public static final int DOBLE = 2;
	
	private static final double MINIMUN_LF = 0.16;
	private static final double MAXIMUN_LF = 0.5;
	
	private double minlf; // factor de carga min
	private double maxlf; // factor de carga max
	
	private HashNode<T> tabla[]; // tabla hash
	private int hashSize; // dimension de la tabla hash
	private int numElementos; // numero de elementos insertados hasta el momento
	private int tipoExploracion; /* 0 - LINEAL
								 * 1 - CUADRATICA
								 * 2 - DISPERSION DOBLE
								 */
	
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo)
	{
		this.numElementos = 0;
		this.tipoExploracion = tipo;
		
		this.minlf = MINIMUN_LF;
		this.maxlf = MAXIMUN_LF;
		
		// si el tama�o que nos pasa no es numero primo, obtenemos el siguiente numero primo (porque entonces tendr� menos colisiones)
		if(!isPositivePrime(tam))
			tam = nextPrimeNumber(tam);
		
		this.hashSize = tam;
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, tam);
		for(int i = 0; i < tam; i++)
			tabla[i] = new HashNode<T>();
	}
	
	public ClosedHashTable(int tam, int tipo, double minlf, double maxlf)
	{
		this(tam, tipo);
		
		this.minlf = minlf;
		this.maxlf = maxlf;
	}
	
	@Override
	public int getNumOfElems()
	{
		return this.numElementos;
	}

	@Override
	public int getSize()
	{
		return this.hashSize;
	}

	/**
	 * Si recibe como parametro un null, lanza una excepcion del tipo NullPointerException.
	 * Si no cabe, retorna false
	 * true si inserta la clave
	 */
	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Elemento to insert is null.");
		if(numElementos == tabla.length)
			return false;
		
		int nueva_pos = fHash(elemento); // calcular nueva posicion
		int intento = 1; // recuento de los intentos para asignar posicion
		
		while(tabla[nueva_pos].getStatus() == HashNode.LLENO && intento < getSize()) // mientras la posicion calculada este llena seguir calculando...
		{
			// recalcular posicion en funcion del tipo de busqueda
			nueva_pos = calcularPosicion(elemento, intento);
			intento++;
		}
		
		if(tabla[nueva_pos].getStatus() != HashNode.LLENO) // si la posicion calculada no se encuentra llena
		{
			tabla[nueva_pos].setInfo(elemento); // el setInfo() pone el estado a lleno
			numElementos++;
		}
		
		if(factorCarga() > maxlf)
			reDispersion();
		
		return true;
	}

	private int calcularPosicion(T elemento, int intento)
	{
		int ps = fHash(elemento);
		switch(tipoExploracion)
		{
		case LINEAL: // lineal
			return busquedaLineal(ps, intento);
		case CUADRATICA: // cuadratica
			return busquedaCuadratica(ps, intento);
		default: // doble
			return busquedaDoble(ps, intento);
		}
	}

	private int busquedaDoble(int ps, int intento)
	{
		return (ps + (intento * H2(ps)) % getSize());
	}

	private int H2(int ps)
	{
		int R = previousPrimeNumber(getSize());
		return R - ps % R;
	}

	private int busquedaCuadratica(int ps, int intento)
	{
		return (ps + (intento^2)) % getSize();
	}

	private int busquedaLineal(int ps, int intento)
	{
		return (ps + intento) % getSize();
	}

	@Override
	public HashNode<T> find(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element to search is null.");
		if(numElementos == 0) // no hay elementos en la tabla...
			return null;
		
		int pos = fHash(elemento);
		int intento = 1;
		
		while(tabla[pos].getStatus() != HashNode.VACIO /* el nodo recorrido no sea vacio */ &&
				!tabla[pos].getInfo().equals(elemento) /* el nodo recorrido no tenga la misma clave */ &&
				intento < getSize())
		{
			pos = calcularPosicion(elemento, intento); // calculamos una nueva posicion
			intento++;
		}
		
		if(tabla[pos].getStatus() != HashNode.VACIO &&
				tabla[pos].getInfo().equals(elemento)) // hemos encontrado un nodo con la clave pasada como parametro
			return tabla[pos]; // retornamos el nodo con la clave encontrada
		
		return null; // nodo no encontrado
	}

	@Override
	public boolean remove(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element to remove is null");
		if(numElementos == 0) // tabla vacia
			return false;
		if(find(elemento) == null)
			throw new ElementNotPresentException(elemento);
			
		int pos = fHash(elemento);
		int intento = 1;
		
		while(tabla[pos].getStatus() != HashNode.VACIO /* estado del nodo encontrado no sea vacio */ &&
				!tabla[pos].getInfo().equals(elemento) /* clave del nodo sea la misma que pasada por parametro */)
		{
			pos = calcularPosicion(elemento, intento);
			intento++;
		}
		
		if(tabla[pos].getInfo().equals(elemento)) // nodo encontrado
			tabla[pos].remove(); // el remove deja el estado del nodo a borrado
		
		if(factorCarga() < minlf)
			inverseRedispersion();
		
		return true;
	}

	@Override
	public String toString()
	{
		StringBuilder cadena = new StringBuilder();
		for(int i=0;i< getSize();i++){
		cadena.append(tabla[i].toString());
		cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElems());
		cadena.append("]");
		return cadena.toString();
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void reDispersion()
	{
		HashNode<T>[] aux = tabla; // hacemos copia de la tabla original
		int nuevo_tam = nextPrimeNumber(getSize()*2); // calculamos la nueva dimension de la tabla
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, nuevo_tam); // volvemos a inicializar la tabla con la nueva dimension
		
		for(int i = 0; i < nuevo_tam; i++) // rellenamos la nueva tabla redimensionada con nodos
			tabla[i] = new HashNode<T>();
		
		this.numElementos = 0; // volvemos a inicializar el numero de elementos insertados en la tabla
		this.hashSize = nuevo_tam; // volvemos a inicializar el hashSize pero con la nueva dimension de la tabla
		
		for(int i = 0; i < aux.length; i++)
		{
			if(aux[i].getStatus() == HashNode.LLENO)
				add(aux[i].getInfo());
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void inverseRedispersion()
	{
		HashNode<T>[] aux = tabla; // hacemos una copia de la tabla original
		int nuevo_tam = previousPrimeNumber(getSize()/2); // calculamos la nueva dimension de la tabla
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, nuevo_tam); // reinicializamos la tabla con la nueva dimension
		
		for(int i = 0; i < nuevo_tam; i++) // rellenamos la tabla con nodos
			tabla[i] = new HashNode<T>();
		
		this.numElementos = 0; // reseteamos el numero de elementos insertados en la tabla
		this.hashSize = nuevo_tam; // actualizamos dimension de la tabla con la nueva dimension calculada
		
		for(int i = 0; i < aux.length; i++)
		{
			if(aux[i].getStatus() == HashNode.LLENO)
				add(aux[i].getInfo());
		}
	}
	
	
}
