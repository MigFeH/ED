package ColasPrioridad;

public interface PriorityQueue <T extends Comparable<T>>
{
	public boolean add(T elemento);
	public T sacar();
	public boolean remove (T elemento);
	public boolean isEmpty();
	public void clear();
	public boolean cambiarPrioridad(int pos, T elemento);
	public String toString();
	boolean add2(T elemento);
	public T sacar2();
	public boolean remove2(T elemento);
	public boolean isEmpty2();
	public void clear2();
	public boolean cambiarPrioridad2(int pos, T elemento);
}
