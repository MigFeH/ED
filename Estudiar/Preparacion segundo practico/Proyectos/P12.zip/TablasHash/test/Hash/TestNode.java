package Hash;

import org.junit.jupiter.api.Test;

class TestNode
{

	@Test
	void test()
	{		
		// Nodo vac�o
		HashNode<Integer> M = new HashNode<>();
		System.out.println(M.toString());
		System.out.println("El estado del nodo es: " + M.getStatus());
		
		// Nodo lleno
		HashNode<Integer> N = new HashNode<>();
		N.setInfo(8);
		System.out.println(N.toString());
		
		System.out.println("El valor del nodo es: " + N.getInfo());
		System.out.println("El estado del nodo es: " + N.getStatus());
		
		// Nodo borrado
		N.remove();
		System.out.println(N.toString());
		System.out.println("El estado del nodo es: " + N.getStatus());
	}

}
