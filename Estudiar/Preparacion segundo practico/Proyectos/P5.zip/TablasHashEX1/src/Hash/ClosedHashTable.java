package Hash;

public class ClosedHashTable<T> extends AbstractHash<T>
{
	// implementa una tabla hash cerrada
	public static final int LINEAL = 0;
	public static final int CUADRATICA = 1;
	public static final int DOBLE = 2;
	
	private HashNode<T> tabla[]; // tabla hash
	private int hashSize; // dimension de la tabla hash
	private int numElementos; // numero de elementos insertados hasta el momento
	private int tipoExploracion; /* 0 - LINEAL
								 * 1 - CUADRATICA
								 * 2 - DISPERSION DOBLE
								 */
	
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo)
	{
		this.tabla = (HashNode<T>[]) new Comparable[tam];
		this.hashSize = tam;
		this.numElementos = 0;
		this.tipoExploracion = tipo;
	}
	
	@Override
	public int getNumOfElems()
	{
		return this.numElementos;
	}

	@Override
	public int getSize()
	{
		return this.hashSize;
	}

	/**
	 * Si recibe como parametro un null, lanza una excepcion del tipo NullPointerException.
	 * Si no cabe, retorna false
	 * true si inserta la clave
	 */
	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Elemento to insert is null.");
		if(numElementos == tabla.length)
			return false;
		
		int nueva_pos = fHash(elemento); // calcular nueva posicion
		int intento = 1; // recuento de los intentos para asignar posicion
		
		while(tabla[nueva_pos].getStatus() != HashNode.LLENO && intento < getSize())
		{
			// recalcular posicion en funcion del tipo de busqueda
			nueva_pos = calcularPosicion(nueva_pos, intento);
			intento++;
		}
		
		return true;
	}

	private int calcularPosicion(int nueva_pos, int intento)
	{
		switch(tipoExploracion)
		{
		case 0: // lineal
			return busquedaLineal(nueva_pos, intento);
		case 1: // cuadratica
			return busquedaCuadratica(nueva_pos, intento);
		default: // doble
			return busquedaDoble(nueva_pos, intento);
		}
	}

	private int busquedaDoble(int nueva_pos, int intento)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	private int busquedaCuadratica(int nueva_pos, int intento)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	private int busquedaLineal(int nueva_pos, int intento)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public HashNode<T> find(T elemento)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(T elemento)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String toString()
	{
		StringBuilder cadena = new StringBuilder();
		for(int i=0;i< getSize();i++){
		cadena.append(tabla[i].toString());
		cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElems());
		cadena.append("]");
		return cadena.toString();
	}
	
}
