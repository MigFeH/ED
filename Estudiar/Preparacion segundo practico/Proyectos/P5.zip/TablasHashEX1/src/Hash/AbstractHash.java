package Hash;

public abstract class AbstractHash<T>
{
	/*
	 * Se definen las cabeceras de los metodos cuya implementacion dependera de la filosofia de tablas
	 * hash (abiertas o cerradas) y otros metodos comunes a cualquier implementacion
	 */
	
	abstract public int getNumOfElems();
	abstract public int getSize();
	abstract public boolean add(T elemento);
	abstract public HashNode<T> find(T elemento);
	abstract public boolean remove(T elemento);
	abstract public String toString();
	
	protected int fHash(T elemento)
	{
		int pos = elemento.hashCode()%getSize();
		if (pos < 0) return pos+getSize();
		else return pos;
	}
	
	protected boolean isPositivePrime(int numero)
	{
		for(int i = 2; i < numero; i++)
		{
			if(numero % i == 0)
				return false;
		}
		return true;
	}
	
	protected int nextPrimeNumber(int numero)
	{
		int num = numero+1;
		while(!isPositivePrime(num))
			num++;
		return num;
	}
	
	protected int previousPrimeNumber(int numero)
	{
		if(numero <= 3 || isPositivePrime(numero))
			return numero;
		int num = numero-1;
		while(!isPositivePrime(num))
			num--;
		if(num <= 3)
			return 3;
		return num;
	}
}
