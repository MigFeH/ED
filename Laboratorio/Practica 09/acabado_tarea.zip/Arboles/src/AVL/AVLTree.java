package AVL;

public class AVLTree <T extends Comparable<T>>
{
	private AVLNode<T> raiz; // nodo raiz del arbol (es la clave (info) del nodo raiz)
	
	/**
	 * Constructor que inicializa la raiz a null
	 */
	public AVLTree()
	{
		this.raiz = null;
	}
	
	/**
	 * Dada una clave pasada como parametro, retorna el nodo completo que tenga esa clave
	 * @param clave de tipo T
	 * @return Si clave es nul --> null Pointer
	 * Si arbol null o no encuentra la clave --> null
	 * Si lo encuentra --> nodo completo
	 */
	public AVLNode<T> search(T clave)
	{		
		if(this.raiz == null) // arbol vacio (no tiene nodo raiz)
		{
			return null;
		}
		
		if(clave == null) // clave del nodo a buscar null...
		{
			throw new NullPointerException();
		}
		
		// nodo del subarbol donde busco la clave
		return searchNodeRec(raiz, clave);
	}
	
	private AVLNode<T> searchNodeRec(AVLNode<T> nodo, T clave)
	{
		if(nodo == null || nodo.getInfo() == null) // caso basico (o de finalizacion): nodo no encontrado (nodo de clave null)
		{
			return null;
		}
		
		// si clave < nodo (la info) busco en el subarbol izquierdo
		if(clave.compareTo(nodo.getInfo()) < 0) // clave < nodo.getInfo()
		{
			return searchNodeRec(nodo.getLeft(), clave);
		}
		
		// si clave > nodo (la info) busco en el subarbol derecho
		if(clave.compareTo(nodo.getInfo()) > 0) // clave > nodo.getInfo()
		{
			return searchNodeRec(nodo.getRight(), clave);
		}

		// si clave == nodo (la info) retorno el nodo
		return nodo; // clave == nodo.getInfo()
	}
	
	/**
	 * @param clave de tipo T del nodo a agregar al arbol
	 * @return Si la clave es null --> null Pointer
	 * Si la clave ya existe --> false
	 * Si la inserta --> true 
	 */
	public boolean addNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(raiz == null) // arbol vacio (no tiene raiz)
		{
			this.raiz = new AVLNode<T>(clave);
			this.raiz.updateBFHeight();
			return true;
		}
		return addRec(raiz, clave);
	}
	
	private boolean addRec(AVLNode<T> nodo, T clave)
	{
		if(nodo.getInfo() == clave) // caso basico: nodo existente en el arbol
		{
			return false;
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0)
		{
			if(nodo.getRight() == null) // nodo de la derecha es null
			{
				nodo.setRight(new AVLNode<T>(clave)); // set del nuevo nodo por la derecha
				updateAndBalancedIfNecesary(nodo);
				return true;
			}
			// sino devolver el resultado de volver a llamar al subarbol derecho
			return addRec(nodo.getRight(), clave);
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0)
		{
			if(nodo.getLeft() == null) // nodo de la izquierda es null
			{
				nodo.setLeft(new AVLNode<T>(clave)); // set del nuevo nodo por la izquierda
				updateAndBalancedIfNecesary(nodo);
				return true;
			}
			// sino devolver el resultado de volver a llamar al subarbol izquierdo
			return addRec(nodo.getLeft(), clave);
		}
		
		return false; // nodo existente en el arbol
	}
	
	/**
	 * @return recorrido del arbol en preorden:
	 * 	raiz, izquierda, derecha
	 */
	public String preOrder()
	{
		return preOrderRec(raiz);
	}
	
	private String preOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return nodo.toString() + "\t" + preOrderRec(nodo.getLeft()) + preOrderRec(nodo.getRight());
	}

	/**
	 * @return recorrido del arbol en postorden:
	 * izquierda, derecha, raiz
	 */
	public String postOrder()
	{
		return postOrderRec(raiz);
	}
	
	private String postOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return postOrderRec(nodo.getLeft()) + postOrderRec(nodo.getRight()) + nodo.toString() + "\t";
	}

	/**
	 * @return recorrido del arbol en inorden
	 * izquierda, raiz, derecha
	 */
	public String inOrder()
	{
		return inOrderRec(raiz);
	}
	
	private String inOrderRec(AVLNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return inOrderRec(nodo.getLeft()) + nodo.toString() + "\t" + inOrderRec(nodo.getRight());
	}
	
	/**
	 * Borra el nodo que se corresponde con la clave que pasada por parametro
	 * @param clave del nodo a borrar
	 * @return Si la clave es null --> null Pointer
	 * Si el arbol es null o la clave no existe --> false
	 * Si borra la clave --> true 
	 */
	public boolean removeNode(T clave)
	{	
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(search(clave) == null)
		{
			return false;
		} else
		{
			raiz = removeNodeRec(raiz, clave); // va a buscar en el arbol el nodo con la clave del parametro
												// la primera llamada al metodo recursivo siempre se hace con la raiz
			// el metodo recursivo ira recorriendo el arbol hasta dar con el nodo a borrar, una vez borrado se va a actualizar
			// el padre del nodo borrado recursivamente hasta acabar actualizando la raiz
			return true;
		}
	}
	
	private AVLNode<T> removeNodeRec(AVLNode<T> nodo, T clave)
	{
		// Antes de devolver el nodo hay que actualizar su balance y su altura
		
		if(clave.compareTo(nodo.getInfo()) > 0) // el elemento a borrar est� en el subarbol derecho
		{
			AVLNode<T> nuevo_nodo = removeNodeRec(nodo.getRight(), clave); // devuelve el subarbol derecho modificado
			nodo.setRight(nuevo_nodo);  // asignar nodo por la derecha lo que me devuelve el removeR (nuevo_nodo)
			//return nodo;
			return updateAndBalancedIfNecesary(nodo);
		} else if(clave.compareTo(nodo.getInfo()) < 0) // el elemento a borrar est� en el subarbol izquierdo
		{
			AVLNode<T> nuevo_nodo = removeNodeRec(nodo.getLeft(), clave); // devuelve el subarbol izquierdo modificado
			nodo.setLeft(nuevo_nodo); // asignar nodo por la izquierda lo que me devuelve el removeR (nuevo_nodo)
			//return nodo;
			return updateAndBalancedIfNecesary(nodo);
		} else // hemos encontrado la clave (el nodo) y el algoritmo recursivo termina
		{
			if(nodo.getRight() == null) // si nodo por la derecha es null
			{
				//return nodo.getLeft();
				return updateAndBalancedIfNecesary(nodo.getLeft());
			} else
			{
				if(nodo.getLeft() == null) // si el nodo por la izquierda es null
				{
					//return nodo.getRight();
					return updateAndBalancedIfNecesary(nodo.getRight());
				} else // ni la derecha ni izquierda son null
				{
					AVLNode<T> mayor = buscarElMayorDelSubarbol(nodo.getLeft());
					nodo.setInfo(mayor.getInfo());
					AVLNode<T> nuevo_nodo = removeNodeRec(nodo.getLeft(), mayor.getInfo());
					nodo.setLeft(nuevo_nodo);
					//return nodo;
					return updateAndBalancedIfNecesary(nodo);
				}
			}
		}
	}
	
	/**
	 * buscar el mayor del subarbol izquierdo del nodo
	 */
	private AVLNode<T> buscarElMayorDelSubarbol(AVLNode<T> nodo)
	{
		while(nodo.getRight() != null)
		{
			nodo = nodo.getRight();
		}
		return nodo;
	}
	
	/**
	 * Actualiza el factor de balance y la altura y devuelve el nodo actualizado tras aplicar alguna de 
	 * las rotaciones si es necesario
	 * @param nodo, de tipo generico, a actualizar
	 * @return el nodo actualizado
	 */
	private AVLNode<T> updateAndBalancedIfNecesary(AVLNode<T> nodo)
	{
		nodo.updateBFHeight();
		if(nodo.getBF() == -2)
		{
			if(nodo.getLeft().getBF() == 1)
			{
				nodo = doubleLeftRotation(nodo);
			} else // -1 o cero
			{
				nodo = singleLeftRotation(nodo);
			}
		} else if(nodo.getBF() == 2)
		{
			if(nodo.getRight().getBF() == -1)
			{
				nodo = doubleRightRotation(nodo);
			} else // 1 o cero
			{
				nodo = singleRightRotation(nodo);
			}
		}
		
		return nodo;
	}

	/**
	 * Realiza la rotacion simple a la derecha y devuelve el nodo actualizado
	 * @param nodo a aplicarle la rotacion simple a la derecha y su actualizacion
	 * @return el nodo rotado y actualizado
	 */
	private AVLNode<T> singleRightRotation(AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getRight();
		nodo.setRight(aux.getLeft()); // nodo.derecha = aux.izquierda
		updateAndBalancedIfNecesary(nodo); // ACTUALIZAR LA ALTURA Y EL FB DE NODO
		aux.setLeft(nodo); // aux.izquierda = nodo
		updateAndBalancedIfNecesary(aux); // ACTUALIZAR LA ALTURA Y EL FB DE AUX
		return aux;
	}

	/**
	 * Realiza la rotacion doble a la derecha y devuelve el nodo actualizado.
	 * La rotacion doble a la derecha se realiza:
	 * 		- Rotacion simple a la izquierda sobre el hijo derecho del nodo pasado por parametro
	 * 		- Rotacion simple a la derecha sobre el nodo pasado por parametro
	 * @param nodo a aplicarle la rotacion doble a la derecha y su actualizacion
	 * @return el nodo rotado y actualizado
	 */
	private AVLNode<T> doubleRightRotation(AVLNode<T> nodo)
	{
		AVLNode<T> aux = singleLeftRotation(nodo.getRight()); // rotacion simple a la izquierda sobre el hijo derecho de nodo
		nodo.setRight(aux); // se lo asigno por la derecha al nodo
		return singleRightRotation(nodo);
	}

	/**
	 * Realiza la rotacion simple a la izquierda y devuelve el nodo actualizado
	 * @param nodo a aplicarle la rotacion simple a la izquierda y su actualizacion
	 * @return el nodo rotado y actualizado
	 */
	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo)
	{
		AVLNode<T> aux = nodo.getLeft();
		nodo.setLeft(aux.getRight()); // nodo.izquierda = aux.derecha
		updateAndBalancedIfNecesary(nodo); // ACTUALIZAR LA ALTURA Y EL FB DE NODO
		aux.setRight(nodo); // aux.derecha = nodo
		updateAndBalancedIfNecesary(aux); // ACTUALIZAR LA ALTURA Y EL FB DE AUX
		return aux;
	}

	/**
	 * Realiza la rotacion doble a la izquierda y devuelve el nodo actualizado.
	 * La rotacion doble a la izquierda se realiza:
	 * 		- Rotacion simple a la derecha sobre el hijo izquierdo del nodo pasado por parametro
	 * 		- Rotacion simple a la izquierda sobre el nodo pasado por parametro
	 * @param nodo a aplicarle la rotacion doble a la izquierda y su actualizacion
	 * @return el nodo rotado y actualizado
	 */
	private AVLNode<T> doubleLeftRotation(AVLNode<T> nodo)
	{
		AVLNode<T> aux = singleRightRotation(nodo.getLeft()); // rotacion simple a la derecha sobre el hijo izquierdo de nodo
		nodo.setLeft(aux); // se lo asigno por la izquierda al nodo
		return singleLeftRotation(nodo);
	}
}
