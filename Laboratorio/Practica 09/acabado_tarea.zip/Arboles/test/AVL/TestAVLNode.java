package AVL;

import org.junit.jupiter.api.Test;

class TestAVLNode
{

	@Test
	void test()
	{
		AVLNode<Integer> N1 = new AVLNode<Integer>(10);
		System.out.println(N1.toString());
		System.out.println("Altura= " + N1.getHeight());
		System.out.println();
		
		AVLNode<Integer> N2 = new AVLNode<Integer>(15);
		System.out.println(N2.toString());
		System.out.println("Altura= " + N2.getHeight());
		System.out.println("---------------------------------------------------");
		
		
		// Hago que N2 sea hijo derecho de N1
		N1.setRight(N2);
		N1.updateBFHeight();
		
		System.out.println(N2.getInfo() + " es hijo por la derecha de " + N1.getInfo());
		System.out.println(N1.toString());
		System.out.println("Altura= " + N1.getHeight());
		System.out.println();
		
		System.out.println(N2.toString());
		System.out.println("Altura= " + N2.getHeight());
		System.out.println();
		
		System.out.println("El hijo del " + N1.getInfo() + " por la derecha es: " + N1.getRight().getInfo().toString());
		System.out.println("---------------------------------------------------");
		
		
		AVLNode<Integer> N3 = new AVLNode<Integer>(20);
		// Hago que N3 sea hijo derecho de N2
		N2.setRight(N3);
		N2.updateBFHeight();
		N1.updateBFHeight();
		
		System.out.println(N3.getInfo() + " es hijo por la derecha de " + N2.getInfo());
		
		System.out.println(N1.toString());
		System.out.println("Altura= " + N1.getHeight());
		System.out.println();
		
		System.out.println(N2.toString());
		System.out.println("Altura= " + N2.getHeight());
		System.out.println();
		
		System.out.println(N3.toString());
		System.out.println("Altura= " + N3.getHeight());
		System.out.println("---------------------------------------------------");
		
		
		AVLNode<Integer> B2 = new AVLNode<Integer>(5);
		// Hago que B2 sea hijo izquierdo de N1
		N1.setLeft(B2);
		N1.updateBFHeight();
		
		System.out.println(B2.getInfo() + " es hijo por la izquierda de " + N1.getInfo());
		
		System.out.println(N1.toString());
		System.out.println("Altura= " + N1.getHeight());
		System.out.println();
		
		System.out.println(N2.toString());
		System.out.println("Altura= " + N2.getHeight());
		System.out.println();
		
		System.out.println(N3.toString());
		System.out.println("Altura= " + N3.getHeight());
		System.out.println();
		
		System.out.println(B2.toString());
		System.out.println("Altura= " + B2.getHeight());
		System.out.println("---------------------------------------------------");
		
	}

}
