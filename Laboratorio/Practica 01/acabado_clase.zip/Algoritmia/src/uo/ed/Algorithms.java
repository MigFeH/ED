package uo.ed;

public class Algorithms {
	
	/**
	 * Calcula la potencia n-esima de 2
	 * @param n Exponente de tipo long
	 * @return Devuelve la base (2) elevado al exponente (n)
	 */
	public long powIter(long n)
	{
		long potencia = 1;
		for(int i = 1; i <= n; i++)
		{
			potencia = potencia * 2;
		}
		return potencia;
	}
	
	/**
	 * Calcula el sumatorio de n
	 * @param n tope del sumatorio
	 * @return suma los n numeros desde 1 hasta el tope
	 */
	public long sumaIter(long n)
	{
		long result = 0;
		for(int i = 1; i <= n; i++)
		{
			result = result + i;
		}
		return result;
	}
	
	/**
	 * Calcula el sumatorio de n de forma recursiva
	 * @param n numeros para hacer el sumatorio
	 * @return suma los n numeros desde 1 hasta el tope de forma recursiva
	 */
	public long sumaRec(long n)
	{
		if(n == 1)
		{
			return 1;
		}
		else
		{
			return n + sumaRec(n - 1);
		}
	}
	
	/**
	 * @param n posicion del termino a calcular
	 * @return Calcula y devuelve el termino de la serie de Fibonacci que se corresponde con la 
	 * posicion de n
	 */
	public int fibonacciIter(int n)
	{
		int pos1 = 0;
		int pos2 = 1;
		int termino = 0;
		
		if(n == 0)
		{
			termino = 0;
		}
		if(n == 1)
		{
			termino = 1;
		}
		
		for(int i = 2; i <= n; i++)
		{
			termino = pos1 + pos2;
			pos1 = pos2;
			pos2 = termino;
		}
		
		return termino;
	}
	
	/**
	 * @param n posicion del termino a calcular de forma recursiva
	 * @return Calcula y devuelve el termino de la serie de Fibonacci que se corresponde con la
	 * posicion de n
	 */
	public int fibonacciRec(int n)
	{
		if(n == 0 || n == 1)
		{
			return n;
		}
		else
		{
			return fibonacciRec(n - 1) + fibonacciRec(n - 2);
		}
	}
	
	/**
	 * @param n numero a calcularle el factorial de forma iterativa
	 * @return el factorial del numero (n)
	 */
	public int factorialIter(int n)
	{
		if(n == 0 || n == 1)
		{
			return n;
		}
		else
		{
			int res = 1;
			
			for(int i = n; i > 0; i--)
			{
				res = res * i;
			}
			
			return res;
		}
	}
	
	/**
	 * @param n numero a calcularle el factorial de forma recursiva
	 * @return el factorial del numero (n)
	 */
	public int factorialRec(int n)
	{
		if(n == 0 || n == 1)
		{
			return n;
		}
		else
		{
			return n * factorialRec(n - 1);
		}
	}
	
	/**
	 * @param n Exponente de tipo long
	 * @return Devuelve la base (2) elevado al exponente (n) de forma recursiva version 1
	 */
	public long powRec1(long n)
	{
		int base = 2;
		
		if(n == 0)
		{
			return 1;
		}
		else if(n == 1)
		{
			return base;
		}
		else
		{
			return base * powRec1(n-1);
		}
	}
	
	/**
	 * @param n Exponente de tipo long
	 * @return Devuelve la base (2) elevado al exponente (n) de forma recursiva version 2
	 */
	public long powRec2(long n)
	{
		if(n == 0)
		{
			return 1;
		}
		else
		{
			return powRec2(n-1) + powRec2(n-1);
		}
	}
	
	/**
	 * @param n Exponente de tipo long
	 * @return Devuelve la base (2) elevado al exponente (n) de forma recursiva version 3
	 */
	public long powRec3(long n)
	{
		if(n == 0)
		{
			return 1;
		}
		if(n%2 == 0)
		{
			return powRec3(n/2) * powRec3(n/2);
		}
		else
		{
			return powRec3(n/2)* powRec3(n/2) * 2;
		}
	}
}

