package Hash;

import java.lang.reflect.Array;

import Exceptions.ElementNotPresentException;

public class ClosedHashTable<T> extends AbstractHash<T>
{
	// Implementa una tabla hash cerrada
	private static final double MINIMUM_LF = 0.16;
	private static final double MAXIMUM_LF = 0.5;
	
	public static final int LINEAL = 0;
	public static final int CUADRATICA = 1;
	public static final int DOBLE = 2;
	
	private HashNode<T> tabla[]; // tabla hash
	private int hashSize; // tama�o de la tabla hash
	
	private int numElementos; // numero de elementos insertados hasta el momento
	private int tipoExploracion; // 0-Lineal; 1-Cuadr�tica; 2-Dispersi�n doble
	
	private double minlf; // factor de carga minimo
	private double maxlf; // factor de carga maximo
	
	/**
	 * @param tam, tama�o maximo que tendr� la tabla hash
	 * @param tipo, el tipo de exploraci�n que se aplicar� en caso de haber colisiones
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo)
	{
		this.numElementos = 0;
		this.tipoExploracion = tipo;
		
		this.minlf = MINIMUM_LF;
		this.maxlf = MAXIMUM_LF;
		
		// si el tama�o que nos pasa no es numero primo, obtenemos el siguiente numero primo (porque entonces tendr� menos colisiones)
		if(!isPositivePrime(tam))
			tam = nextPrimeNumber(tam);
		
		this.hashSize = tam;
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, tam);
		for(int i = 0; i < tam; i++)
			tabla[i] = new HashNode<T>();
	}
	
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo, double minlf, double maxlf)
	{
		this(tam, tipo);
		this.minlf = minlf;
		this.maxlf = maxlf;
		
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, tam);
		for(int i = 0; i < tam; i++)
			tabla[i] = new HashNode<T>();
	}
	
	@Override
	public int getNumOfElems()
	{
		return this.numElementos;
	}

	@Override
	public int getSize()
	{
		return this.hashSize;
	}

	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element null");
		
		if(hashSize == numElementos) // elemento no cabe en la tabla
			return false;
		
		int posicion = fHash(elemento);
		int intento = 1;
		
		while(tabla[posicion].getStatus() == HashNode.LLENO /*&& intento < getSize()*/)
		{
			posicion = calcularPosicion(elemento, intento);
			intento++;
		}
		
		if(tabla[posicion].getStatus() != HashNode.LLENO)
		{
			tabla[posicion].setInfo(elemento);
			numElementos++;
		}
		
		if(factorCarga() > maxlf)
		{
			reDispersion();
		}
			
		return true;
	}

	private int calcularPosicion(T elemento, int intento)
	{
		int posicion = fHash(elemento);
		switch(tipoExploracion)
		{
		case LINEAL:
			return (posicion+intento) % getSize();
		case CUADRATICA:
			return (posicion+intento^2) % getSize();
		default:
			return (posicion+intento * H2(elemento, posicion)) % getSize();
		}
	}

	private int H2(T elemento, int posicion)
	{
		int primo_antecesor = previousPrimeNumber(hashSize);
		return (primo_antecesor - posicion) % primo_antecesor;
	}

	@Override
	public HashNode<T> find(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element null");
		
		if(numElementos == 0) // no hay elementos en la tabla
			return null;
		
		int posicion = fHash(elemento);
		int intento = 1;
		
		while(tabla[posicion].getStatus() != HashNode.VACIO 
				&& tabla[posicion].getInfo() != elemento
				&& intento < getSize())
		{
			posicion = calcularPosicion(elemento, intento);
			intento++;
		}
		
		if(tabla[posicion].getStatus() != HashNode.VACIO && tabla[posicion].getInfo().equals(elemento)) // hemos encontrado el nodo
		{
			return tabla[posicion];
		}
		return null;
	}

	@Override
	public boolean remove(T elemento)
	{
		if(elemento == null)
			throw new NullPointerException("Element null");
		
		if(numElementos == 0) // no hay elementos en la tabla
			return false;
		
		if(find(elemento) == null)
			throw new ElementNotPresentException(elemento);
		
		int posicion = fHash(elemento); // calcular posicion del elemento
		int intento = 1;
		
		while(tabla[posicion].getStatus() != HashNode.VACIO && 
				!tabla[posicion].getInfo().equals(elemento))
		{
			posicion = calcularPosicion(elemento, intento);
			intento++;
		}
		if(tabla[posicion].getInfo().equals(elemento)) // lo encuentro...
		{
			tabla[posicion].remove(); // lo borro
		}
		
		if(factorCarga() < minlf)
		{
			inverseRedispersion();
		}
		
		return true;
	}

	@Override
	public String toString()
	{
		StringBuilder cadena = new StringBuilder();
		
		for (int i = 0; i < getSize(); i++)
		{
			cadena.append(tabla[i]);
			cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElems());
		cadena.append("]");
		return cadena.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void reDispersion()
	{
		int nuevo_tam = nextPrimeNumber(hashSize*2);
		HashNode<T> aux[] = tabla;
		// inicializar la propiedad tabla de la clase con el nuevo tam
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, nuevo_tam);
		
		for(int i = 0; i < nuevo_tam; i++)
		{
			tabla[i] = new HashNode<T>();
		}
		
		this.numElementos = 0;
		this.hashSize = nuevo_tam;
		
		for(int i = 0; i < aux.length; i++)
		{
			if(aux[i].getStatus() == HashNode.LLENO)
			{
				add(aux[i].getInfo());
			}
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void inverseRedispersion()
	{
		int nuevo_tam = previousPrimeNumber(hashSize/2);
		HashNode<T> aux[] = tabla;
		
		// inicializar la propiedad tabla de la clase con el nuevo tam
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, nuevo_tam);
		
		for(int i = 0; i < nuevo_tam; i++)
		{
			tabla[i] = new HashNode<T>();
		}
		
		this.numElementos = 0;
		this.hashSize = nuevo_tam;
		
		for(int i = 0; i < aux.length; i++)
		{
			if(aux[i].getStatus() == HashNode.LLENO)
			{
				add(aux[i].getInfo());
			}
		}
	}
	
			
}
