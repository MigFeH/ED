package uo.ed;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public class TestBench {

	public static void main(String[] args) {
		TestBench t = new TestBench();
		//t.test0("salida1.csv",1,20);
		t.test2("salida2.csv",10,20,5);
		//t.test3("salida3.csv", 0, 2, 100, "Algorithms", "powRec2");
	}
	
	/**
	 * @param output fichero al escribir las mediciones
	 * @param startN valor de carga inicial
	 * @param EndN valor de carga final
	 */
	public void test0(String output, int startN, int EndN)
	{
		FileWriter file = null;
		PrintWriter pw;
		
		try
		{
			file = new FileWriter(output);
			pw = new PrintWriter(file);
			// Lineal 1
			for(int i = startN; i <= EndN; i++)
			{
				pw.format(Locale.FRANCE, "%f%n", (float)i*i);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(file != null)
			{
				try
				{
					file.close();
				}
				catch(IOException e1)
				{
					e1.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * Medir tiempos de algoritmos en base a una carga de trabajo i escribir en el fichero la diferencia de tiempos
	 * antes de ejecutar el algoritmo y despues de ejecutarlo
	 * @param output fichero al escribir las mediciones
	 * @param startN valor de carga inicial
	 * @param EndN valor de carga final
	 */
	public void test1(String output, int startN, int EndN)
	{
		FileWriter file = null;
		PrintWriter pw;
		Algorithms a = new Algorithms();
		float time_initial, time_final, time;
		try
		{
			file = new FileWriter(output);
			pw = new PrintWriter(file);
			for(int carga = startN; carga <= EndN; carga++)
			{
				time_initial = System.nanoTime();
				a.lineal(carga);
				time_final = System.nanoTime();
				time = time_final - time_initial;
				pw.print(carga + "; " + time);
				pw.format(Locale.FRANCE, "%f%n", time);
			}
			System.out.println("Proceso finalizado");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		} finally 
		{
			if(file != null)
			{
				try
				{
					file.close();
				} catch(IOException e1)
				{
					e1.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * Ejecutar el algoritmo con una carga unas n veces
	 * @param output fichero al escribir las mediciones
	 * @param startN valor de carga inicial
	 * @param EndN valor de carga final
	 * @param times las veces que se ejecuta el algoritmo a medir
	 */
	public void test2(String output, int startN, int EndN, int times)
	{
		FileWriter file = null;
		PrintWriter pw;
		Algorithms a = new Algorithms();
		float time_initial, time_final, tiempo;
		try
		{
			file = new FileWriter(output);
			pw = new PrintWriter(file);
			for(int carga = startN; carga <= EndN; carga++)
			{
				System.out.println("Ejecutando para carga " + carga);
				time_initial = System.nanoTime();
				for(int veces = 1; veces <= times; veces++)
				{
					a.powRec3(carga);
					a.doNothing();
				}
				time_final = System.nanoTime();
				tiempo = time_final - time_initial;
				pw.print(carga + "; ");
				pw.format(Locale.FRANCE, "%f%n", tiempo / (double) times);
			}
			System.out.println("Proceso finalizado");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		} finally 
		{
			if(file != null)
			{
				try
				{
					file.close();
				} catch(IOException e1)
				{
					e1.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * @param className
	 *            Nombre de la clase que contiene un m�todo que se quiere
	 *            invocar
	 * @param methodName
	 *            Nombre del m�todo que se quiere invocar
	 * @param n
	 *            Par�metro que se le pasa al m�todo invocado
	 */
	public void testAlgorithm(String className, String methodName, int n) throws InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, Exception 
	{
		Class<?> clase;
		Object miclase;
		Method metodo;

		// Localiza la clase
		try {
			clase = Class.forName(className); 
			// Crear una nueva instancia de la clase
			try {
				miclase = Class.forName(className).getDeclaredConstructor().newInstance();
				// Obtiene el metodo indicando y el tipo de par�metro
				// param[0]=int.class;
				try {
					metodo = clase.getMethod(methodName, int.class);
					// Invocar al m�todo
					try {
						metodo.invoke(miclase, n);
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param output Nombre del fichero de salida
	 * @param startN Valor inicial de carga
	 * @param endN Valor final de carga
	 * @param times Veces que se ejecuta un algoritmo para un determinado valor de carga
	 * @param clase Clase donde se encuentra el m�tod a invocar
	 * @param metodo M�todo a invocar
	 */
	public void test3(String output, int startN, int endN, int times, String clase, String metodo) 
	{
		FileWriter file = null;
		PrintWriter pw;
		double time_ini, time_fin, tiempo;

		try {
			file = new FileWriter(output);
			pw = new PrintWriter(file);
			for (int carga = startN; carga <= endN; carga++) {
				time_ini = System.currentTimeMillis();
				for (int veces = 1; veces <= times; veces++)
				{
					testAlgorithm(clase, metodo,carga);
					//doNothing
				}
				time_fin = System.currentTimeMillis();
				tiempo = time_fin - time_ini;
				//System.out.println("Ejecutando " + i);
				pw.print(carga + "; ");
				pw.format(Locale.FRANCE, "%f%n", tiempo / (double) times);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null)
				try {
					file.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
	}
}
