package uo.ed;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlgorithmsTest {

	Algorithms a = new Algorithms();
	
	/**
	 * Test para el metodo powIter()
	 */
	@Test
	void powIterTest() 
	{
		assertEquals(8,a.powIter(3));
	}
	
	/**
	 * Test para el metodo sumaIter()
	 */
	@Test
	void sumaIterTest() 
	{
		assertEquals(10,a.sumaIter(4));
	}
	
	/**
	 * Test para el metodo sumaRec()
	 */
	@Test
	void sumaRecTest() 
	{
		assertEquals(10,a.sumaRec(4));
	}
	
	/**
	 * Test para el metodo fibonacciIter()
	 */
	@Test
	void fibonacciIterTest() 
	{
		assertEquals(3,a.fibonacciIter(4));
	}
	
	/**
	 * Test para el metodo fibonacciRec()
	 */
	@Test
	void fibonacciRecTest() 
	{
		assertEquals(3,a.fibonacciRec(4));
	}
	
	/**
	 * Test para el metodo factorialIter()
	 */
	@Test
	void factorialIterTest() 
	{
		assertEquals(24,a.factorialIter(4));
	}
	
	/**
	 * Test para el metodo factorialRec()
	 */
	@Test
	void factorialRecTest() 
	{
		assertEquals(24,a.factorialRec(4));
	}
	
	/**
	 * Test para el metodo powRec1()
	 */
	@Test
	void powRec1Test() 
	{
		assertEquals(8,a.powRec1(3));
	}
	
	/**
	 * Test para el metodo powRec2()
	 */
	@Test
	void powRec2Test() 
	{
		assertEquals(8,a.powRec2(3));
	}
	
	/**
	 * Test para el metodo powRec3()
	 */
	@Test
	void powRec3Test() 
	{
		assertEquals(8,a.powRec3(3));
	}
}
