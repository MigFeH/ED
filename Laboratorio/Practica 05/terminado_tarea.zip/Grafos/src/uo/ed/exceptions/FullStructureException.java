package uo.ed.exceptions;

public class FullStructureException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public FullStructureException(Object element) {
		super("El elemnto " + element.toString() + " no se puede insertar porque la estructura est� llena");
	}

	public FullStructureException(Object element, Object dataStructure) {
		super("Element " + element.toString() + " could not be inserted. Data structure full:\n "
				+ dataStructure.toString());
	}

	public FullStructureException(String message) {
		super(message);
	}
}