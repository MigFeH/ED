package ColasPrioridad;

import Exceptions.ElementNotPresentException;

public class BinaryHeap <T extends Comparable<T>> implements PriorityQueue<T>
{
	private T[] monticulo; // vector de elementos de una determinada dimension
	private int numElementos; // numero de elementos insertados en el vector
	
	@SuppressWarnings("unchecked")
	public BinaryHeap(int n)
	{
		this.monticulo = (T[]) new Comparable[n];
		this.numElementos = 0;
	}

	/**
	 * @return NullPointerException, si el elemento es null.
	 * False, si el elemento no cabe.
	 * True, si el elemento se inserta correctamente.
	 */
	@Override
	public boolean add(T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		if(this.monticulo.length == numElementos)
		{
			return false;
		}
		
		this.monticulo[numElementos] = elemento;
		this.numElementos++;
		
		filtradoAscendente(this.numElementos-1);
		
		return true;
	}

	/**
	 * @return saca el elemento de la raiz y lo borra.
	 * Null, si la cola esta vacia
	 */
	@Override
	public T sacar()
	{
		if(numElementos == 0)
		{
			return null;
		}
		
		T aux = this.monticulo[0]; // aux es la raiz del monticulo
		T sustituto = this.monticulo[numElementos-1];
		this.monticulo[0] = sustituto;
		this.monticulo[numElementos-1] = null;
		this.numElementos--;
		filtradoDescendente(0);
		return aux; // devolvemos la raiz inicial del moticulo
	}

	/**
	 * @return borra un elemento de la cola de prioridad. Si el elemento est� repetido, borra el primero
	 * NullPointerException, si la clave pasada es null.
	 * ElementNotPresentException, si la clave no existe.
	 * False, si la cola esta vacia.
	 * True, si se ha eliminado correctamente el elemento.
	 */
	@Override
	public boolean remove(T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(numElementos == 0)
		{
			return false; // cola vacia
		}
		
		if(!existElement(elemento))
		{
			throw new ElementNotPresentException(elemento);
		}
		
		int pos = getIndexOfElement(elemento); // buscar el elemento para determinar su posicion O(n) (porque es buscar por un vector)
		T sustituto = this.monticulo[numElementos-1]; // ultimo elemento del vector
		T eliminado = this.monticulo[pos];
		this.monticulo[pos] = sustituto; // reemplazar por sustituto
		this.monticulo[numElementos-1] = null;
		numElementos--;
		
		if(eliminado.compareTo(sustituto) < 0) // elemento a eliminar < sustituto...
		{
			filtradoDescendente(getIndexOfElement(sustituto)); // porque es ir hacia abajo
		} else
		{
			filtradoAscendente(getIndexOfElement(sustituto)); // porque es ir hacia arriba
		}
		
		return true;
	}

	private int getIndexOfElement(T elemento)
	{
		int index = 0;
		for(int i = 0; i < numElementos; i++)
		{
			if(this.monticulo[i] != null && this.monticulo[i].compareTo(elemento) == 0)
			{
				return index;
			}
			index++;
		}
		return -1;
	}

	private boolean existElement(T elemento)
	{
		return getIndexOfElement(elemento) != -1;
	}

	/**
	 * @return True, si la cola esta vacia.
	 * False, si no esta vacia
	 */
	@Override
	public boolean isEmpty()
	{
		return this.numElementos == 0;
	}

	/**
	 * Pone a null a todos los elementos de la cola de prioridad
	 */
	@Override
	public void clear()
	{
		if(numElementos > 0)
		{
			for(int i = 0; i < numElementos; i++)
			{
				this.monticulo[i] = null;
			}
		}
	}

	/**
	 * Cambia el elemento de una determinada posicion
	 * @return NullPointerException, si el elemento es null
	 * False, si posicion incorrecta o la cola esta vacia
	 * True, si puede cambiar la prioridad
	 */
	@Override
	public boolean cambiarPrioridad(int pos, T elemento)
	{
		if(elemento == null)
		{
			throw new NullPointerException();
		}
		if(pos < 0 || pos >= numElementos || numElementos == 0)
		{
			return false;
		}
		// la posicion del elemento me da la pos
		// el sustituto es el que me pasan por parametro
		T anterior = this.monticulo[pos];
		this.monticulo[pos] = elemento;
		
		if(anterior.compareTo(elemento) < 0) // elemento anterior < sustituto...
		{
			filtradoDescendente(getIndexOfElement(elemento)); // porque es ir hacia abajo
		} else
		{
			filtradoAscendente(getIndexOfElement(elemento)); // porque es ir hacia arriba
		}
		
		return true;
	}
	
	/**
	 * Elementos separados por tabuladores. No hay tabulador al final
	 */
	@Override
	public String toString()
	{
		String res = "";
		for(int i = 0; i < numElementos - 1; i++)
		{
			res += this.monticulo[i] + "\t";
		}
		return res + this.monticulo[numElementos-1];
	}
	
	/**
	 * Filtrado ascendente a partir de la posicion pasada como parametro.
	 * Es necesario realizarlo cada vez que se inserta nuevo elemento o cuando se borra
	 * @param pos, posicion del elemento a aplicarle el filtrado ascendente
	 */
	private void filtradoAscendente(int pos)
	{
		int pos_hijo = pos; // tenemos el hijo (nos dan siempre el izquierdo) y tenemos que calcular el padre
		int pos_padre = (pos_hijo-1) / 2; // tenemos que calcular la posici�n del padre porque tenemos que ir de abajo a arriba
		
		/*
		 * Condici�n de parada:
		 * 1) hijo >= padre 
		 * 2) pos_hijo = 0; // estar�amos en la ra�z
		 */

		while(this.monticulo[pos_hijo].compareTo(this.monticulo[pos_padre]) < 0 /* hijo < padre...*/ && pos_hijo != 0)
		{
			// intercambio
			T padre = this.monticulo[pos_padre];
			
			this.monticulo[pos_padre] = this.monticulo[pos_hijo];
			this.monticulo[pos_hijo] = padre;
			
			pos_hijo = pos_padre;
			pos_padre = (pos_hijo-1) / 2;
		}
		
	}
	
	/**
	 * Filtrado descendente a partir de la posicion pasada como parametro.
	 * Es necesario realizarlo cada vez que se inserta nuevo elemento o cuando se borra
	 * @param pos, posicion del elemento a aplicarle el filtrado descendente
	 */
	private void filtradoDescendente(int pos)
	{
		int pos_padre = pos; // tenemos el padre y tenemos que calcular los hijos (vamos de arriba a abajo)
		int pos_hijo_izq = 2 * pos_padre + 1;
		int pos_hijo_der = 2 * pos_padre + 2;

		/*
		 * Condici�n de parada:
		 * 1) si los dos hijos son mayores
		 * 2) si la posici�n del hijo izquierdo es incorrecta (por tanto, tambien lo es la del hijo derecho)
		 * 3) si el hijo izquierdo es null (por tanto, tambien lo es el hijo derecho)
		 */

		while(pos_hijo_izq < numElementos // posicion del hijo izquierdo es valida
				&& this.monticulo[pos_hijo_izq] != null // hijo izquierdo no es null
				&& (this.monticulo[pos_hijo_izq].compareTo(this.monticulo[pos_padre]) < 0 // hijo izquierdo menor que el padre
				|| this.monticulo[pos_hijo_der].compareTo(this.monticulo[pos_padre]) < 0)) // hijo derecho menor que el padre
		{
			T padre = this.monticulo[pos_padre];
			
			// intercambio la posicion del padre con la posicion del menor de los hijos
			if(this.monticulo[pos_hijo_der].compareTo(this.monticulo[pos_hijo_izq]) < 0 /* derecho < izquierdo */
					&& this.monticulo[pos_hijo_der].compareTo(this.monticulo[pos_padre]) < 0) // derecho < padre
			{
				this.monticulo[pos_padre] = this.monticulo[pos_hijo_der];
				this.monticulo[pos_hijo_der] = padre;
				pos_padre = pos_hijo_der; // posici�n del hijo menor
				
			} else if(this.monticulo[pos_hijo_izq].compareTo(this.monticulo[pos_padre]) < 0) // izquierdo < padre
			{	
				this.monticulo[pos_padre] = this.monticulo[pos_hijo_izq];
				this.monticulo[pos_hijo_izq] = padre;
				pos_padre = pos_hijo_izq; // posici�n del hijo menor
			}

			pos_hijo_izq = 2 * pos_padre + 1;
			pos_hijo_der = 2 * pos_padre + 2;
		}
	}
	
}
