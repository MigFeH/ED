package Hash;

public abstract class AbstractHash<T>
{
	/**
	 * Se definen las cabeceras de los m�todos cuya implementaci�n depender� de la filosof�a de tablas
	 * hash (abiertas o cerradas)
	 */
	
	/**
	 * @return numero de elementos insertaos en la tabla hash hasta el momento
	 */
	abstract public int getNumOfElems();
	
	/**
	 * @return el tama�o de la tabla hash
	 */
	abstract public int getSize();
	
	/**
	 * @param elemento
	 * @return true, si se inserta correctamente.
	 * NullPointerException, si el elemento es null.
	 * false, si no se encuentra una posici�n vac�a (no es capaz de insertar)
	 */
	abstract public boolean add(T elemento);
	
	/**
	 * @param elemento
	 * @return NullPointerException, si elemento es null.
	 * El elemento entero junto con su estado (es decir, el nodo entero), si lo encuentra.
	 * null, si no encuentra el elemento
	 */
	abstract public HashNode<T> find(T elemento);
	
	/**
	 * @param elemento
	 * @return true, si encuentra el elemento y lo borra.
	 * false, si la tabla est� vac�a.
	 * NullPointerException, si el elemento es null
	 * ElementNotFoundException, si el elemento no existe en la tabla
	 */
	abstract public boolean remove(T elemento);
	
	/**
	 * @return una cadena con informaci�n
	 */
	abstract public String toString();
	
	/**
	 * Da una posici�n para un elemento dentro de una tabla hash
	 * @param elemento
	 */
	protected int fHash(T elemento)
	{
		int pos = elemento.hashCode() % getSize();
		if(pos < 0) return pos+getSize();
		else return pos;
	}
	
	/**
	 * @param numero
	 * @return si el numero pasado es primo o no
	 */
	protected boolean isPositivePrime(int numero)
	{
		for(int i = 2; i < numero; i++)
		{
			if(numero % i == 0)
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * @param numero
	 * @return el siguiente numero primo pasado como par�metro
	 */
	protected int nextPrimeNumber(int numero)
	{
		int aux = numero+1;
		
		while(!isPositivePrime(aux)) // mientras no sea primo...
		{
			aux++;
		}
		return aux;
	}
	
	/**
	 * @param numero
	 * @return el anterior numero primo pasado como par�metro.
	 * No devuelve n�meros menores que 3
	 */
	protected int previousPrimeNumber(int numero)
	{
		if(numero <= 3)
		{
			return numero;
		}
		if(isPositivePrime(numero))
		{
			return numero;
		}
		int num = numero-1;
		while(!isPositivePrime(num))
		{
			num--;
		}
		if(num <= 3)
		{
			return 3;
		}
		return num;
	}
}
