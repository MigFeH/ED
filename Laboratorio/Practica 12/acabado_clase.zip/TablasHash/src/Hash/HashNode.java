package Hash;

public class HashNode <T>
{
	/*
	 * Implementa un elemento de una tabla Hash
	 * Se permiten elementos repetidos y a la hora de borrar se realiza con el primer elemento encontrado
	 */
	public static final int BORRADO = -1;
	public static final int VACIO = 0;
	public static final int LLENO = 1;
	
	private T info; // el contenido de un elemento de la tabla hash
	private int estado; // estado del elemento de la tabla hash: borrado, lleno o vac�o
	
	
	public HashNode()
	{
		this.info = null;
		this.estado = VACIO;
	}
	
	/**
	 * @return el contenido del nodo
	 */
	public T getInfo()
	{
		return this.info;
	}
	
	/**
	 * Asigna contenido a un nodo y le asigna el estado LLENO al nodo
	 * @param elemento
	 */
	public void setInfo(T elemento)
	{
		this.info = elemento;
		this.estado = LLENO;
	}
	
	/**
	 * El estado pasa a borrado s�lamente, no borra nada.
	 * Esto nos sirve de cara a las b�squedas
	 */
	public void remove()
	{
		this.estado = BORRADO;
	}
	
	/**
	 * @return el estado del nodo
	 */
	public int getStatus()
	{
		return this.estado;
	}
		
	/**
	 * Muestra el contenido del nodo en funci�n de su estado
	 */
	public String toString()
	{
		StringBuilder cadena = new StringBuilder("{");
		switch (getStatus()) {
		case LLENO:
			cadena.append(info);
			break;
		case VACIO:
			cadena.append("_E_");
			break;
		case BORRADO:
			cadena.append("_D_");
		}
		cadena.append("}");
		return cadena.toString();
	}
}
