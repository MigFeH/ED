package uo.ed;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GraphTest {

	@Test
	public void addNoteTest()
	{
		Graph<String> G = new Graph<String>(5);
	
		assertTrue(G.addNode("Nodo_A"));
		
		// a�ado un nodo que ya existe
		assertTrue(G.addNode("Nodo_A"));
		assertTrue(G.addNode("Nodo_B"));
		
		// a�ado nodo repetido
		assertFalse(G.addNode("Nodo_A"));
		
		// a�ado un eje y su peso
		assertTrue(G.addEdge("Nodo_A", "Nodo_B", 4.0));
		
		// obtengo la posicion de un nodo
		assertEquals(G.getNode("Nodo_B"),1);
		
		// obtengo el peso del eje
		assertEquals(G.getEdge("Nodo_A", "Nodo_B"),4.0);
		
		// obtengo el peso de un eje para un nodo que no existe
		try
		{
			G.getEdge("Nodooooooooo_A", "Nodo_B");
		} catch(Exception e)
		{
			System.out.println(e.getMessage());
			assertEquals("El elemento Nodooooooooo_A no existe en la estructura", e.getMessage());
		}
		
		
		System.out.println(G.toString());
	}
	
	@Test
	public void T1_testGrafoVacio() {
		Graph<String> G = new Graph<String>(8);
		
		// mostrar el grafo vacio
		assertEquals("VECTOR NODOS\n\n\nMATRIZ ARISTAS\n\nMATRIZ PESOS\n",G.toString());
		System.out.println(G.toString());
		System.out.println("---------------------------\n");
		
		// borra un nodo en un arbol vacio
		try
		{
			assertFalse(G.removeNode("A"));
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			//assertEquals("");
		}
	}

}
