package uo.ed;

public class DijkstraDataClass {

}
