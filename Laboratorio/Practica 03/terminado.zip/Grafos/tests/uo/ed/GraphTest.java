package uo.ed;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uo.ed.exceptions.ElementNotPresentException;
import uo.ed.exceptions.FullStructureException;

class GraphTest {

	@Test
	public void addNodeTest()
	{
		Graph<String> G = new Graph<String>(5);
	
		assertTrue(G.addNode("Nodo_A"));
		
		// a�ado un nodo que ya existe
		assertFalse(G.addNode("Nodo_A"));
		assertTrue(G.addNode("Nodo_B"));
		
		// poner a false la fila y columna del nodo que se a�ade en la matriz de ejes
		for (int i = 0; i < G.getEjes().length; i++) {
			assertFalse(G.getEjes()[G.getNumNodos() - 1][i]);
			assertFalse(G.getEjes()[i][G.getNumNodos() - 1]);
		}
		// poner infinitos en la fila y columna del nodo que se a�ade en la matriz de pesos
		for (int i = 0; i < G.getPesos().length; i++) {
			assertEquals(G.getPesos()[G.getNumNodos() - 1][i], G.INFINITO);
			assertEquals(G.getPesos()[i][G.getNumNodos() - 1], G.INFINITO);
		}
		
		try
		{
			// a�ado nodo null
			G.addNode(null);
			
			// a�ado nodo en un grafo completo
			for(int i = 0; i < 5; i++)
			{
				G.addNode("Nodo_" + i);
			}
			G.addNode("Nodo_C");
			
		}catch(NullPointerException e)
		{
			assertEquals(e.getMessage(),"Nodo a a�adir null");
		}catch(FullStructureException e)
		{
			assertEquals(e.getMessage(), "El elemnto Nodo_C no se puede insertar porque la estructura est� llena");
		}
		
		System.out.println(G.toString());
	}
	
	@Test
	public void addEdgeTest()
	{
		Graph<String> G = new Graph<String>(5);
		
		G.addNode("Nodo_A");
		G.addNode("Nodo_B");
		
		// a�ado un eje y su peso
		assertTrue(G.addEdge("Nodo_A", "Nodo_B", 4.0));
		
		assertTrue(G.getEjes()[G.getNode("Nodo_A")][G.getNode("Nodo_B")]);
		assertEquals(G.getPesos()[G.getNode("Nodo_A")][G.getNode("Nodo_B")], 4.0);
		
		// ya existe el eje entre dos nodos --> false
		assertFalse(G.addEdge("Nodo_A", "Nodo_B", 8.0));
		
		try
		{
			// no existe el nodo origen
			G.addEdge("Nodo_C", "Nodo_B", 2.0);
			
		}catch(ElementNotPresentException e)
		{
			assertEquals(e.getMessage(),"El elemento Nodo_C no existe en la estructura");
		}
		
		try {
			// no existe el nodo destino
			G.addEdge("Nodo_A", "Nodo_D", 7.0);
			
			// peso de eje negativo
			G.addNode("Nodo_C");
			G.addEdge("Nodo_B", "Nodo_C", -2.0);
			
		}catch(ElementNotPresentException e)
		{
			assertEquals(e.getMessage(),"El elemento Nodo_D no existe en la estructura");
		}catch(IllegalArgumentException e)
		{
			assertEquals(e.getMessage(), "Peso de eje negativo");
		}
		System.out.println(G.toString());
	}
	
	@Test
	public void getNodeTest()
	{
		Graph<String> G = new Graph<String>(5);
		
		G.addNode("Nodo_A");
		G.addNode("Nodo_B");
		
		// obtengo la posicion de un nodo
		assertEquals(G.getNode("Nodo_B"), 1);
		
		// obtengo la posicion de un nodo que no existe
		assertEquals(G.getNode("Nodo_C"), -1);
	}
	
	@Test
	public void getEdgeTest()
	{
		Graph<String> G = new Graph<String>(5);
		
		G.addNode("Nodo_A");
		G.addNode("Nodo_B");
		
		G.addEdge("Nodo_A", "Nodo_B", 4.0);
		
		// obtengo el peso del eje
		assertEquals(G.getEdge("Nodo_A", "Nodo_B"), 4.0);
		
		// no existe eje entre los nodos origen y destino --> -1
		G.addNode("Nodo_C");
		assertEquals(G.getEdge("Nodo_A", "Nodo_C"), -1);
		
		try {
			// no existe el nodo origen
			G.getEdge("Nodooooooooo_A", "Nodo_B");
		} catch (ElementNotPresentException e) {
			assertEquals("El elemento Nodooooooooo_A no existe en la estructura", e.getMessage());
		}
		
		try {
			// no existe el nodo destino
			G.getEdge("Nodo_A", "Nodooooooooo_B");
		} catch (ElementNotPresentException e) {
			assertEquals("El elemento Nodooooooooo_B no existe en la estructura", e.getMessage());
		}
	}
	
	@Test
	public void removeNodeTest()
	{
		Graph<String> G = new Graph<String>(5);
		
		G.addNode("Nodo_A");
		G.addNode("Nodo_B");
		
		assertTrue(G.removeNode("Nodo_B"));
		
		// nodo a borrar no existente --> false
		assertFalse(G.removeNode("Nodo_C"));
		
		try
		{
			// nodo a borrar null
			G.removeNode(null);
		}catch(NullPointerException e)
		{
			assertEquals("Nodo a eliminar null", e.getMessage());
		}
	}
	
	@Test
	public void removeEdgeTest()
	{
		Graph<String> G = new Graph<String>(5);
		
		G.addNode("Nodo_A");
		G.addNode("Nodo_B");
		G.addNode("Nodo_C");
		
		assertTrue(G.addEdge("Nodo_A", "Nodo_B", 4.0));
		
		// no existe el eje entre el nodo origen y destino --> false
		assertFalse(G.removeEdge("Nodo_B", "Nodo_C"));
		
		try
		{
			// no existe el nodo origen
			G.removeEdge("Nodo_D", "Nodo_A");
		}catch(ElementNotPresentException e)
		{
			assertEquals("El elemento Nodo_D no existe en la estructura",e.getMessage());
		}
		
		try
		{
			// no existe el nodo destino
			G.removeEdge("Nodo_A", "Nodo_E");
		}catch(ElementNotPresentException e)
		{
			assertEquals("El elemento Nodo_E no existe en la estructura",e.getMessage());
		}
	}
	
	
	
	@Test
	public void T1_testGrafoVacio() {
		Graph<String> G = new Graph<String>(8);
		
		// mostrar el grafo vacio
		assertEquals("VECTOR NODOS\n\n\nMATRIZ ARISTAS\n\nMATRIZ PESOS\n",G.toString());
		System.out.println(G.toString());
		System.out.println("---------------------------\n");
		
		// borra un nodo en un arbol vacio
		try
		{
			assertFalse(G.removeNode("A"));
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			//assertEquals("");
		}
	}

}
