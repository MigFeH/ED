package uo.ed;

public class DijkstraDataClass {
	
	/**
	 * Metodo que implementa el algoritmo de Dijkstra. Calcula el camino de coste
	 * minimo desde el nodoOrigen al resto de los nodos.
	 * @param nodoOrigen
	 * @return Un objeto de la clase DijkstraDataClass que contiene de vector D y el
	 * vector P. Null si no se puede aplicar Dijkstra.
	 */
	/*public DijkstraDataClass Dijkstra(T nodoOrigen)
	{
		
	}*/
	
	/**
	 * Metodo que implementa el algoritmo de Floyd segun lo visto en clase de teoria.
	 * @return true si genera las matrices A y P. false en caso contrario.  
	 */
	/*public boolean floyd()
	{
		
	}*/
	
	/**
	 * Metodo recursivo que implementa el recorrido en profundidad de un grafo
	 * desde un nodo origen
	 * @param nodo
	 * @return Una cadena con el recorrido de los nodos en profundidad separados
	 * por tabuladores. La cadena vacia si el nodo no existe.
	 */
	/*public String recorridoProfundidad(T nodo)
	{
		
	}*/
	
	/**
	 * Obtiene el valor del camino de coste minimo para ir desde el nodo origen al
	 * nodo destino.
	 * @param origen
	 * @param destino
	 * @return El valor del camino de coste minimo entre origen y destino segun el
	 * algoritmo de Floyd. Si no se habia aplicado Floyd, lo invoca.
	 * Si los nodos origen o destino no existen, lanza una excepcion de tipo
	 * ElementNotPresentException
	 */
	/*public double minCostPath(T origen, T destino)
	{
		
	}*/
	
	/**
	 * Obtiene una cadena con el camino del coste minimo entre el nodo origen y el
	 * nodo destino. 
	 * @param origen
	 * @param destino
	 * @return La cadena vacia, si no existen el nodo origen o el nodo destino.
	 * Si el nodo origen es igual al nodo destino, la cadena contendra tan solo
	 * el nodo origen seguido de un tabulador.
	 * Si no hay camino entre el nodo origen y el nodo destino, la cadena
	 * tendra el siguiente formato:
	 * 		Origen<tab>(Infinito)<tab>Destino<tab>
	 * Si hay camino entre el nodo origen y el nodo destino, la cadena tendra
	 * el siguiente formato:
	 * 		Origen<tab>(coste0)<tab>Intermedio1<tab>(coste1) � IntermedioN<tab>(costeN)<tab>Destino<tab>
	 */
	/*public String path(T origen, T destino)
	{
		
	}*/
}
