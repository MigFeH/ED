package uo.ed;

import java.text.DecimalFormat;
import java.util.ArrayList;

import uo.ed.exceptions.ElementNotPresentException;
import uo.ed.exceptions.FullStructureException;

public class Graph<T> {
	double INFINITO = Double.POSITIVE_INFINITY;
	
	private T[] nodos; // el contenido de cada nodo es de tipo generico
	private boolean[][] ejes; // filas: origen, columnas: destino
	private double[][] pesos; // pesos de los ejes (reales positivos)
	private int numNodos; // numero de nodos insertados hasta el momento
	
	/**
	 * Constructor
	 * @param n numero maximo de nodos que tendra el grafo
	 */
	@SuppressWarnings("unchecked")
	public Graph(int n)
	{
		nodos = (T[]) new Object[n];
		ejes = new boolean[n][n];
		pesos = new double[n][n];
		numNodos = 0;
	}
	
	/**
	 * @param nodo de tipo T
	 * @return la posicion dentro del vector donde se encuentra el nodo. -1 si no existe el nodo
	 */
	public int getNode(T nodo)
	{
		int index = 0;
		for(T theNode: nodos)
		{
			if(theNode != null && theNode.equals(nodo))
			{
				return index; 
			}
			index++;
		}
		return -1;
	}
	
	/**
	 * @param nodo de tipo T
	 * @return true o false en funcion de la existencia del nodo
	 */
	public boolean existNode(T nodo)
	{
		for(T theNode: nodos)
		{
			if(theNode != null && theNode.equals(nodo))
			{
				return true; 
			}
		}
		return false;
	}
	
	/**
	 * A�ade un nuevo nodo que se pasa por parametro
	 * @param nodo de tipo T
	 * @return true si lo inserta correctamente. false si ya existe el nodo (por tanto, no se inserta).
	 * Retorna una FullStructureException si no cabe el nodo en el grafo.
	 * Retorna un NullPointerException si el nodo es null.
	 */
	public boolean addNode(T nodo)
	{
		if(nodo == null)
		{
			throw new NullPointerException("Nodo a a�adir null");
		}
		if(nodos.length == numNodos)
		{
			throw new FullStructureException(nodo);
		}
		
		if(numNodos > 0) // si el grafo tiene nodos...
		{
			boolean existNode = existNode(nodo);
			if(existNode)
			{
				return false;
			}
		}
		numNodos++;

		// a�adir nodo al vector de nodos
		int index = numNodos - 1;
		nodos[index] = nodo;

		// poner a false la fila y columna del nodo que se a�ade en la matriz de ejes
		for (int i = 0; i < ejes.length; i++) {
			ejes[index][i] = false;
			ejes[i][index] = false;
		}
		// poner infinitos en la fila y columna del nodo que se a�ade en la matriz de
		// pesos
		for (int i = 0; i < pesos.length; i++) {
			pesos[index][i] = INFINITO;
			pesos[i][index] = INFINITO;
		}

		return true;
	}
	
	/**
	 * A�ade un nuevo eje que une a dos nodos pasados por parametro con un peso pasado por parametro
	 * @param origen nodo del que parte el eje a a�adir
	 * @param destino nodo al que llega el eje a a�adir
	 * @param peso peso del eje a a�adir
	 * @return true si a�ade el eje correctamente. false si ya existe un eje entre los nodos pasados por parametro.
	 * Retorna una ElementNotPresentException si no existe nodo origen o nodo destino o ambos.
	 * Retorna una IllegalArgumentException si el peso es negativo.
	 */
	public boolean addEdge(T origen, T destino, double peso)
	{
		if(!existNode(origen))
		{
			throw new ElementNotPresentException(origen);
		}
		if(!existNode(destino))
		{
			throw new ElementNotPresentException(destino);
		}
		if(peso < 0.0)
		{
			throw new IllegalArgumentException("Peso de eje negativo");
		}
		if(existEdge(origen, destino)) // si existe el eje...
		{
			return false;
		}
		else // sino...
		{
			ejes[getNode(origen)][getNode(destino)] = true;
			pesos[getNode(origen)][getNode(destino)] = peso;
			
			return true;
		}
	}
	
	/**
	 * @param origen nodo de tipo T
	 * @param destino nodo de tipo 
	 * @return true o false en funcion de la existencia del eje que une a los nodos pasados por parametro
	 */
	public boolean existEdge(T origen, T destino)
	{
		// si hay un true en la casilla de ejes (origen, destino) entonces retornamos true
		int index_origen = getNode(origen);
		int index_destino = getNode(destino);
		
		if(ejes[index_origen][index_destino])
		{
			return true;
		}
		return false;
	}
	
	/**
	 * @param origen nodo origen de tipo T
	 * @param destino nodo destino de tipo T
	 * @return el peso del eje que une los nodos pasados por parametro.
	 * Retorna una ElementNotPresentException si no existe al menos uno de los nodos pasados.
	 * Retorna -1 si entre los nodos pasados por parametro no hay un eje existente.
	 * Retorna una IllegalArgumentException si al menos uno de los nodos es null.
	 */
	public double getEdge(T origen, T destino)
	{
		if(!existNode(origen))
		{
			throw new ElementNotPresentException(origen);
		}
		if(!existNode(destino))
		{
			throw new ElementNotPresentException(destino);
		}
		if(!existEdge(origen, destino))
		{
			return -1;
		}
		return pesos[getNode(origen)][getNode(destino)];
	}
	
	/**
	 * Ponemos en los pesos un infinito y en la matriz de ejes un false
	 * @param origen nodo origen de tipo T
	 * @param destino nodo destino de tipo T
	 * @return true si se borra correctamente el eje. false si no existiese un eje entre los nodos pasados
	 * Retorna un ElementNotPresentException si al menos uno de los nodos no existe.
	 */
	public boolean removeEdge(T origen, T destino)
	{
		if(!existNode(origen))
		{
			throw new ElementNotPresentException(origen);
		}
		if(!existNode(destino))
		{
			throw new ElementNotPresentException(destino);
		}
		if(!existEdge(origen, destino))
		{
			return false;
		}
		
		ejes[getNode(origen)][getNode(destino)] = false;
		pesos[getNode(origen)][getNode(destino)] = INFINITO;
		
		return true;
	}
	
	/**
	 * @param nodo de tipo T a borrar
	 * @return true si borra el nodo correctamente. false si el nodo no existe
	 * Retorna un NullPointerException si el nodo es null
	 */
	public boolean removeNode(T nodo)
	{
		if(nodo == null)
		{
			throw new NullPointerException("Nodo a eliminar null");
		}
		if(!existNode(nodo)) // si el nodo no existe...
		{
			return false;
		}
		else
		{
			// pasar el ultimo nodo a la posicion del nodo que borramos
			nodos[getNode(nodo)] = nodos[numNodos - 1];
			
			
			// en la matriz de nodos pasamos la fila del ultimo nodo que borramos en la fila del nodo a borrar
			// y la columna del ultimo nodo en la columna del nodo a borrar 
			for(int i = 0; i < numNodos-1; i++)
			{
				ejes[getNode(nodo)][i] = ejes[numNodos - 1][i]; // fila
				ejes[i][getNode(nodo)] = ejes[i][numNodos - 1]; // columna
				
				ejes[numNodos - 1][i] = false;
				ejes[i][numNodos - 1] = false;
			}
			
			for(int i = 0; i < numNodos-1; i++)
			{
				pesos[getNode(nodo)][i] = pesos[numNodos - 1][i]; // fila
				pesos[i][getNode(nodo)] = pesos[i][numNodos - 1]; // columna
				
				pesos[numNodos - 1][i] = INFINITO;
				pesos[i][numNodos - 1] = INFINITO;
			}
			
			numNodos--;
				
			return true;
		}
	}
	
	/**
	 * Metodo para mostrar el contenido del grafo
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		String cadena = "";

		cadena += "VECTOR NODOS\n";
		for (int i = 0; i < numNodos; i++) {
			cadena += nodos[i].toString() + "\t";
		}
		cadena += "\n\nMATRIZ ARISTAS\n";
		for (int i = 0; i < numNodos; i++) {
			for (int j = 0; j < numNodos; j++)
				if (ejes[i][j])
					cadena += "T\t";
				else
					cadena += "F\t";
			cadena += "\n";
		}
		cadena += "\nMATRIZ PESOS\n";
		for (int i = 0; i < numNodos; i++) {
			for (int j = 0; j < numNodos; j++) {
				if (ejes[i][j]) cadena += df.format(pesos[i][j])+"\t";
				else cadena += "-" + "\t";
			}
			cadena += "\n";
		}
		return cadena;
	}
	
	public T[] getNodos()
	{
		return this.nodos;
	}
	
	public boolean[][] getEjes()
	{
		return this.ejes;
	}
	
	public double[][] getPesos()
	{
		return this.pesos;
	}
	
	public int getNumNodos()
	{
		return this.numNodos;
	}
	
	/**
	 * 
	 * @param nodo a partir del cual queremos calcular sus caminos de coste minimo
	 * @return objeto de tipo DijkstraDataClass con la posicion a partir del cual se aplica dijkstra, 
	 * su vector D, su vector P
	 */
	@SuppressWarnings("unchecked")
	public DijkstraDataClass dijkstra(T nodo)
	{
		ArrayList<T> S = new ArrayList<>();  // nodos para los cuales ya se conoce el camino
		ArrayList<T> V = new ArrayList<>(); // todos los nodos del grafo menos nodo origen
		double[] D = new double[numNodos]; // vector con el coste desde el nodo origen al resto de los nodos
		double[] P = new double[numNodos]; // vector donde se almacena desde que nodo se accede a los nodos
		
		boolean[] visitados = new boolean[numNodos];// vector de tama�o numNodos con todo a False salvo la poicion del nodo que se pasa como parametro
		
		S.add(nodo); // = nodo origen
		for(int i = 0; i < nodos.length; i++)
		{
			visitados[i] = false;
			if(!nodos[i].equals(nodo))
			{
				V.add(nodo);
				visitados[i] = true;
			}
			
			D[i] = getPesos()[getNode(nodo)][i]; // dentro de la matriz de pesos la fila del nodo origen
		}
		
		// a si mismo ponemos 0; si es infinito ponemos -1; y si se llega desde un nodo ponemos el indice del nodo desde
		// el que se accede
		for(int i = 0; i < nodos.length; i++)
		{
			if(nodos[i].equals(nodo))
			{
				P[i] = 0;
			} else if(getEdge(nodo, nodos[i]) != -1)
			{
				P[i] = getNode(nodo);
			} else
			{
				P[i] = INFINITO;
			}
		}
		
		// mientras haya nodos en V
		while(V.size() > 0)
		{
			// Paso 2
			// seleccionar un nodo w de V tal que su coste sea minimo
			T w = getPivote(S,V,D);
			
			// Borrar W de V
			int posW = V.indexOf(w);
			borrarPivoteDeV(w,V);
			
			// A�adir W a S
			S.add(w);
			
			// Paso 3
			// para cada nodo m de V
			for(T m: V)
			{
				if(D[posW] + pesos[posW][V.indexOf(m)] < D[posW])
				{
					D[posW] = D[posW] + pesos[posW][V.indexOf(m)];
					P[m] = posicion del w;
				}
			}
			
		}
		
		return new DijkstraDataClass(numNodos, getNode(nodo),D,P);
	}

	private void borrarPivoteDeV(T w, ArrayList<T> v) 
	{
		for(int i = 0; i < v.size(); i++)
		{
			if(v.get(i).equals(w))
			{
				v.remove(i);
				break;
			}
		}
	}

	private T getPivote(ArrayList<T> s, ArrayList<T> v, double[] d) 
	{
		double minimo = INFINITO;
		T pivote = null;
		
		int index = 0;
		for(int i = 0; i < v.size(); i++)
		{
			if(!isNodoIn(v.get(i), s))
			{
				if(d[index] <= index)
				{
					minimo = d[index];
					pivote = v.get(index);
				}
			} else
			{
				continue;
			}
			index++;
		}
		
		return pivote;
	}

	private boolean isNodoIn(T nodo, ArrayList<T> s)
	{
		for(int i = 0; i < s.size(); i++)
		{
			if(s.get(i).equals(nodo))
			{
				return true;
			}
		}
		return false;
	}
		
}
