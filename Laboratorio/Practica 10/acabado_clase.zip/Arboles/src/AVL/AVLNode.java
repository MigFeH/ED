package AVL;

public class AVLNode <T extends Comparable <T>>
{
	private T info; // contenido del nodo que sera de tipo generico
	private AVLNode<T> left; // nodo hijo izquierdo
	private AVLNode<T> right; // nodo hijo derecho
	private int balanceFactor; // factor de balance del nodo
	private int height; // altura del nodo
	
	
	/**
	 * Constructor, que recibe como par�metro el contenido que se le debe asignar a la propiedad info (contenido) del nodo. 
	 * Tambi�n inicializar� el hijo izquierdo y el derecho del nodo a null y la altura y el factor de balance a cero. 
	 * Se entiende que cuando se crea un nodo es un nodo hoja
	 * @param clave, contenido del nodo (la info del nodo)
	 */
	public AVLNode(T clave)
	{
		setInfo(clave);
		setLeft(null);
		setRight(null);
		this.height = 0;
		this.balanceFactor = 0;
	}
	
	/**
	 * Asigna al nodo la clave pasada por parametro, dicha clave sera asignada a la propiedad info del nodo
	 * @param clave, info a asignar al nodo
	 */
	public void setInfo(T clave)
	{
		this.info = clave;
	}
	
	/**
	 * @return el valor de la propiedad info del nodo
	 */
	public T getInfo()
	{
		return this.info;
	}
	
	/**
	 * Asigna al nodo un nodo hijo izquierdo pasado como parametro
	 * @param nodo hijo a asignar
	 */
	public void setLeft(AVLNode<T> nodo)
	{
		this.left = nodo;
	}
	
	/**
	 * Asigna al nodo un nodo hijo derecho pasado como parametro
	 * @param nodo hijo a asignar
	 */
	public void setRight(AVLNode<T> nodo)
	{
		this.right = nodo;
	}
	
	/**
	 * @return el subarbol izquierdo
	 */
	public AVLNode<T> getLeft()
	{
		return this.left;
	}
	
	/**
	 * @return el subarbol derecho
	 */
	public AVLNode<T> getRight()
	{
		return this.right;
	}
	
	/**
	 * @return la altura del nodo
	 */
	public int getHeight()
	{
		return this.height;
	}
	
	/**
	 * @return el factor de balance del nodo
	 */
	public int getBF()
	{
		return this.balanceFactor;
	}
	
	/**
	 * actualiza el factor de balance y la altura del nodo
	 */
	public void updateBFHeight()
	{
		// se basa en las alturas de sus hijos izquierdo y derecho (dicha altura ya la saben los hijos, no es necesario el calculo de la altura para cada nodo hijo
		
		int altura_hijo_izquierdo = 0;
		int altura_hijo_derecho = 0;
		
		if(getLeft() == null)
		{
			altura_hijo_izquierdo = -1;
		} else
		{
			altura_hijo_izquierdo = getLeft().getHeight();
		}
		
		if(getRight() == null)
		{
			altura_hijo_derecho = -1;
		} else
		{
			altura_hijo_derecho = getRight().getHeight();
		}
		
		int nueva_altura = maximo(altura_hijo_izquierdo, altura_hijo_derecho) + 1;
		this.height = nueva_altura;
		
		int nuevo_BF = altura_hijo_derecho - altura_hijo_izquierdo;
		this.balanceFactor = nuevo_BF;
	}
	
	private int maximo(int numero1, int numero2)
	{
		if(numero1 < numero2)
		{
			return numero2;
		}
		return numero1;
	}

	public String toString()
	{
		return info.toString() + ":BF=" + getBF();
	}
}
