package BST;

public class BSTree<T extends Comparable<T>>
{
	private BSTNode<T> raiz; // NODO RAIZ del arbol BST
	
	/**
	 * Crea arbol vacio (no es un nodo vacio, es null)
	 */
	public BSTree()
	{
		this.raiz = null;
	}
	
	/**
	 * Dada una clave pasada como parametro, retorna el nodo completo que tenga esa clave
	 * @param clave de tipo T
	 * @return el nodo completo que tiene la clave pasada como parametro si encuentra la clave en el arbol;
	 * null si no lo encuentra
	 */
	public BSTNode<T> search(T clave)
	{
		if(this.raiz == null)
		{
			return null;
		}
		
		if(clave == null)
		{
			throw new NullPointerException();
		}
		
		// nodo del subarbol donde busco la clave
		return searchNodeRec(raiz, clave);
	}
	
	private BSTNode<T> searchNodeRec(BSTNode<T> nodo, T clave)
	{
		if(nodo == null || nodo.getInfo() == null) // caso basico (o de finalizacion): nodo no encontrado (nodo de clave null)
		{
			return null;
		}
		
		// si clave < nodo (la info) busco en el subarbol izquierdo
		if(clave.compareTo(nodo.getInfo()) < 0) // clave < nodo.getInfo()
		{
			return searchNodeRec(nodo.getLeft(), clave);
		}
		
		// si clave > nodo (la info) busco en el subarbol derecho
		if(clave.compareTo(nodo.getInfo()) > 0) // clave > nodo.getInfo()
		{
			return searchNodeRec(nodo.getRight(), clave);
		}

		// si clave == nodo (la info) retorno el nodo
		return nodo; // clave == nodo.getInfo()
	}

	/**
	 * @param clave de tipo T del nodo a agregar al arbol
	 * @return true si inserta el nodo (o clave) (si encuentra hueco para insertarlo (va a ser siempre)); 
	 * false si ya existe la clave en el arbol; NullPointerException si la clave es null
	 */
	public boolean addNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(raiz == null) // arbol vacio (no tiene raiz)
		{
			this.raiz = new BSTNode<T>(clave);
			return true;
		}
		return addRec(raiz, clave);
	}
	
	private boolean addRec(BSTNode<T> nodo, T clave)
	{
		if(nodo.getInfo() == clave) // caso basico: nodo existente en el arbol
		{
			return false;
		}
		
		if(clave.compareTo(nodo.getInfo()) > 0)
		{
			if(nodo.getRight() == null) // nodo de la derecha es null
			{
				nodo.setRight(new BSTNode<T>(clave)); // set del nuevo nodo por la derecha
				return true;
			}
			// sino devolver el resultado de volver a llamar al subarbol derecho
			return addRec(nodo.getRight(), clave);
		}
		
		if(clave.compareTo(nodo.getInfo()) < 0)
		{
			if(nodo.getLeft() == null) // nodo de la izquierda es null
			{
				nodo.setLeft(new BSTNode<T>(clave)); // set del nuevo nodo por la izquierda
				return true;
			}
			// sino devolver el resultado de volver a llamar al subarbol izquierdo
			return addRec(nodo.getLeft(), clave);
		}
		
		return false; // nodo existente en el arbol
	}

	/**
	 * @return recorrido del arbol en preorden:
	 * 	raiz, izquierda, derecha
	 */
	public String preOrder()
	{
		return preOrderRec(raiz);
	}
	
	private String preOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return nodo.toString() + "\t" + preOrderRec(nodo.getLeft()) + preOrderRec(nodo.getRight());
	}

	/**
	 * @return recorrido del arbol en postorden:
	 * izquierda, derecha, raiz
	 */
	public String postOrder()
	{
		return postOrderRec(raiz);
	}
	
	private String postOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return postOrderRec(nodo.getLeft()) + postOrderRec(nodo.getRight()) + nodo.toString() + "\t";
	}

	/**
	 * izquierda, raiz, derecha
	 * @return
	 */
	public String inOrder()
	{
		return inOrderRec(raiz);
	}
	
	private String inOrderRec(BSTNode<T> nodo)
	{
		if(nodo == null) // caso basico (o de finalizacion)
		{
			return "";
		}
		
		return inOrderRec(nodo.getLeft()) + nodo.toString() + "\t" + inOrderRec(nodo.getRight());
	}

	public boolean removeNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException("Element to insert is null.");
		}
		
		if(search(clave) == null)
		{
			return false;
		} else
		{
			raiz = removeNodeRec(raiz, clave);
			return true;
		}
	}

	private BSTNode<T> removeNodeRec(BSTNode<T> nodo, T clave)
	{
		if(clave.compareTo(nodo.getInfo()) > 0) // el elemento a borrar est� en el subarbol derecho
		{
			BSTNode<T> nuevo_nodo = removeNodeRec(nodo.getRight(), clave); // devuelve el subarbol derecho modificado
			nodo.setRight(nuevo_nodo);  // asignar nodo por la derecha lo que me devuelve el removeR (nuevo_nodo)
			return nodo;
		} else if(clave.compareTo(nodo.getInfo()) < 0) // el elemento a borrar est� en el subarbol izquierdo
		{
			BSTNode<T> nuevo_nodo = removeNodeRec(nodo.getLeft(), clave); // devuelve el subarbol izquierdo modificado
			nodo.setLeft(nuevo_nodo); // asignar nodo por la izquierda lo que me devuelve el removeR (nuevo_nodo)
			return nodo;
		} else // hemos encontrado la clave (el nodo) y el algoritmo recursivo termina
		{
			if(nodo.getRight() == null) // si nodo por la derecha es null
			{
				return nodo.getLeft();
			} else
			{
				if(nodo.getLeft() == null) // si el nodo por la izquierda es null
				{
					return nodo.getRight();
				} else // ni la derecha ni izquierda son null
				{
					BSTNode<T> mayor = buscarElMayorDelSubarbol(nodo.getLeft());
					nodo.setInfo(mayor.getInfo());
					BSTNode<T> nuevo_nodo = removeNodeRec(nodo.getLeft(), mayor.getInfo());
					nodo.setLeft(nuevo_nodo);
					return nodo;
				}
			}
		}
	}

	/**
	 * buscar el mayor del subarbol izquierdo del nodo
	 */
	private BSTNode<T> buscarElMayorDelSubarbol(BSTNode<T> nodo)
	{
		while(nodo.getRight() != null)
		{
			nodo = nodo.getRight();
		}
		return nodo;
	}
}
