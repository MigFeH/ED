package BST;

public class BSTNode <T extends Comparable <T>>
{
	private T info; // el contenido del nodo que va a ser de tipo generico
	
	private BSTNode<T> left; // nodo hijo izquierdo
	private BSTNode<T> right; // nodo hijo derecho
	
	
	/**
	 * Crea un nuevo nodo sin hijo derecho ni izquierdo
	 * @param clave de tipo T, es la info del nodo a crear
	 */
	public BSTNode(T clave)
	{
		if(clave == null)
		{
			throw new NullPointerException();
		}
		
		setInfo(clave);
		this.left = null;
		this.right = null;
	}
	
	/**
	 * Asigna a la propiedad info de un nodo el valor pasado por parametro
	 * @param clave, el valor a insertar en la propiedad info de un nodo
	 */
	public void setInfo(T clave)
	{
		this.info = clave;
	}
	
	/**
	 * @return el valor de la propiedad info de un nodo
	 */
	public T getInfo()
	{
		return this.info;
	}
	
	/**
	 * Asigna a un nodo padre un nodo hijo izquierdo pasado por parametro
	 * @param nodo de tipo T que sera el hijo izquierdo de un nodo padre
	 */
	public void setLeft(BSTNode<T> nodo)
	{
		this.left = nodo;
	}
	
	/**
	 * Asigna a un nodo padre un nodo hijo derecho pasado por parametro
	 * @param nodo de tipo T que sera el hijo derecho de un nodo padre
	 */
	public void setRight(BSTNode<T> nodo)
	{
		this.right = nodo;
	}
	
	/**
	 * @return el hijo izquierdo de un nodo padre
	 */
	public BSTNode<T> getLeft()
	{
		return this.left;
	}
	
	/**
	 * @return el hijo derecho de un nodo padre
	 */
	public BSTNode<T> getRight()
	{
		return this.right;
	}
	
	public String toString()
	{
		return info.toString();
	}
	
}
